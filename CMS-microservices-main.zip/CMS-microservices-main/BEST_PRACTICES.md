# Avoiding the N+1 Problem using Spring JPA

**Introduction**

The N+1 problem can significantly degrade the performance of your construction CMS project, particularly when dealing with entities like `File`, `Folder`, and `FileVersion`. This document outlines best practices for avoiding the N+1 problem using JOIN FETCH and DTO projections.

### Using `JOIN FETCH`

- **What is JOIN FETCH?**
JOIN FETCH allows you to retrieve a parent entity and its associated child entities in a single query. This prevents the N+1 problem, where multiple additional queries would otherwise be executed to load related entities.

- **Example**
  Suppose you need to fetch all files along with their associated folders. Without JOIN FETCH, fetching the File entities might result in N+1 queries to load each file's Folder.

  Here’s how to use JOIN FETCH to optimize this:
```Java
@Query("SELECT f FROM File f JOIN FETCH f.folder WHERE f.deleted = FALSE")
List<File> findAllFilesWithFolder();
```
**Explanation:**
1. `JOIN FETCH f.folder`: This part of the query ensures that both the `File` and its associated `Folder` are fetched in one go.
2. **Avoiding N+1:** Instead of executing one query to fetch the `File` entities and then additional queries to fetch their `Folder` entities, this single query retrieves everything, avoiding the N+1 problem.

### Using DTO Projections
- **What are DTO Projections?**
  DTO projections involve fetching only specific fields from your entities and mapping them to a Data Transfer Object (DTO). This approach reduces data transfer and avoids N+1 problems by controlling exactly what is fetched.
- **Example**
Suppose you need to retrieve only the file name and folder name for a report or API response. Instead of fetching entire `File` and `Folder` entities, you can use a DTO projection.
```java
@Query("SELECT new com.digitalchain.document_management.dto.FileFolderDTO(f.file_name, fo.folder_name) " +
       "FROM File f JOIN f.folder fo WHERE f.deleted = FALSE")
List<FileFolderDTO> findAllFileNamesWithFolderNames();
```
**Explanation:**
1. `FileFolderDTO`: A simple DTO that holds just the file name and folder name.
2. `JOIN f.folder fo`: Joins the File and Folder entities to access both fields.
3. `DTO Projection`: Only the required fields (`file_name` and `folder_name`) are fetched and mapped directly to the `FileFolderDTO`.
