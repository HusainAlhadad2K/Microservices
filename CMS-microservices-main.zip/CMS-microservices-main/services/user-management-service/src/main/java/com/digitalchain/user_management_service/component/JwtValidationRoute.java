package com.digitalchain.user_management_service.component;

import com.digitalchain.user_management_service.dto.UserDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.stereotype.Component;

@Component
public class JwtValidationRoute extends RouteBuilder {

    @Value("${auth.validation.url}")
    private String validationUrl;

    @Override
    public void configure() throws Exception {
        from("direct:validateJwt")
                .log("Validating JWT")
                .doTry()
                .process(exchange -> {
                    exchange.setProperty("originalBody", exchange.getIn().getBody());
                    exchange.setProperty("originalMethod", exchange.getIn().getHeader(Exchange.HTTP_METHOD));

                    exchange.getIn().setBody(null);
                    exchange.getIn().setHeader(Exchange.HTTP_METHOD, "GET");
                })
                .enrich(validationUrl + "validate?bridgeEndpoint=true", (original, resource) -> {
                    log.info("Using URL");
                    // Process the validation response
                    String validationResponse = resource.getIn().getBody(String.class);
                    log.info("JWT validation response: " + validationResponse);

                    // Return the original exchange (no changes to body)
                    return original;
                })
                .enrich(validationUrl + "decode?bridgeEndpoint=true", (original, resource) -> {
                    log.info("Decoding JWT");

                    String decodingResponse = resource.getIn().getBody(String.class);
                    ObjectMapper objectMapper = new ObjectMapper();
                    UserDTO user;
                    try {
                        user = objectMapper.readValue(decodingResponse, UserDTO.class);
                    } catch (JsonProcessingException e) {
                        throw new RuntimeException(e);
                    }
                    log.info("Decoded response user id: " + user.getUser_id());

                    original.setProperty("user", user);
                    original.getIn().setBody(original.getProperty("originalBody"));

                    return original;
                })
                .doCatch(HttpOperationFailedException.class)
                .process(exchange -> {
                    HttpOperationFailedException cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, HttpOperationFailedException.class);
                    int statusCode = cause.getStatusCode();

                    if (statusCode == 401) {
                        log.warn("JWT validation failed with status 401 (Unauthorized)");
                        throw new JwtException("Unauthorized");
                    } else {
                        log.error("HTTP operation failed with status code: " + statusCode);
                        throw new RuntimeException("HTTP operation failed with status code: " + statusCode);
                    }
                })
                .end();
    }
}

