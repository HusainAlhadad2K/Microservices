package com.digitalchain.alert_service.services;

import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AlertService {

    @Autowired
    private ProducerTemplate producerTemplate;

    public void triggerAlert(String message) {
        producerTemplate.sendBody("kafka:alerts", message); // Sends an alert to the Kafka topic
    }

}
