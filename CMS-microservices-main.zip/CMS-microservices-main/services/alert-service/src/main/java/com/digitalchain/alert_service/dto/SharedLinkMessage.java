package com.digitalchain.alert_service.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SharedLinkMessage {
    private String targetType;
    private String targetName;
    private String sharedWith;
    private String sharedBy;
}
