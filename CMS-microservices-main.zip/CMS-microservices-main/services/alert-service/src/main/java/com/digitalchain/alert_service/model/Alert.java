package com.digitalchain.alert_service.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Alert {
    private String userEmail; // The email address of the user to notify
    private AlertType alertType; // Type of the alert (e.g., INFO, WARNING, ERROR)
    private String alertMessage; // The main content of the alert message
    private LocalDateTime timestamp; // Timestamp of when the alert was generated
    private boolean isSent; // Flag indicating if the alert has been sent successfully
}
