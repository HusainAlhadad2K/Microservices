package com.digitalchain.alert_service.route;

import com.digitalchain.alert_service.config.BaseRouteBuilder;
import com.digitalchain.alert_service.dto.SharedLinkMessage;
import com.digitalchain.alert_service.services.SendGridEmailService;
import org.apache.camel.LoggingLevel;
import org.springframework.stereotype.Component;

@Component
public class AlertRoute extends BaseRouteBuilder {

    private final SendGridEmailService sendGridEmailService;

    // Inject SendGridEmailService into AlertRoute via constructor
    public AlertRoute(SendGridEmailService sendGridEmailService) {
        this.sendGridEmailService = sendGridEmailService;
    }

    @Override
    public void configure() throws Exception {
        // Define a Kafka consumer route
        from("kafka:shared-link-topic?brokers={{camel.component.kafka.brokers}}")
                .routeId("kafkaToMailRoute")
                .log(LoggingLevel.INFO, "Received alert message from Kafka: ${body}")

                // Unmarshal the Kafka message into SharedLinkMessage object
                .unmarshal().json(SharedLinkMessage.class)

                // Process the Kafka message to extract details for the email
                .process(exchange -> {
                    SharedLinkMessage message = exchange.getIn().getBody(SharedLinkMessage.class);

                    // Extract necessary details from the message
                    String fromEmail = "contentsystemalert333@gmail.com"; // Ensure this email is verified in SendGrid
                    String toEmail = message.getSharedWith();  // The recipient of the email
                    String subject = "New Shared Link Notification";  // Subject of the email
                    String contentText = String.format("The user %s has shared a %s with you: %s.",
                            message.getSharedBy(), message.getTargetType(), message.getTargetName());

                    // Log email details
                    log.info("Sending email to: " + toEmail);
                    log.info("Email subject: " + subject);
                    log.info("Email body: " + contentText);

                    // Use SendGridEmailService to send the email
                    sendGridEmailService.sendEmail(fromEmail, toEmail, subject, contentText);
                })
                // Log after successful email sending
                .log(LoggingLevel.INFO, "Email sent successfully to ${body.sharedWith}");
    }
}
