package com.digitalchain.alert_service.config;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.stereotype.Component;

@Component
public class RestApiConfiguration extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        restConfiguration()
                .component("servlet")
                .bindingMode(RestBindingMode.json)
                .dataFormatProperty("prettyPrint", "true")
                .contextPath("/api")  // Base path for all your REST services
                .apiContextPath("/doc")  // Swagger UI path
                .apiProperty("api.title", "chat")
                .apiProperty("api.version", "1.0")
                .apiProperty("api.description", "Operations related to files in the CMS")
                .apiProperty("host", "")
                .apiProperty("schemes", "http,https")
                .apiProperty("base.path", "/api")
                .apiProperty("cors", "true");  // Enable CORS support
    }
}