package com.digitalchain.alert_service.exception;

public class UnsupportedMediaTypeException extends RuntimeException {
    public UnsupportedMediaTypeException(String message){super(message);}
}
