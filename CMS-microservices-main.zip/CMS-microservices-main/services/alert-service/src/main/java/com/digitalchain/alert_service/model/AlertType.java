package com.digitalchain.alert_service.model;

public enum AlertType {
    INFO,
    WARNING,
    ERROR
}
