package com.digitalchain.alert_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
