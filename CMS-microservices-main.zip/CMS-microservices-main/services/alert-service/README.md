# Microservices Template

Welcome to the Java Microservices Template! This project provides a foundational setup for building Spring Boot microservices using. The template is designed to help teams quickly scaffold new services.

### Template Structure 
- **component**: Contains reusable components and processors for the microservice.
  - **GlobalValidationProcessor**: Handles global request validation.
  - **JwtValidationRoute**: Provides routing and validation logic for JWT tokens.
- **config**: Configuration classes for setting up the microservice.
  - **BaseRouteBuilder**: Base class for defining Apache Camel routes.
  - **EurekaClientConfig**: Configuration for integrating with Eureka service discovery.
  - **RestApiConfiguration**: Configures the REST API settings, such as base paths.
  - **SecurityConfig**: Manages security settings, including authentication and authorization.
- **dto**: Data Transfer Objects (DTOs) used to encapsulate data sent between client and server.
  - **ErrorDTO**: Structure for returning error information in API responses.
  - **UserDTO**: Contains user-related data.
- **exception**: Handles custom exceptions and global error processing.
  - **ExceptionDetails**: Provides detailed information about exceptions.
  - **ExceptionType**: Enum for defining various types of exceptions.
  - **GlobalErrorHandler**: Centralized error handler for catching and processing exceptions.
  - **GlobalErrorProcessor**: Processes global exceptions and sends meaningful responses.
  - **ResourceNotFoundException**: Custom exception for handling missing resources.
  - **UnsupportedMediaTypeException**: Custom exception for unsupported media types.
  - **MicroserviceTemplateApplication**: The main entry point for the Spring Boot application.

### How To Use
#### Step 1: Clone the repository
```
git clone https://github.com/Digitalchain-IT/microservice-template your-new-microservice
```
#### Step 2: Customize the project
1. Update the `pom.xml`:
   - Change the `artifactId`, `name` and `description`
      ```
        <artifactId>microservice-template</artifactId>
        <version>0.0.1-SNAPSHOT</version>
        <name>microservice-template</name>
        <description>Microservice reusable template</description>
      ```
2. Update package names:
   Refactor the Java package names (e.g., com.yourorg.template) to match your project.
![img.png](assets/img.png)
![img_1.png](assets/img_1.png)
![img_2.png](assets/img_2.png)

### Step 3: Remove git from cloned project
Delete the `.git` folder in your cloned service
![img_3.png](assets/img_3.png)