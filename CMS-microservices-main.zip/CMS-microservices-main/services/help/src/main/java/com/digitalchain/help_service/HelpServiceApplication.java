package com.digitalchain.help_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@EnableMongoRepositories(basePackages = "com.digitalchain.help_service.repository")  // Enable MongoDB repositories
public class HelpServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(HelpServiceApplication.class, args);
	}
}



