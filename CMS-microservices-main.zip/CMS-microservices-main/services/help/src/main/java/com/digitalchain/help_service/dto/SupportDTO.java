package com.digitalchain.help_service.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SupportDTO {
    @NotBlank(message = "Support title is mandatory")
    private String support_title;

    @NotBlank(message = "Description is mandatory")
    private String description;

    private String submitted_by; // This will be set by the UserDTO

    @NotBlank(message = "Submitted to is mandatory")
    private String submitted_to;

    private String status; // This can be optional during creation
}
