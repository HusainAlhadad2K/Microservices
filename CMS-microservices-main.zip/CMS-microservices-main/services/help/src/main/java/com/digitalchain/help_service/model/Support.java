package com.digitalchain.help_service.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.UUID;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@Document(collection = "support")  // Defines the MongoDB collection name
public class Support {

    @Id
    private UUID support_id;  // Unique ID for each support ticket

    private String support_title;

    // User IDs for submitted_by and submitted_to
    private String submitted_by;  // This will now store the user ID of the person submitting the ticket
    private String submitted_to;  // This will now store the user ID of the person receiving the ticket

    private String status;  // Ticket status (e.g., New, Open, Resolved)

    @Size(max = 2000, message = "Description cannot be more than 2000 characters")
    private String description;

    @CreatedDate
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date created_at;

    @LastModifiedDate
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date updated_at;
}
