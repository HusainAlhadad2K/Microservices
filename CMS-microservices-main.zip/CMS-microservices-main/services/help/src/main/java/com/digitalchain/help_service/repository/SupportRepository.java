package com.digitalchain.help_service.repository;

import com.digitalchain.help_service.model.Support;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.UUID;

public interface SupportRepository extends MongoRepository<Support, UUID> {

    // Custom query to filter by submitted_by and submitted_to
    @Query("{ $and: [ { 'submitted_by': { $regex: ?0, $options: 'i' } }, { 'submitted_to': { $regex: ?1, $options: 'i' } } ] }")
    Page<Support> findBySubmittedByAndSubmittedTo(String submittedBy, String submittedTo, Pageable pageable);

}
