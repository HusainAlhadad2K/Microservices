package com.digitalchain.help_service.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateStatusDTO {
    @NotBlank(message = "Status is mandatory")
    private String status;  // The new status to be set (e.g., Open, Resolved)
}
