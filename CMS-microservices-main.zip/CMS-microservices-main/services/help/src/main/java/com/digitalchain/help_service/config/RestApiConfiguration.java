package com.digitalchain.help_service.config;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.stereotype.Component;

@Component
public class RestApiConfiguration extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        restConfiguration()
                .component("servlet")
                .bindingMode(RestBindingMode.json)
                .dataFormatProperty("prettyPrint", "true")
                .contextPath("/api")  // Base path for all your REST services
                .apiContextPath("support/doc")  // Swagger UI path
                .apiProperty("api.title", "Support")
                .apiProperty("api.version", "1.0")
                .apiProperty("api.description", "Operations related to Help and Support Center in the CMS")
                .apiProperty("host", "localhost:8222")
                .apiProperty("schemes", "http,https")
                .apiProperty("base.path", "localhost:8222/api/")
                .apiProperty("cors", "true");  // Enable CORS support
    }
}