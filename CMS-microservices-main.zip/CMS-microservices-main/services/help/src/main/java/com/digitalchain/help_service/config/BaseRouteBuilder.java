package com.digitalchain.help_service.config;

import com.digitalchain.help_service.component.GlobalValidationProcessor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;

public class BaseRouteBuilder extends RouteBuilder {
    @Autowired
    private GlobalValidationProcessor globalValidationProcessor;

    @Override
    public void configure() throws Exception {
        onException(Throwable.class)
                .log("Exception caught")
                .to("direct:error")
                .handled(true);

        interceptFrom("rest:*")
                .log("Intercepting")
                .process(exchange -> {
                    exchange.getContext().createProducerTemplate().send("direct:validateJwt", exchange);
                }).process(globalValidationProcessor);
    }
}