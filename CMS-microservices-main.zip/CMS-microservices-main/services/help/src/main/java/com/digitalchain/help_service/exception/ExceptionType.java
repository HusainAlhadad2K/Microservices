package com.digitalchain.help_service.exception;

import lombok.Getter;

@Getter
public enum ExceptionType {
    ResourceNotFoundException(404, "Resource Not Found"),
    UnsupportedMediaTypeException(415, "Unsupported Media Type"),
    IOException(500, "IO Exception"),
    AccessDeniedException(403, "Access Denied"),
    UsernameNotFoundException(404, "User Not Found"),
    JwtException(401, "Invalid Token"),
    UNEXPECTED_ERROR(500, "Unexpected Error");

    private final ExceptionDetails details;

    ExceptionType(int errorCode, String errorName) {
        this.details = new ExceptionDetails(errorCode, errorName);
    }

    // Static method to get ExceptionType by exception class name
    public static ExceptionType fromExceptionClass(Class<? extends Throwable> exceptionClass) {
        try {
            return ExceptionType.valueOf(exceptionClass.getSimpleName());
        } catch (IllegalArgumentException e) {
            return UNEXPECTED_ERROR; // Fallback to a default if no match is found
        }
    }
}
