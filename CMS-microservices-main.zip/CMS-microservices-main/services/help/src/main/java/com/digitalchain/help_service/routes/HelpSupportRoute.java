package com.digitalchain.help_service.routes;

import com.digitalchain.help_service.config.BaseRouteBuilder;
import com.digitalchain.help_service.dto.SupportDTO;
import com.digitalchain.help_service.dto.UpdateStatusDTO;
import com.digitalchain.help_service.dto.UserDTO;
import com.digitalchain.help_service.model.Support;
import com.digitalchain.help_service.service.HelpSupportService;
import org.apache.camel.Exchange;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class HelpSupportRoute extends BaseRouteBuilder {

    @Autowired
    private HelpSupportService helpSupportService;

    @Override
    public void configure() throws Exception {
        super.configure();

        // REST API routes
        rest("/support")
                // Create a new support ticket
                .post()
                .type(SupportDTO.class)
                .description("Report a new support ticket")
                .responseMessage().code(200).message("Support ticket reported successfully").responseModel(Support.class).endResponseMessage()
                .responseMessage().code(400).message("Invalid input or missing required fields").endResponseMessage() // 400 error handling
                .to("direct:createSupportTicket")

                .get()
                .description("Retrieve all reported support tickets with pagination, sorting, and filtering")
                .responseMessage().code(200).message("Support tickets retrieved successfully").responseModel(Support.class).endResponseMessage()
                .to("direct:getAllSupportTickets")

                // Update a specific support ticket
                .put("/{supportId}")
                .type(SupportDTO.class)
                .description("Update an existing support ticket")
                .responseMessage().code(200).message("Support ticket updated successfully").responseModel(Support.class).endResponseMessage()
                .responseMessage().code(400).message("Invalid input or missing required fields").endResponseMessage() // 400 error handling
                .to("direct:updateSupportTicket")

                // Delete a specific support ticket
                .delete("/{supportId}")
                .description("Delete a support ticket by ID")
                .responseMessage().code(200).message("Support ticket deleted successfully").endResponseMessage()
                .responseMessage().code(404).message("Support ticket not found").endResponseMessage()
                .responseMessage().code(400).message("Invalid request").endResponseMessage() // 400 error handling
                .to("direct:deleteSupportTicket")

                // Get a specific support ticket by ID
                .get("/{supportId}")
                .description("Get a specific support ticket by ID")
                .responseMessage().code(200).message("Support ticket retrieved successfully").responseModel(Support.class).endResponseMessage()
                .responseMessage().code(404).message("Support ticket not found").endResponseMessage()
                .responseMessage().code(400).message("Invalid request").endResponseMessage() // 400 error handling
                .to("direct:getSupportTicketById")

                // Update the status of a support ticket
                .put("/{supportId}/status")
                .type(UpdateStatusDTO.class)  // Expect the UpdateStatusDTO as the request body
                .description("Update the status of a support ticket")
                .responseMessage().code(200).message("Support ticket status updated successfully").responseModel(Support.class).endResponseMessage()
                .responseMessage().code(400).message("Invalid input or missing required fields").endResponseMessage() // 400 error handling
                .to("direct:updateSupportStatus");

        // Route for creating a support ticket
        from("direct:createSupportTicket")
                .routeId("createSupportTicket")
                .process(exchange -> {
                    SupportDTO supportDTO = exchange.getIn().getBody(SupportDTO.class);
                    UserDTO user = exchange.getProperty("user", UserDTO.class); // Get UserDTO from exchange properties

                    // Set the submitted_by value from UserDTO's user ID
                    supportDTO.setSubmitted_by(user.getUser_id());

                    Support support = helpSupportService.createSupportTicket(supportDTO);
                    exchange.getIn().setBody(support);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        // Route for getting all support tickets with filters
        from("direct:getAllSupportTickets")
                .routeId("getAllSupportTickets")
                .process(this::getAllReportedTickets)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        // Route for updating a specific support ticket
        from("direct:updateSupportTicket")
                .routeId("updateSupportTicket")
                .process(exchange -> {
                    UUID supportId = UUID.fromString(exchange.getIn().getHeader("supportId", String.class));
                    SupportDTO supportDTO = exchange.getIn().getBody(SupportDTO.class);
                    Support updatedSupport = helpSupportService.updateSupportTicket(supportId, supportDTO);
                    exchange.getIn().setBody(updatedSupport);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        // Route for deleting a support ticket
        from("direct:deleteSupportTicket")
                .routeId("deleteSupportTicket")
                .process(exchange -> {
                    UUID supportId = UUID.fromString(exchange.getIn().getHeader("supportId", String.class));
                    helpSupportService.deleteSupportTicket(supportId);
                    exchange.getIn().setBody("Support ticket deleted successfully");
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        // Route for retrieving a specific support ticket by ID
        from("direct:getSupportTicketById")
                .routeId("getSupportTicketById")
                .process(exchange -> {
                    UUID supportId = UUID.fromString(exchange.getIn().getHeader("supportId", String.class));
                    Support support = helpSupportService.getSupportTicketById(supportId);
                    exchange.getIn().setBody(support);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        // Route logic for updating support ticket status
        from("direct:updateSupportStatus")
                .routeId("updateSupportStatus")
                .process(exchange -> {
                    UUID supportId = UUID.fromString(exchange.getIn().getHeader("supportId", String.class));
                    UpdateStatusDTO updateStatusDTO = exchange.getIn().getBody(UpdateStatusDTO.class);

                    // Call the service method to update the status
                    Support updatedSupport = helpSupportService.updateSupportTicketStatus(supportId, updateStatusDTO.getStatus());

                    // Set the updated support object as the response body
                    exchange.getIn().setBody(updatedSupport);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
    }

    // Method to handle pagination, sorting, and filtering for support tickets
    private void getAllReportedTickets(Exchange exchange) {
        // Pagination headers
        int page = exchange.getIn().getHeader("page", 0, Integer.class); // Default to page 0
        int size = exchange.getIn().getHeader("size", 10, Integer.class); // Default to size 10

        // Sorting headers
        String sortBy = exchange.getIn().getHeader("sortBy", "created_at", String.class); // Default to created_at
        String sortDirection = exchange.getIn().getHeader("sortDirection", "asc", String.class); // Default to ascending order

        // Filter headers
        String submittedBy = exchange.getIn().getHeader("submitted_by", "", String.class); // Filter by submitted_by
        String submittedTo = exchange.getIn().getHeader("submitted_to", "", String.class); // Filter by submitted_to

        // Build Sort object based on sortBy and sortDirection
        Sort sort = Sort.by(Sort.Direction.fromString(sortDirection), sortBy);

        // Create a Pageable object with sorting
        Pageable pageable = PageRequest.of(page, size, sort);

        // Query the service to get filtered and sorted tickets
        Page<Support> supportPage = helpSupportService.getFilteredSupportTickets(submittedBy, submittedTo, pageable);

        // Set the paginated and sorted results as the response body
        exchange.getIn().setBody(supportPage);
    }
}
