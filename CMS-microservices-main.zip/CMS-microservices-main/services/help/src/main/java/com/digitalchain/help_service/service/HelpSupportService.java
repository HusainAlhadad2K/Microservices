package com.digitalchain.help_service.service;

import com.digitalchain.help_service.dto.SupportDTO;
import com.digitalchain.help_service.model.Support;
import com.digitalchain.help_service.repository.SupportRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class HelpSupportService {

    @Autowired
    private SupportRepository supportRepository;

    // Create a new support ticket
    // Create a new support ticket
    public Support createSupportTicket(SupportDTO supportDTO) {
        if (supportDTO == null || supportDTO.getSupport_title() == null || supportDTO.getDescription() == null) {
            throw new IllegalArgumentException("Support title and description are required");
        }

        Support support = Support.builder()
                .support_id(UUID.randomUUID())
                .support_title(supportDTO.getSupport_title())
                .description(supportDTO.getDescription())
                .submitted_by(supportDTO.getSubmitted_by()) // Set from UserDTO
                .submitted_to(supportDTO.getSubmitted_to())
                .status("New")
                .created_at(new Date())
                .build();

        // Save the support ticket to the MongoDB database
        return supportRepository.save(support);
    }

    // Get all reported support tickets with pagination, sorting, and filtering
    public Page<Support> getFilteredSupportTickets(String submittedBy, String submittedTo, Pageable pageable) {
        return supportRepository.findBySubmittedByAndSubmittedTo(submittedBy, submittedTo, pageable);
    }
    // Update an existing support ticket
    public Support updateSupportTicket(UUID supportId, SupportDTO supportDTO) {
        Support existingSupport = supportRepository.findById(supportId)
                .orElseThrow(() -> new IllegalArgumentException("Support ticket not found"));

        existingSupport.setSupport_title(supportDTO.getSupport_title());
        existingSupport.setDescription(supportDTO.getDescription());
        existingSupport.setStatus(supportDTO.getStatus());
        existingSupport.setUpdated_at(new Date());

        return supportRepository.save(existingSupport);
    }

    // Delete a support ticket
    public void deleteSupportTicket(UUID supportId) {
        Support support = supportRepository.findById(supportId)
                .orElseThrow(() -> new IllegalArgumentException("Support ticket not found"));
        supportRepository.delete(support);
    }



    // Get a specific support ticket by ID
    public Support getSupportTicketById(UUID supportId) {
        return supportRepository.findById(supportId)
                .orElseThrow(() -> new IllegalArgumentException("Support ticket not found"));
    }
    public Support updateSupportTicketStatus(UUID supportId, String status) {
        // Find the existing support ticket by its ID
        Support existingSupport = supportRepository.findById(supportId)
                .orElseThrow(() -> new IllegalArgumentException("Support ticket not found"));

        // Update the status
        existingSupport.setStatus(status);
        existingSupport.setUpdated_at(new Date());  // Update the timestamp

        // Save and return the updated support ticket
        return supportRepository.save(existingSupport);
    }
}