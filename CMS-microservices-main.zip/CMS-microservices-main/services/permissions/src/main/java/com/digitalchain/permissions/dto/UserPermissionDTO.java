package com.digitalchain.permissions.dto;

import com.digitalchain.common.enums.permissions.Role;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserPermissionDTO {
    @NotNull
    private String userId;

    @NotNull
    private Role role;
}
