package com.digitalchain.permissions.service;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.common.dto.users.GroupResponseDTO;
import com.digitalchain.common.dto.users.UserDetailsDTO;
import com.digitalchain.common.dto.users.UserResponseDTO;
import com.digitalchain.permissions.exception.ResourceNotFoundException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UsersService {
    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    public GroupResponseDTO getGroupDetails(String groupId, UserDTO user){
        try {
            Exchange exchange = producerTemplate.request("direct:getGroupsDetails", e -> {
                e.getIn().setHeader("groupId", groupId);
                e.getIn().setHeader("jwtToken", user.getJwtToken()); // Pass the JWT token to the route
            });

            int responseCode = exchange.getMessage().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
            if (responseCode == 200) {
                String responseBody = exchange.getMessage().getBody(String.class);
                return objectMapper.readValue(responseBody, GroupResponseDTO.class);
            } else {
                throw new ResourceNotFoundException("Group with id " + groupId + " does not exist");
            }
        } catch (Exception ex) {
            throw new ResourceNotFoundException("Group with id " + groupId + " does not exist");
        }
    }

    public UserDetailsDTO getUserDetails(String userId, UserDTO user){
        try {
            Exchange exchange = producerTemplate.request("direct:getUsersDetails", e -> {
                e.getIn().setHeader("userId", userId);
                e.getIn().setHeader("jwtToken", user.getJwtToken()); // Pass the JWT token to the route
            });

            int responseCode = exchange.getMessage().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
            if (responseCode == 200) {
                String responseBody = exchange.getMessage().getBody(String.class);
                return objectMapper.readValue(responseBody, UserDetailsDTO.class);
            } else {
                throw new ResourceNotFoundException("User with id " + userId + " does not exist");
            }
        } catch (Exception ex) {
            throw new ResourceNotFoundException("User with id " + userId + " does not exist");
        }
    }
}
