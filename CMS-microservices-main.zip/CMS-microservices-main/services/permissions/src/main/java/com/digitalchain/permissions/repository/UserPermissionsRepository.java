package com.digitalchain.permissions.repository;

import com.digitalchain.permissions.model.UserPermissions;

import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserPermissionsRepository extends JpaRepository<UserPermissions, UUID> {
    void deleteByFolderId(UUID folderId);
    List<UserPermissions> findByFolderId(UUID folderId);
    @Query("SELECT up FROM UserPermissions up WHERE up.folderId IN :folderIds AND up.userId = :userId")
    List<UserPermissions> findByFolderIdsAndUserId(@Param("folderIds") List<UUID> folderIds, @Param("userId") String userId);

    @Query(value = "SELECT COUNT(*) > 0 FROM user_permissions WHERE role <> 'NONE' AND folder_path LIKE CONCAT(:pathPrefix, '%') LIMIT 1", nativeQuery = true)
    boolean existsByPathPrefixAndRoleNotNone(@Param("pathPrefix") String pathPrefix);
}
