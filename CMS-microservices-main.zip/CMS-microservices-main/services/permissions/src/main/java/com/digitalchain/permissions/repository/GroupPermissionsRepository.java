package com.digitalchain.permissions.repository;

import com.digitalchain.permissions.model.GroupPermissions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface GroupPermissionsRepository extends JpaRepository<GroupPermissions, UUID> {
    void deleteByFolderId(UUID folderId);
    List<GroupPermissions> findByFolderId(UUID folderId);

    @Query("SELECT gp FROM GroupPermissions gp WHERE gp.folderId IN :folderIds AND gp.groupId IN :groupIds")
    List<GroupPermissions> findByFolderIdsAndGroupIds(@Param("folderIds") List<UUID> folderIds, @Param("groupIds") List<String> groupIds);

    @Query(value = "SELECT COUNT(*) > 0 FROM group_permissions WHERE role <> 'NONE' AND folder_path LIKE CONCAT(:pathPrefix, '%') LIMIT 1", nativeQuery = true)
    boolean existsByPathPrefixAndRoleNotNone(@Param("pathPrefix") String pathPrefix);
}
