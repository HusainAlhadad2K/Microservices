package com.digitalchain.permissions.dto;

import com.digitalchain.common.enums.permissions.Role;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GroupPermissionDTO {
    @NotNull
    private String groupId;

    @NotNull
    private Role role; // The role assigned to the group
}
