package com.digitalchain.permissions.routes;

import com.digitalchain.permissions.config.BaseRouteBuilder;
import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

@Component
public class FoldersRoutes extends BaseRouteBuilder {

    @Override
    public void configure() throws Exception {
        super.configure();
        // Define a route to call the external API to get folder details
        from("direct:getFolderDetails")
                .routeId("getFolderDetails")
                .setHeader(Exchange.HTTP_METHOD, constant("GET"))
                .setHeader(Exchange.HTTP_URI, simple("{{application.config.document-url}}/${header.folderId}"))
                .setHeader("Authorization", simple("${header.jwtToken}"))
                .toD("http://dummyhost") // Use http4 component, the actual URI is set in HTTP_URI header
                .choice()
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(200))
                .log("Folder details retrieved successfully")
                .setBody(simple("${body}")) // Keep the response body as is
                .otherwise()
                .log("Failed to retrieve folder details or folder does not exist")
                .setBody(constant(null)); // Set the body to null if the folder is not found
    }
}
