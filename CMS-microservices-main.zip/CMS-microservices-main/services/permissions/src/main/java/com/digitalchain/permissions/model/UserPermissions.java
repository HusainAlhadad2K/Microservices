package com.digitalchain.permissions.model;

import com.digitalchain.common.enums.permissions.Role;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.UUID;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "user_permissions")
public class UserPermissions {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "permission_id", nullable = false)
    private UUID permissionId;

    @Column(name = "folder_id", nullable = false)
    private UUID folderId;

    @Column(name = "folder_path")
    private String folderPath;

    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "role", nullable = false)
    @Enumerated(EnumType.STRING)
    private Role role;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Date createdAt;

    @Column(name = "created_by", nullable = false)
    private String createdBy;
}
