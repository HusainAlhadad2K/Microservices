package com.digitalchain.permissions.service;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.permissions.exception.ResourceNotFoundException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.UUID;
@Service
public class FoldersService {

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Retrieves the folder details by calling the external API with a JWT token.
     *
     * @param folderId The ID of the folder to retrieve.
     * @param user The JWT token for authorization.
     * @return The folder details as a String, or null if not found.
     */
    public FolderDTO getFolderDetails(UUID folderId, UserDTO user) {
        try {
            Exchange exchange = producerTemplate.request("direct:getFolderDetails", e -> {
                e.getIn().setHeader("folderId", folderId);
                e.getIn().setHeader("jwtToken", user.getJwtToken()); // Pass the JWT token to the route
            });

            int responseCode = exchange.getMessage().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
            if (responseCode == 200) {
                String responseBody = exchange.getMessage().getBody(String.class);
                return objectMapper.readValue(responseBody, FolderDTO.class);
            } else {
                throw new ResourceNotFoundException("Folder with id " + folderId + "does not exist");
            }
        } catch (Exception ex) {
            throw new ResourceNotFoundException("Folder with id " + folderId + "does not exist");
        }
    }
}
