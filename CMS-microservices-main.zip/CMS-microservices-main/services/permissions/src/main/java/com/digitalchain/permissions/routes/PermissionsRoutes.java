package com.digitalchain.permissions.routes;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.users.UserDetailsDTO;
import com.digitalchain.permissions.config.BaseRouteBuilder;
import com.digitalchain.common.dto.permissions.FilterFolderPermissionsDTO;
import com.digitalchain.common.dto.permissions.FilterFolderPermissionsRequestDTO;
import com.digitalchain.permissions.dto.PermissionRequestDTO;
import com.digitalchain.permissions.service.PermissionsService;
import com.digitalchain.permissions.service.ValidatePermissionsService;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class PermissionsRoutes extends BaseRouteBuilder {

    @Autowired
    private PermissionsService permissionsService;

    @Autowired
    private ValidatePermissionsService validateFoldersPermissions;

    @Override
    public void configure() throws Exception {
        super.configure();

        // Define REST endpoints with Swagger documentation
        rest("/permissions")
                // Create or update permissions for a folder
                .post()
                .type(PermissionRequestDTO.class)
                .description("Creates or updates permissions for a folder")
                .param().name("body").type(RestParamType.body).description("Details of the permissions to be created or updated").dataType("PermissionRequestDTO").endParam()
                .responseMessage().code(200).message("Permissions created or updated successfully").endResponseMessage()
                .responseMessage().code(400).message("Bad request - Invalid permission data").endResponseMessage()
                .to("direct:createOrUpdatePermissions")

                // Delete permissions for a specific folder by ID
//                .delete("/{folderId}")
//                .description("Deletes permissions for a specific folder by its ID")
//                .param().name("folderId").type(RestParamType.path).description("UUID of the folder").dataType("UUID").required(true).endParam()
//                .responseMessage().code(200).message("Permissions deleted successfully").endResponseMessage()
//                .responseMessage().code(404).message("Permissions not found for the given folder ID").endResponseMessage()
//                .to("bean:permissionsService?method=deletePermissions(${header.folderId})")

                // Get permissions for a specific folder by ID
                .get("/{folderId}")
                .description("Gets permissions for a specific folder by its ID")
                .param().name("folderId").type(RestParamType.path).description("UUID of the folder").dataType("UUID").required(true).endParam()
                .responseMessage().code(200).message("Permissions retrieved successfully").endResponseMessage()
                .responseMessage().code(404).message("Permissions not found for the given folder ID").endResponseMessage()
                .to("direct:getPermissionsByFolderId")

                .post("/validate-folder-access")
                .description("Validates folder access based on folder IDs and user information")
                .type(FilterFolderPermissionsRequestDTO.class)
                .outType(List.class)
                .to("direct:validateFolderAccess");

        // Route to handle creating or updating permissions
        from("direct:createOrUpdatePermissions")
                .routeId("createOrUpdatePermissions")
                .description("Creates or updates permissions for a folder using the provided data")
                .process(this::createOrUpdatePermissions);

        // Route to get permissions by folder ID
        from("direct:getPermissionsByFolderId")
                .routeId("getPermissionsByFolderId")
                .description("Fetches permissions associated with the given folder ID")
                .process(this::getPermissionsByFolderId);

        from("direct:validateFolderAccess")
                .routeId("validateFolderAccess")
                .log("Starting folder access validation")
                .process(this::validateFolderAccess)
                .log("Completed folder access validation");
    }

    private void createOrUpdatePermissions(Exchange exchange) {
        PermissionRequestDTO permissionRequestDTO = exchange.getIn().getBody(PermissionRequestDTO.class);
        UUID folderId = permissionRequestDTO.getFolderId();
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        log.info("USER_DETAILS {}", user);

        // Call the service to create or update permissions
        permissionsService.updateFolderPermissions(permissionRequestDTO, user);

        // Return a success response
        exchange.getIn().setBody("Permissions created or updated successfully for folderId: " + folderId);
    }

    private void getPermissionsByFolderId(Exchange exchange) {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);

        // Call the service to get permissions by folderId
        Object permissions = permissionsService.getPermissionsByFolderId(folderId);

        // Set the retrieved permissions as the response body
        exchange.getIn().setBody(permissions);
    }

    private void validateFolderAccess(Exchange exchange) {
        FilterFolderPermissionsRequestDTO requestDTO = exchange.getIn().getBody(FilterFolderPermissionsRequestDTO.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);
        UserDetailsDTO userDetails = exchange.getProperty("userDetails", UserDetailsDTO.class);

        List<FilterFolderPermissionsDTO> result = validateFoldersPermissions.validateFoldersPermissions(requestDTO.getFolderIdPathMap(), user, userDetails);
        exchange.getMessage().setBody(result);
    }
}
