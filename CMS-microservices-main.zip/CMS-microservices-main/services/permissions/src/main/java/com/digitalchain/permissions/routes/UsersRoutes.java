package com.digitalchain.permissions.routes;

import com.digitalchain.permissions.config.BaseRouteBuilder;
import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

@Component
public class UsersRoutes extends BaseRouteBuilder {

    @Override
    public void configure() throws Exception {
        super.configure();
        // Define a route to call the external API to get folder details
        from("direct:getGroupsDetails")
                .routeId("getGroupsDetails")
                .setHeader(Exchange.HTTP_METHOD, constant("GET"))
                .setHeader(Exchange.HTTP_URI, simple("{{application.config.users-url}}/groups/${header.groupId}"))
                .setHeader("Authorization", simple("${header.jwtToken}"))
                .toD("http://dummyhost") // Use http4 component, the actual URI is set in HTTP_URI header
                .choice()
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(200))
                .log("Group details retrieved successfully")
                .setBody(simple("${body}")) // Keep the response body as is
                .otherwise()
                .log("Failed to retrieve group details or group does not exist")
                .setBody(constant(null)); // Set the body to null if the folder is not found

        from("direct:getUsersDetails")
                .routeId("getUsersDetails")
                .setHeader(Exchange.HTTP_METHOD, constant("GET"))
                .setHeader(Exchange.HTTP_URI, simple("{{application.config.users-url}}/${header.userId}"))
                .log("{{application.config.users-url}}/${header.userId}")
                .setHeader("Authorization", simple("${header.jwtToken}"))
                .toD("http://dummyhost") // Use http4 component, the actual URI is set in HTTP_URI header
                .choice()
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(200))
                .log("User details retrieved successfully")
                .setBody(simple("${body}")) // Keep the response body as is
                .otherwise()
                .log("Failed to retrieve user details or user does not exist")
                .setBody(constant(null)); // Set the body to null if the folder is not found
    }
}
