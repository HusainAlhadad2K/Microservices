package com.digitalchain.permissions.dto;

import com.digitalchain.common.enums.permissions.Role;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;
import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PermissionRequestDTO {
    @NotNull
    private UUID folderId; // This can be folderId if the context is folder permissions

    @Valid
    private List<GroupPermissionDTO> groupPermissions; // List of group permissions

    @Valid
    private List<UserPermissionDTO> userPermissions; // List of user-specific permissions
}

