package com.digitalchain.permissions.service;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.common.dto.users.GroupResponseDTO;
import com.digitalchain.common.enums.permissions.Role;
import com.digitalchain.permissions.dto.GroupPermissionDTO;
import com.digitalchain.permissions.dto.PermissionRequestDTO;
import com.digitalchain.permissions.dto.PermissionsResponseDTO;
import com.digitalchain.permissions.dto.UserPermissionDTO;
import com.digitalchain.permissions.exception.ResourceNotFoundException;
import com.digitalchain.permissions.model.GroupPermissions;
import com.digitalchain.permissions.model.UserPermissions;
import com.digitalchain.permissions.repository.GroupPermissionsRepository;
import com.digitalchain.permissions.repository.UserPermissionsRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class PermissionsService {

    @Autowired
    private GroupPermissionsRepository groupPermissionsRepository;
    @Autowired
    private UserPermissionsRepository userPermissionsRepository;

    @Autowired
    private FoldersService foldersService;

    @Autowired
    private UsersService usersService;

    // Function to edit group and user permissions on a folder
    @Transactional
    public void updateFolderPermissions(PermissionRequestDTO permissionRequestDTO, UserDTO user) {
        UUID folderId = permissionRequestDTO.getFolderId();
        log.info("Updating permissions for folderId: {} by user: {}", folderId, user.getUser_id());

        FolderDTO folder = foldersService.getFolderDetails(folderId, user);
        log.info("Got folder {}", folder);
        String folderPath = folder.getFolderPath();


        log.debug("Deleting existing permissions for folderId: {}", folderId);
        groupPermissionsRepository.deleteByFolderId(folderId);
        userPermissionsRepository.deleteByFolderId(folderId);
        log.info("Deleted existing permissions for folderId: {}", folderId);

        // Step 2: Update group permissions if provided
        Set<String> allUserIds = null;
        if (!permissionRequestDTO.getGroupPermissions().isEmpty()) {
            allUserIds = verifyGroups(permissionRequestDTO.getGroupPermissions(), user);

            log.info("Updating group permissions for folderId: {}", folderId);
            List<GroupPermissions> updatedGroupPermissions = updateGroupPermissions(permissionRequestDTO.getGroupPermissions(), folderId, folderPath, user);
            log.debug("Updated group permissions: {}", updatedGroupPermissions);
        } else {
            log.info("No group permissions provided for folderId: {}", folderId);
        }

        // Step 3: Update user-specific permissions if provided
        if (!permissionRequestDTO.getUserPermissions().isEmpty()) {
            verifyUsers(allUserIds, permissionRequestDTO.getUserPermissions(), user);

            log.info("Updating user permissions for folderId: {}", folderId);
            List<UserPermissions> updatedUserPermissions = updateUserPermissions(permissionRequestDTO.getUserPermissions(), folderId, folderPath, user);
            log.debug("Updated user permissions: {}", updatedUserPermissions);
        } else {
            log.info("No user permissions provided for folderId: {}", folderId);
        }

        log.info("Completed updating permissions for folderId: {}", folderId);
    }

    // Function to edit group-specific permissions on a folder
    @Transactional
    private List<GroupPermissions> updateGroupPermissions(List<GroupPermissionDTO> groupPermissionDTO, UUID folderId, String folderPath, UserDTO user) {
        List<GroupPermissions> groupPermissionsList = groupPermissionDTO.stream()
                .map(permissionDTO -> GroupPermissions.builder()
                        .folderId(folderId)
                        .groupId(permissionDTO.getGroupId())
                        .role(permissionDTO.getRole())
                        .folderPath(folderPath)
                        .createdAt(new Date())
                        .createdBy(user.getUser_id())
                        .build())
                .toList();

        log.debug("Saving group permissions for folderId: {}", folderId);
        return groupPermissionsRepository.saveAll(groupPermissionsList);
    }

    // Function to edit user-specific permissions (exceptions) on a folder
    @Transactional
    private List<UserPermissions> updateUserPermissions(List<UserPermissionDTO> userPermissionDTO, UUID folderId, String folderPath, UserDTO user) {
        List<UserPermissions> userPermissionsList = userPermissionDTO.stream()
                .map(permissionDTO -> UserPermissions.builder()
                        .folderId(folderId)
                        .role(permissionDTO.getRole())
                        .userId(permissionDTO.getUserId())
                        .folderPath(folderPath)
                        .createdAt(new Date())
                        .createdBy(user.getUser_id())
                        .build())
                .toList();

        log.debug("Saving user permissions for folderId: {}", folderId);
        return userPermissionsRepository.saveAll(userPermissionsList);
    }

    private Set<String> verifyGroups(List<GroupPermissionDTO> groupPermissionDTO, UserDTO user){
        Set<String> allUserIds = new HashSet<>();

        groupPermissionDTO.forEach(
                groupPermission -> {
                    GroupResponseDTO group = usersService.getGroupDetails(groupPermission.getGroupId(), user);
                    allUserIds.addAll(group.getUserIds());
                }
        );

        return allUserIds;
    }
    private void verifyUsers(Set<String> allUserIds, List<UserPermissionDTO> userPermissions, UserDTO user){
        userPermissions.forEach(
                permission -> {
                    if (!allUserIds.contains(permission.getUserId())){
                        usersService.getUserDetails(permission.getUserId(), user);
                    }
                }
        );
    }

    public PermissionsResponseDTO getPermissionsByFolderId(UUID folderId) {
        log.info("Retrieving permissions for folderId: {}", folderId);

        // Fetch group permissions for the folder
        List<GroupPermissions> groupPermissions = groupPermissionsRepository.findByFolderId(folderId);
        log.debug("Retrieved group permissions for folderId: {}: {}", folderId, groupPermissions);

        // Fetch user-specific permissions for the folder
        List<UserPermissions> userPermissions = userPermissionsRepository.findByFolderId(folderId);
        log.debug("Retrieved user permissions for folderId: {}: {}", folderId, userPermissions);

        // Build and return the PermissionsResponseDTO
        PermissionsResponseDTO responseDTO = PermissionsResponseDTO.builder()
                .groupPermissions(groupPermissions)
                .userPermissions(userPermissions)
                .build();

        log.info("Completed retrieving permissions for folderId: {}", folderId);
        return responseDTO;
    }
}
