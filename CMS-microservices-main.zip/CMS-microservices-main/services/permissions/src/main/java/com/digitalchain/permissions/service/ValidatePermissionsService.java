package com.digitalchain.permissions.service;


import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.users.GroupDTO;
import com.digitalchain.common.dto.users.UserDetailsDTO;
import com.digitalchain.common.dto.permissions.FilterFolderPermissionsDTO;
import com.digitalchain.common.enums.permissions.Role;
import com.digitalchain.permissions.model.GroupPermissions;
import com.digitalchain.permissions.model.UserPermissions;
import com.digitalchain.permissions.repository.GroupPermissionsRepository;
import com.digitalchain.permissions.repository.UserPermissionsRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ValidatePermissionsService {

    @Autowired
    private UserPermissionsRepository userPermissionsRepository;

    @Autowired
    private GroupPermissionsRepository groupPermissionsRepository;

    @Autowired
    private UsersService usersService;

    /**
     * Validates folder permissions for a user based on individual user and group permissions.
     *
     * @param folderIdsPathMap List of folder IDs to validate.
     * @param user             The user whose permissions are being validated.
     * @return List of FilterFolderPermissionsDTO containing folder access details.
     */
    public List<FilterFolderPermissionsDTO> validateFoldersPermissions(Map<UUID, String> folderIdsPathMap, UserDTO user, UserDetailsDTO userDetails) {
        List<UUID> folderIds = new ArrayList<>(folderIdsPathMap.keySet());

        log.info("Validating folder permissions for user: {} with {} folders", user.getUser_id(), folderIds.size());

        List<FilterFolderPermissionsDTO> permissions = new ArrayList<>();

        if (Objects.equals(user.getUserRole(), "Admin")) {
            folderIds.forEach(folderId ->
                    permissions.add(new FilterFolderPermissionsDTO(folderId, Role.ADMIN))
            );
            log.info("User {} is an Admin. Granted Admin access to all folders.", user.getUser_id());
            return permissions; // Return early since all folders are covered
        }

        // Validate user-specific permissions
        List<UUID> remainingFolderIds = validateUserPermissions(folderIds, folderIdsPathMap, user, permissions);

        // Validate group-specific permissions for folders not covered by user permissions
        validateGroupPermissions(remainingFolderIds, folderIdsPathMap, user, permissions, userDetails);

        log.info("Completed validation for user: {}. Total permissions: {}", user.getUser_id(), permissions.size());
        return permissions;
    }

    private List<UUID> validateUserPermissions(List<UUID> folderIds, Map<UUID, String> folderIdsPathMap, UserDTO user, List<FilterFolderPermissionsDTO> permissions) {
        if (folderIds.isEmpty()) {
            return folderIds;
        }

        log.debug("Fetching user-specific permissions for user: {} and folders: {}", user.getUser_id(), folderIds);
        List<UserPermissions> userPermissions = userPermissionsRepository.findByFolderIdsAndUserId(folderIds, user.getUser_id());

        Set<UUID> foldersWithPermissions = userPermissions.stream()
                .map(UserPermissions::getFolderId)
                .collect(Collectors.toSet());

        List<UUID> foldersWithoutPermissions = getFoldersWithoutPermissions(folderIds, foldersWithPermissions);

        // Validate by path for folders without permissions
        validateByPath(foldersWithoutPermissions, folderIdsPathMap, permissions, true);

        // Add the user-specific permissions to the permissions list
        userPermissions.forEach(perm -> {
            permissions.add(new FilterFolderPermissionsDTO(perm.getFolderId(), perm.getRole()));
            log.debug("Added user permission for folderId: {} with role: {}", perm.getFolderId(), perm.getRole());
        });

        return foldersWithoutPermissions;
    }


    private void validateGroupPermissions(List<UUID> folderIds, Map<UUID, String> folderIdsPathMap, UserDTO user, List<FilterFolderPermissionsDTO> permissions, UserDetailsDTO userDetails) {
        if (folderIds.isEmpty()) {
            return;
        }

        log.debug("Fetching group-specific permissions for user: {}", user.getUser_id());
//        UserDetailsDTO userDetails = usersService.getUserDetails(user.getUser_id(), user);
        List<String> groupIds = getUserGroupAndPositionIds(userDetails);

        List<GroupPermissions> groupPermissions = groupPermissionsRepository.findByFolderIdsAndGroupIds(folderIds, groupIds);

        Set<UUID> foldersWithPermissions = groupPermissions.stream()
                .map(GroupPermissions::getFolderId)
                .collect(Collectors.toSet());

        List<UUID> foldersWithoutPermissions = getFoldersWithoutPermissions(folderIds, foldersWithPermissions);

        // Validate by path for folders without permissions
        validateByPath(foldersWithoutPermissions, folderIdsPathMap, permissions, false);

        // Add the group-specific permissions to the permissions list
        groupPermissions.forEach(perm -> {
            permissions.add(new FilterFolderPermissionsDTO(perm.getFolderId(), perm.getRole()));
            log.debug("Added group permission for folderId: {} with role: {}", perm.getFolderId(), perm.getRole());
        });
    }

    private List<UUID> getFoldersWithoutPermissions(List<UUID> folderIds, Set<UUID> foldersWithPermissions) {
        return folderIds.stream()
                .filter(id -> !foldersWithPermissions.contains(id))
                .collect(Collectors.toCollection(ArrayList::new)); // Collect results into a mutable ArrayList
    }

    private void validateByPath(List<UUID> foldersWithoutPermissions, Map<UUID, String> folderIdsPathMap, List<FilterFolderPermissionsDTO> permissions, boolean isUserSpecific) {
        List<UUID> foldersToRemove = new ArrayList<>(); // List to keep track of folders that should be removed

        for (UUID folderId : foldersWithoutPermissions) {
            String folderPath = folderIdsPathMap.get(folderId);
            if (folderPath != null) {
                boolean hasAccess = checkAccessByPath(folderPath, isUserSpecific);
                if (hasAccess) {
                    if (isUserSpecific) {
                        foldersToRemove.add(folderId); // Mark the folder for removal
                    }

                    permissions.add(new FilterFolderPermissionsDTO(folderId, Role.VIEW));
                    log.debug("Granted access by path for folderId: {} with path: {}", folderId, folderPath);
                } else {
                    log.debug("No access granted by path for folderId: {} with path: {}", folderId, folderPath);
                }
            }
        }

        // Remove the folders that were validated by user path after the iteration
        if (!foldersToRemove.isEmpty()) foldersWithoutPermissions.removeAll(foldersToRemove);
    }

    private List<String> getUserGroupAndPositionIds(UserDetailsDTO userDetails) {
        List<String> groupIds = new ArrayList<>(userDetails.getGroups().stream().map(GroupDTO::getGroupId).toList());
        List<String> positionIds = userDetails.getPosition().stream().map(GroupDTO::getGroupId).toList();
        if (!positionIds.isEmpty()) {
            groupIds.addAll(positionIds);
        }
        return groupIds;
    }

    private boolean checkAccessByPath(String folderPath, boolean isUserSpecific) {
        return isUserSpecific
                ? userPermissionsRepository.existsByPathPrefixAndRoleNotNone(folderPath)
                : groupPermissionsRepository.existsByPathPrefixAndRoleNotNone(folderPath);
    }
}