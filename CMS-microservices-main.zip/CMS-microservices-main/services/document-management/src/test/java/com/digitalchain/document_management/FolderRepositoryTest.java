package com.digitalchain.document_management;

import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.repository.FoldersRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest()
public class FolderRepositoryTest {

    @Autowired
    private FoldersRepository foldersRepository;

    private UUID folderId;

    @BeforeEach
    public void setUp() {
        // Set a folder ID that you know exists and has subfolders in the database
        folderId = UUID.fromString("b8f08971-b7f4-4404-bcef-40f13de3ac6d");
    }

    @Test
    public void testFindFolderWithSubfolders() {
        // Fetch the folder using the custom query
        Folder folder = foldersRepository.findFolderWithFilesAndSubfolders(folderId);

        System.out.println(folder);

        // Assert that the folder is not null
        assertNotNull(folder, "Folder should not be null");

        // Assert that the folder has subfolders
        Set<Folder> subFolders = folder.getSub_folders();
        assertNotNull(subFolders, "Subfolders should not be null");

        // Assert that subfolders are fetched and not empty
        assertFalse(subFolders.isEmpty(), "Subfolders should not be empty");

        // Print out the subfolder details for debugging
        subFolders.forEach(subFolder -> {
            System.out.println("Subfolder ID: " + subFolder.getFolder_id());
            System.out.println("Subfolder Name: " + subFolder.getFolder_name());
        });
    }
}
