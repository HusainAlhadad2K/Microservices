package com.digitalchain.document_management;

import com.digitalchain.document_management.dto.folder.ParsedFolderDTO;
import com.digitalchain.document_management.service.folder.ExcelFolderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class ExcelFolderServiceTest {

    private ExcelFolderService excelFolderService;

    @BeforeEach
    void setUp() {
        excelFolderService = new ExcelFolderService();
    }

    @Test
    void testBuildFolderPath_SingleRootFolder() {
        // Test case with only one root folder
        List<ParsedFolderDTO> folderList = List.of(
                new ParsedFolderDTO("Root Folder 1", null)
        );

        String path = excelFolderService.buildFolderPath("Root Folder 1", folderList);
        assertEquals("", path, "Root folder should return its name followed by a slash");
    }

    @Test
    void testBuildFolderPath_NestedFolders() {
        // Test case with multiple nested folders
        List<ParsedFolderDTO> folderList = Arrays.asList(
                new ParsedFolderDTO("Root Folder 2", null),
                new ParsedFolderDTO("Sub Folder 1", "Root Folder 2"),
                new ParsedFolderDTO("Sub Folder 2", "Root Folder 2"),
                new ParsedFolderDTO("Sub Folder 3", "Sub Folder 1")
        );

        String path1 = excelFolderService.buildFolderPath("Sub Folder 1", folderList);
        assertEquals("Root Folder 2/", path1, "Sub Folder 1 path should be correct");

        String path2 = excelFolderService.buildFolderPath("Sub Folder 2", folderList);
        assertEquals("Root Folder 2/", path2, "Sub Folder 2 path should be correct");

        String path3 = excelFolderService.buildFolderPath("Sub Folder 3", folderList);
        assertEquals("Root Folder 2/Sub Folder 1/", path3, "Sub Folder 3 path should be correct");
    }

    @Test
    void testBuildFolderPath_FolderNotFound() {
        // Test case for folder not found
        List<ParsedFolderDTO> folderList = Arrays.asList(
                new ParsedFolderDTO("Root Folder 2", null),
                new ParsedFolderDTO("Sub Folder 1", "Root Folder 2")
        );

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                excelFolderService.buildFolderPath("Nonexistent Folder", folderList)
        );

        assertEquals("Folder not found: Nonexistent Folder", exception.getMessage());
    }

    @Test
    void testBuildFolderPath_CircularDependency() {
        // Test case for circular dependency detection
        List<ParsedFolderDTO> folderList = Arrays.asList(
                new ParsedFolderDTO("Root Folder", "Sub Folder"),
                new ParsedFolderDTO("Sub Folder", "Root Folder")
        );

        StackOverflowError error = assertThrows(StackOverflowError.class, () ->
                excelFolderService.buildFolderPath("Root Folder", folderList)
        );

        // StackOverflowError indicates that circular dependency is detected due to infinite recursion
        assertNotNull(error);
    }
}

