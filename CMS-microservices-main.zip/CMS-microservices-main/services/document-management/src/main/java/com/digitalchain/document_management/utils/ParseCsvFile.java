package com.digitalchain.document_management.utils;

import com.digitalchain.document_management.dto.folder.ParsedFolderDTO;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeBodyPart;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


@Slf4j

public class ParseCsvFile {
    public static List<ParsedFolderDTO> parse(InputStream file) throws MessagingException, IOException {
        List<ParsedFolderDTO> parsedFolderDTOS = new ArrayList<>();
        log.info("Starting process to parse folders from Excel file");

        try (InputStream inputStream = file;
             InputStreamReader reader = new InputStreamReader(inputStream)) {

            // Define the format for the CSV file and parse it
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT
                    .builder()
                    .setHeader()
                    .setIgnoreEmptyLines(true)
                    .setTrim(true)
                    .build()
            );

            // Iterate over CSV records
            for (CSVRecord record : csvParser) {
                parsedFolderDTOS.add(
                        ParsedFolderDTO.builder()
                                .folderName(record.get(0).trim()) // First column: Folder Name
                                .parentFolderName((record.size() > 1 && !record.get(1).trim().isEmpty()) ? record.get(1).trim() : null) // Second column: Parent Folder Name
                                .build()
                );
            }

        }
        return parsedFolderDTOS;
    }
}