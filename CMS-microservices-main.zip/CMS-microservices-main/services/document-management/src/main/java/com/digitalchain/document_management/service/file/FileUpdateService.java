package com.digitalchain.document_management.service.file;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.document_management.config.OCIConfig;
import com.digitalchain.document_management.dto.file.SensitivityRequestDTO;
import com.digitalchain.document_management.exception.FileLockedException;
import com.digitalchain.document_management.exception.ResourceNotFoundException;
import com.digitalchain.document_management.model.document.File;
import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.repository.FilesRepository;
import com.digitalchain.document_management.repository.FoldersRepository;
import com.digitalchain.document_management.utils.FileLogger;
import com.digitalchain.document_management.utils.oci.OciObjectStorageUtil;
import com.oracle.bmc.objectstorage.responses.GetObjectResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
@Slf4j
public class FileUpdateService {

    @Autowired
    private FilesRepository filesRepository;

    @Autowired
    private FoldersRepository foldersRepository;

    @Autowired
    private OciObjectStorageUtil ociObjectStorageUtil;

    @Autowired
    private FileVersionService fileVersionService;

    @Autowired
    private OCIConfig ociConfig;

    @Autowired
    private FileLogger fileLogger;

    // Move file operation
    public String moveFile(UUID fileId, UUID destinationFolderId, UserDTO user) throws Exception {
        log.info("Initiating move operation for file with ID: {} to destination folder with ID: {}", fileId, destinationFolderId);

        File file = filesRepository.findById(fileId).orElseThrow(() -> new ResourceNotFoundException("File not found"));
        if (file.getIsLocked()){
            throw new FileLockedException("File is locked and cannot be moved.");
        }

        UUID previousVersionId = file.getLatestVersionId();

        Folder folder = null;
        if (destinationFolderId != null){
            folder = foldersRepository.findById(destinationFolderId).orElseThrow(() -> new ResourceNotFoundException("Destination folder not found"));
        }

        String newPath = constructCloudFileName(folder, file.getFile_name());
        String folderName = folder == null ? "Root" : folder.getFolder_name();

        try {
            GetObjectResponse copiedFile = ociObjectStorageUtil.moveObject(
                    ociConfig.getObjectStorageBucket(),
                    file.getFile_path(),
                    ociConfig.getObjectStorageBucket(),
                    newPath
            );

            updateFileRecordAfterMove(file, folder, newPath, UUID.fromString(copiedFile.getVersionId()), user);

            fileVersionService.createFileVersion(file, UUID.fromString(copiedFile.getVersionId()), previousVersionId, newPath, null, null);

            fileLogger.log(file, FileLogAction.MOVE, user);

            log.info("File '{}' successfully moved to folder '{}'", file.getFile_name(), folderName);
        } catch (Exception e) {
            log.error("Error moving file '{}' to folder '{}'. Error: {}", file.getFile_path(), folderName, e.getMessage(), e);
            throw new RuntimeException("Error moving file: " + e.getMessage(), e);
        }

        return "File moved successfully to folder: " + folderName;
    }

    // Rename file operation
    public String renameFile(UUID fileId, String newFileName, UserDTO user) throws Exception {
        log.info("Initiating rename operation for file with ID: {} to new name: {}", fileId, newFileName);

        File file = filesRepository.findById(fileId).orElseThrow(() -> new ResourceNotFoundException("File not found"));

        if (file.getIsLocked()){
            throw new FileLockedException("File is locked and cannot be renamed.");
        }

        UUID previousVersionId = file.getLatestVersionId();

        String path = file.getFolder() == null ? "/" : file.getFolder().getFolderPath();
        String newPath = path + newFileName;

        try {
            // Move the file with a new name in the same location
            String renamedFileVersion = ociObjectStorageUtil.renameFile(
                    ociConfig.getObjectStorageBucket(),
                    file.getFile_path(),
                    newPath
            );

            file.setFile_name(newFileName);
            file.setFile_path(newPath);
            file.setLatestVersionId(UUID.fromString(renamedFileVersion));
            file.setUpdated_at(new Date());
            file.setUpdatedBy(user.getUser_id());
            filesRepository.save(file);

            fileVersionService.createFileVersion(file, UUID.fromString(renamedFileVersion), previousVersionId, newPath, null, null);

            fileLogger.log(file, FileLogAction.RENAME, user);

            log.info("File '{}' successfully renamed to '{}'", file.getFile_name(), newFileName);
        } catch (Exception e) {
            log.error("Error renaming file '{}' to '{}'. Error: {}", file.getFile_path(), newFileName, e.getMessage(), e);
            throw new RuntimeException("Error renaming file: " + e.getMessage(), e);
        }

        return "File renamed successfully to: " + newFileName;
    }

    // Lock file operation
    public String lockFile(UUID fileId, Boolean lock, UserDTO user) {
        log.info("Locking file with ID: {}", fileId);

        File file = filesRepository.findById(fileId).orElseThrow(() -> new ResourceNotFoundException("File not found"));

        // Implement your locking logic here
        file.setIsLocked(lock);
        file.setLockedAt(new Date());
        file.setLockedBy(user.getUser_id());

        filesRepository.save(file);

        log.info("File '{}' locked successfully.", file.getFile_name());

        return "File locked successfully.";
    }
    public String sensitiveFile(UUID fileId, SensitivityRequestDTO sensitivityRequestDTO, UserDTO user) {
        log.info("Marking as sensitive file with ID: {}", fileId);

        File file = filesRepository.findById(fileId).orElseThrow(() -> new ResourceNotFoundException("File not found"));

        // Implement your locking logic here
        file.setIsSensitive(sensitivityRequestDTO.isSensitive());
        file.setSensitivityScale(sensitivityRequestDTO.getSensitivityScale());
        file.setMarkedAsSensitiveAt(new Date());
        file.setMarkedAsSensitiveBy(user.getUser_id());

        filesRepository.save(file);

        log.info("File '{}' marked as sensitive successfully.", file.getFile_name());

        return "File marked as sensitive successfully.";
    }

    // Utility method to construct cloud file name
    private String constructCloudFileName(Folder folder, String fileName) {
        return (folder != null ? folder.getFolderPath() : "/") + fileName;
    }

    // Update file record after move or rename
    private void updateFileRecordAfterMove(File file, Folder folder, String newPath, UUID newVersionId, UserDTO user) {
        file.setFile_path(newPath);
        file.setFolder(folder);
        file.setLatestVersionId(newVersionId);
        file.setUpdatedBy(user.getUser_id());
        file.setUpdated_at(new Date());
        filesRepository.save(file);
    }
}
