package com.digitalchain.document_management.dto.folder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FolderVersionDTO {
    private UUID versionId;
    private UUID folderId;
    private int versionNumber;
    private String folderPath;
    private String folderName;
    private Boolean deleted;
    private Date deletedAt;
    private Date createdAt;
    private Date updatedAt;
}
