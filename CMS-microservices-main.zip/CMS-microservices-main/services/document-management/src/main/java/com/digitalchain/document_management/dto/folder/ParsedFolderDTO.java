package com.digitalchain.document_management.dto.folder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParsedFolderDTO {
    private String folderName;
    private String parentFolderName;
}
