package com.digitalchain.document_management.service.folder;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.common.dto.permissions.FilterFolderPermissionsDTO;
import com.digitalchain.common.enums.permissions.Role;
import com.digitalchain.document_management.dto.folder.CreateFolderDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.document_management.exception.ResourceNotFoundException;
import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.repository.FilesRepository;
import com.digitalchain.document_management.repository.FileVersionRepository;
import com.digitalchain.document_management.repository.FoldersRepository;
import com.digitalchain.document_management.service.PermissionsService;
import com.digitalchain.document_management.service.file.DeleteFilesService;
import com.digitalchain.document_management.utils.FileLogger;
import com.digitalchain.document_management.utils.oci.ObjectRetrievalMode;
import com.digitalchain.document_management.utils.oci.OciObjectStorageUtil;
import com.digitalchain.document_management.config.OCIConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
@Slf4j
@Transactional
public class FoldersService {

    @Autowired
    private FoldersRepository foldersRepository;

    @Autowired
    private FilesRepository filesRepository;

    @Autowired
    private FileVersionRepository fileVersionRepository;

    @Autowired
    private OciObjectStorageUtil ociObjectStorageUtil;

    @Autowired
    private DeleteFilesService deleteFilesService;

    @Autowired
    private OCIConfig ociConfig;

    @Autowired
    private FileLogger fileLogger;

    @Autowired
    private PermissionsService permissionsService;

    public Folder createFolder(CreateFolderDTO request, UserDTO user) {
        Folder folder = new Folder();
        folder.setFolder_name(request.getFolderName());
        folder.setUser_id(user.getUser_id());
        folder.setFolderPath(request.getFolderName() + "/");
        folder.setIsProject(request.isProject());

        log.debug("Creating folder with name: {}, userId: {}, parentFolderId: {}", request.getFolderName(), user.getUser_id(), request.getParentFolderId());

        if (request.getParentFolderId() != null) {
            log.debug("Looking for parent folder with ID: {}", request.getParentFolderId());
            Folder parentFolder = foldersRepository.findById(request.getParentFolderId())
                    .orElseThrow(() -> new ResourceNotFoundException("Parent folder not found"));
            folder.setParent_folder(parentFolder);
            folder.setFolderPath(parentFolder.getFolderPath() + folder.getFolder_name() + "/");
            log.debug("Parent folder found: {}", parentFolder.getFolder_name());
        }

        FolderDTO folderDTO = foldersRepository.findFolderByPath(folder.getFolderPath());
        if (folderDTO != null) {
            throw new IllegalArgumentException("Folder already exists for given path: " + folderDTO.getFolderPath());
        }

        log.debug("Saving new folder to the database");
        Folder savedFolder = foldersRepository.save(folder);
        log.debug("Folder successfully created with ID: {}", savedFolder.getFolder_id());

        // Create the folder in OCI
        createFolderInOCI(savedFolder.getFolder_name(), savedFolder.getFolderPath());

        fileLogger.log(folder, FileLogAction.CREATE_FOLDER, user);

        return savedFolder;
    }

    private void createFolderInOCI(String folderName, String folderPath) {
        try {
            String compartmentId = ociConfig.getCompartmentId();
            String bucketName = ociConfig.getObjectStorageBucket();

            log.debug("Creating bucket if not exists in OCI for folder: {}", folderName);
            ociObjectStorageUtil.createBucketIfNotExists(compartmentId, bucketName);

            log.debug("Creating folder structure in OCI bucket '{}'", bucketName);
            ociObjectStorageUtil.createFolder(bucketName, folderPath);

            log.debug("Folder '{}' created in OCI bucket '{}'", folderName, bucketName);
        } catch (Exception e) {
            log.error("Failed to create folder in OCI", e);
            throw new RuntimeException("Failed to create folder in OCI", e);
        }
    }

    public FolderDTO getFolderById(UUID id) {
        return foldersRepository.findFolderById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Folder with ID " + id + " not found"));
    }

    public List<FolderDTO> getAllFolders(UUID parentFolderId, String folderName, UserDTO user) throws IllegalAccessException {
        List<FolderDTO> folders = foldersRepository.findFoldersByParentFolderId(parentFolderId, folderName);

//        folders = filterFoldersByPermission(folders, user);

        for (FolderDTO folder : folders) {
            boolean hasSubFolders = foldersRepository.existsByParentFolderId(folder.getFolderId());
            folder.setExpandable(hasSubFolders);
        }

        return folders;
    }

    private List<FolderDTO> filterFoldersByPermission(List<FolderDTO> folders, UserDTO user) throws IllegalAccessException {
        Map<UUID, String> folderIdPathMap = folders.stream()
                .collect(Collectors.toMap(FolderDTO::getFolderId, FolderDTO::getFolderPath));

        List<FilterFolderPermissionsDTO> filterFolderPermissionsDTOS = permissionsService.validateFolderAccess(folderIdPathMap, user);

        if (filterFolderPermissionsDTOS.isEmpty()) return folders;

        Map<UUID, Role> folderPermissionsMap = filterFolderPermissionsDTOS.stream()
                .collect(Collectors.toMap(FilterFolderPermissionsDTO::getFolderId, FilterFolderPermissionsDTO::getRole));

        // Filter the folders based on the permissions and set the role field
        return folders.stream()
                .filter(folder -> folderPermissionsMap.containsKey(folder.getFolderId())) // Only keep folders with permissions
                .filter(folder -> !folderPermissionsMap.get(folder.getFolderId()).equals(Role.NONE)) // Filter out folders with role "NONE"
                .peek(folder -> folder.setRole(folderPermissionsMap.get(folder.getFolderId()))) // Set the role for the folder
                .toList();
    }

    public ByteArrayOutputStream downloadFolderAsZip(UUID folderId, UserDTO user, boolean includeSubFolders) {
        try {
            Folder folder = foldersRepository.findById(folderId).orElseThrow(
                    () -> new ResourceNotFoundException("Folder not found")
            );

            Folder parentFolder = folder.getParent_folder();
            String folderPath = folder.getFolderPath();

            List<String> objectNames = null;

            if (includeSubFolders) {
                objectNames = ociObjectStorageUtil.listObjectsInFolder(ociConfig.getObjectStorageBucket(), folderPath, ObjectRetrievalMode.ALL, null);
            } else {
                objectNames = ociObjectStorageUtil.listObjectsInFolder(ociConfig.getObjectStorageBucket(), folderPath, ObjectRetrievalMode.FILES_ONLY, "/");
            }

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            try (ZipOutputStream zipOutputStream = new ZipOutputStream(byteArrayOutputStream)) {
                for (String objectName : objectNames) {
                    String entryName = objectName;
                    if (parentFolder != null) {
                        entryName = objectName.replaceFirst(parentFolder.getFolderPath(), "");
                    }
                    addObjectToZip(objectName, entryName, zipOutputStream);
                }
            }

            fileLogger.log(folder, FileLogAction.DOWNLOAD, user);

            return byteArrayOutputStream;
        } catch (Exception e) {
            log.error("Failed to download folder as zip for folder ID: {}", folderId, e);
            throw new RuntimeException("Failed to download folder as zip", e);
        }
    }

    private void addObjectToZip(String objectName, String entryName, ZipOutputStream zipOutputStream) throws IOException {
        try (InputStream inputStream = ociObjectStorageUtil.getObject(ociConfig.getObjectStorageBucket(), objectName, null).getInputStream()) {
            zipOutputStream.putNextEntry(new ZipEntry(entryName));

            byte[] buffer = new byte[1024];
            int len;
            while ((len = inputStream.read(buffer)) > 0) {
                zipOutputStream.write(buffer, 0, len);
            }

            zipOutputStream.closeEntry();
        } catch (Exception e) {
            log.error("Failed to add object to zip: {}", objectName, e);
            throw new IOException("Failed to add object to zip: " + objectName, e);
        }
    }
}

