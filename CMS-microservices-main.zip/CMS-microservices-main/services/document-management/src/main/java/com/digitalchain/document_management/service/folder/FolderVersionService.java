package com.digitalchain.document_management.service.folder;

import com.digitalchain.document_management.dto.folder.FolderVersionDTO;
import com.digitalchain.document_management.exception.ResourceNotFoundException;
import com.digitalchain.document_management.repository.FolderVersionRepository;
import com.digitalchain.document_management.repository.FoldersRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class FolderVersionService {

    @Autowired
    private FolderVersionRepository folderVersionRepository;

    @Autowired
    private FoldersRepository foldersRepository;

    /**
     * Retrieves all versions of a specified folder.
     *
     * @param folderId The UUID of the folder.
     * @return A list of FolderVersionDTOs representing all versions of the folder.
     * @throws Exception if the folder does not exist or any other error occurs.
     */
    public List<FolderVersionDTO> getFolderVersions(UUID folderId) throws Exception {
        // Check if the folder exists
        if (foldersRepository.findById(folderId).isEmpty()) {
            throw new ResourceNotFoundException(String.format("Folder with id %s does not exist", folderId));
        }

        try {
            // Retrieve the folder versions
            return folderVersionRepository.findByFolderId(folderId);
        } catch (Exception e) {
            log.error("Error retrieving folder versions for folderId {}: {}", folderId, e.getMessage());
            throw new RuntimeException(e);
        }
    }
}
