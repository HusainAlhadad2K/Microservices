package com.digitalchain.document_management.repository;

import com.digitalchain.document_management.dto.folder.FolderVersionDTO;
import com.digitalchain.document_management.model.document.FolderVersion;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface FolderVersionRepository extends JpaRepository<FolderVersion, UUID> {

    @Query("SELECT new com.digitalchain.document_management.dto.folder.FolderVersionDTO(" +
            "fv.versionId, fv.folder.id, fv.versionNumber, fv.folderPath, fv.folderName, " +
            "fv.deleted, fv.deletedAt, fv.createdAt, fv.updatedAt) " +
            "FROM FolderVersion fv WHERE fv.folder.id = ?1")
    List<FolderVersionDTO> findByFolderId(UUID folderId);

    @Query("SELECT fv.versionNumber FROM FolderVersion fv WHERE fv.versionId = ?1")
    Optional<Integer> findVersionNumberById(UUID versionId);

    @Modifying
    @Transactional
    @Query("UPDATE FolderVersion fv SET fv.deleted = ?2, fv.deletedAt = ?3 WHERE fv.folder.id = ?1")
    void toggleFolderVersionsDeletion(UUID folderId, boolean deleted, Date deletedAt);
}
