package com.digitalchain.document_management.utils.oci;

import com.oracle.bmc.responses.AsyncHandler;

import java.util.concurrent.CountDownLatch;

public class ResponseHandler<IN, OUT> implements AsyncHandler<IN, OUT> {
    private OUT item;
    private Throwable failed = null;
    private final CountDownLatch latch = new CountDownLatch(1);

    public OUT waitForCompletion() throws Exception {
        latch.await();
        if (failed != null) {
            if (failed instanceof Exception) {
                throw (Exception) failed;
            }
            throw (Error) failed;
        }
        return item;
    }

    @Override
    public void onSuccess(IN request, OUT response) {
        item = response;
        latch.countDown();
    }

    @Override
    public void onError(IN request, Throwable error) {
        failed = error;
        latch.countDown();
    }
}
