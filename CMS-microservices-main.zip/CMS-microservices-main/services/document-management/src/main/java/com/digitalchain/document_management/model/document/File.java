package com.digitalchain.document_management.model.document;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;
import java.util.UUID;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "Files")
public class File {
    @Id
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @Fetch(FetchMode.JOIN)
    @JoinColumn(name = "folder_id", referencedColumnName = "folder_id")  // Make sure this references the correct column in Folder
    private Folder folder;

    @Column(name = "user_id")
    private String user_id;

    @Column(name = "file_name")
    private String file_name;

    @Column(name = "file_path")
    private String file_path;

    @Column(name = "file_type")
    private String file_type;

    @Column(name = "file_size")
    private String file_size;

    @Column(name = "latest_version_id")
    private UUID latestVersionId;

    @Column(name = "deleted")
    private Boolean deleted = false;

    @Column(name = "deleted_version_id")
    private UUID deletedVersionId;

    @Column(name = "deleted_at")
    private Date deletedAt;

    @Column(name = "deleted_by")
    private String deletedBy;

    @Column(name = "deleted_by_folder")
    private Boolean deletedByFolder;

    @Column(name = "restored_at")
    private Date restoredAt;

    @Column(name = "restored_by")
    private String restoredBy;

    @Column(name = "is_locked")
    private Boolean isLocked = false;
    @Column(name = "locked_by")
    private String lockedBy;
    @Column(name = "locked_at")
    private Date lockedAt;

    @Column(name = "is_sensitive")
    private Boolean isSensitive = false;
    @Column(name = "sensitivity_scale")
    private Integer sensitivityScale = 0;

    @Column(name = "marked_as_sensitive_by")
    private String markedAsSensitiveBy;
    @Column(name = "marked_as_sensitive_at")
    private Date markedAsSensitiveAt;

    @Column(name = "duplicated_count")
    private Integer duplicatedCount = 0;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date created_at;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updated_at;

    @Column(name = "updated_by")
    private String updatedBy;
}
