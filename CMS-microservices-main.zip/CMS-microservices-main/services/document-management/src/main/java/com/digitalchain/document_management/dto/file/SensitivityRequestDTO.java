package com.digitalchain.document_management.dto.file;


import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SensitivityRequestDTO {
    @NotNull
    private boolean sensitive = false;

    @Min(value = 0, message = "Sensitivity scale must be between 0 and 9")
    @Max(value = 9, message = "Sensitivity scale must be between 0 and 9")
    private Integer sensitivityScale;
}
