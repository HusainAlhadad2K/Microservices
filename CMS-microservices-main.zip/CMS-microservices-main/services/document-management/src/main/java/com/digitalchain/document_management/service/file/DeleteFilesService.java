package com.digitalchain.document_management.service.file;


import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.document_management.config.OCIConfig;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.document_management.exception.ResourceNotFoundException;
import com.digitalchain.document_management.repository.FileVersionRepository;
import com.digitalchain.document_management.repository.FilesRepository;
import com.digitalchain.document_management.repository.FoldersRepository;
import com.digitalchain.document_management.utils.FileLogger;
import com.digitalchain.document_management.utils.oci.OciObjectStorageUtil;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

@Service
public class DeleteFilesService {

    @Autowired
    FilesRepository filesRepository;

    @Autowired
    OciObjectStorageUtil ociObjectStorageUtil;


    @Autowired
    OCIConfig ociConfig;

    @Autowired
    FileVersionRepository fileVersionRepository;

    @Autowired
    FoldersRepository foldersRepository;

    @Autowired
    private FileLogger fileLogger;

    public Page<FileDTO> getDeletedFiles(int page, int size, String sortBy, String sortDirection) {
        Sort.Direction direction = Sort.Direction.fromString(sortDirection);
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));
        return filesRepository.findDeletedFiles(pageable);
    }

    @Transactional
    public void deleteObject(UUID objectId, UserDTO user) throws Exception {
        Optional<FileDTO> file = filesRepository.findFileById(objectId);

        if (file.isPresent()) {
            String versionId = ociObjectStorageUtil.deleteObject(ociConfig.getObjectStorageBucket(), file.get().getFilePath());

            toggleSoftDeleteObject(file.get(), user.getUser_id(), versionId);

            fileLogger.log(file.get(), FileLogAction.DELETE, user);
        } else {
            throw new ResourceNotFoundException("File not found");
        }
    }

    @Transactional
    public String restoreObject(UUID objectId, UserDTO user) throws Exception {
        FileDTO file = filesRepository.findDeletedFileById(objectId).orElseThrow(() -> new ResourceNotFoundException("File not found"));

        ociObjectStorageUtil.restoreObject(
                ociConfig.getObjectStorageBucket(),
                file.getFilePath(),
                String.valueOf(file.getDeletedVersionId())
        );

        filesRepository.restoreFile(file.getId(), new Date(), user.getUser_id());

        Optional<FolderDTO> folder = foldersRepository.findDeletedFolderById(file.getFolderId());
        if(folder.isPresent()){
            foldersRepository.restoreFolder(file.getFolderId(), new Date(), user.getUser_id());
        }

        fileLogger.log(file, FileLogAction.RESTORE, user);

        return "File restored successfully";
    }

    @Transactional
    public void permanentlyDeleteFile(UUID fileId, UserDTO user){
        FileDTO file = filesRepository.findDeletedFileById(fileId)
                .orElseThrow(() -> new ResourceNotFoundException("File not found"));

        fileVersionRepository.deleteByFileId(file.getId());
        filesRepository.deleteById(file.getId());
    }

    private void toggleSoftDeleteObject(FileDTO file, String userId, String versionId) throws Exception {
        try {
            Date now = new Date();

            filesRepository.deleteFile(file.getId(), now, userId, UUID.fromString(versionId));

            fileVersionRepository.toggleFileVersionsDeletion(file.getId(), true, now);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
