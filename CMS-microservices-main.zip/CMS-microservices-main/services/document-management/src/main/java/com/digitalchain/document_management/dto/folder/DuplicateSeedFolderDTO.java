package com.digitalchain.document_management.dto.folder;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class DuplicateSeedFolderDTO {
    private UUID targetFolderId;
    private String targetFolderName;
}
