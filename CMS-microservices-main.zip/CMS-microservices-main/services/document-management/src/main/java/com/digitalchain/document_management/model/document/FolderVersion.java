package com.digitalchain.document_management.model.document;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@Entity
@Table(name = "folder_versions")
public class FolderVersion {

    @Id
    @GeneratedValue
    private UUID versionId;

    @ManyToOne
    @JoinColumn(name = "folder_id", referencedColumnName = "folder_id")  // Corrected here
    private Folder folder;

    @Column(name = "version_number")
    private int versionNumber;

    @Column(name = "folder_path")
    private String folderPath;

    @Column(name = "folder_name")
    private String folderName;

    @Column(name = "deleted")
    private Boolean deleted = false;

    @Column(name = "deleted_at")
    private Date deletedAt;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updatedAt;
}
