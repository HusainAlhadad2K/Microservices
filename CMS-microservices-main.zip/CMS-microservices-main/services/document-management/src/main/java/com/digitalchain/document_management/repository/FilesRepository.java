package com.digitalchain.document_management.repository;

import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.document_management.model.document.File;
import jakarta.transaction.Transactional;
import org.apache.hc.client5.http.entity.mime.MultipartEntityBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface FilesRepository extends JpaRepository<File, UUID> {
    @EntityGraph(attributePaths = {"folder"})
    Optional<File> findById(UUID id);

    @Query("SELECT new com.digitalchain.common.dto.files.FileDTO(f.id, f.file_name, f.file_path, f.file_type, f.file_size, " +
            "COALESCE(f.folder.folder_id, null), COALESCE(f.folder.folder_name, 'Root'), COALESCE(f.folder.folderPath, ''), " +
            "f.latestVersionId, NULL, " +
            "new com.digitalchain.common.dto.files.LockInfoDTO(f.isLocked, f.lockedBy, f.lockedAt), " +
            "new com.digitalchain.common.dto.files.SensitivityInfoDTO(f.isSensitive, f.sensitivityScale, f.markedAsSensitiveBy, f.markedAsSensitiveAt), " +
            "f.user_id, f.created_at, f.updatedBy, f.updated_at) " +
            "FROM File f LEFT JOIN f.folder WHERE f.deleted = FALSE AND f.id = ?1")
    Optional<FileDTO> findFileById(UUID id);

    @Query("SELECT new com.digitalchain.common.dto.files.FileDTO(f.id, f.file_name, f.file_path, f.file_type, f.file_size, " +
            "COALESCE(f.folder.folder_id, null), COALESCE(f.folder.folder_name, 'Root'), COALESCE(f.folder.folderPath, ''), " +
            "f.latestVersionId, f.deletedVersionId, " +
            "new com.digitalchain.common.dto.files.LockInfoDTO(f.isLocked, f.lockedBy, f.lockedAt), " +
            "new com.digitalchain.common.dto.files.SensitivityInfoDTO(f.isSensitive, f.sensitivityScale, f.markedAsSensitiveBy, f.markedAsSensitiveAt), " +
            "f.user_id, f.created_at, f.updatedBy, f.updated_at) " +
            "FROM File f LEFT JOIN f.folder WHERE f.deleted = TRUE AND f.id = ?1")
    Optional<FileDTO> findDeletedFileById(UUID id);

    @Query("SELECT new com.digitalchain.common.dto.files.FileDTO(f.id, f.file_name, f.file_path, f.file_type, f.file_size, " +
            "COALESCE(f.folder.folder_id, null), COALESCE(f.folder.folder_name, 'Root'), COALESCE(f.folder.folderPath, ''), " +
            "f.latestVersionId, f.deletedVersionId, " +
            "new com.digitalchain.common.dto.files.LockInfoDTO(f.isLocked, f.lockedBy, f.lockedAt), " +
            "new com.digitalchain.common.dto.files.SensitivityInfoDTO(f.isSensitive, f.sensitivityScale, f.markedAsSensitiveBy, f.markedAsSensitiveAt), " +
            "f.user_id, f.created_at, f.updatedBy, f.updated_at) " +
            "FROM File f LEFT JOIN f.folder WHERE f.deleted = TRUE AND f.deletedByFolder != TRUE")
    Page<FileDTO> findDeletedFiles(Pageable pageable);


    @Query("SELECT new com.digitalchain.common.dto.files.FileDTO(f.id, f.file_name, f.file_path, f.file_type, f.file_size, " +
            "COALESCE(f.folder.folder_id, null), COALESCE(f.folder.folder_name, 'Root'), COALESCE(f.folder.folderPath, ''), " +
            "f.latestVersionId, NULL, " +
            "new com.digitalchain.common.dto.files.LockInfoDTO(f.isLocked, f.lockedBy, f.lockedAt), " +
            "new com.digitalchain.common.dto.files.SensitivityInfoDTO(f.isSensitive, f.sensitivityScale, f.markedAsSensitiveBy, f.markedAsSensitiveAt), " +
            "f.user_id, f.created_at, f.updatedBy, f.updated_at) " +
            "FROM File f LEFT JOIN f.folder WHERE f.deleted = FALSE AND f.file_path IN ?1")
    List<FileDTO> findFilesByPath(List<String> paths);


    @Query("SELECT f FROM File f " +
            "LEFT JOIN FETCH f.folder folder " +
            "LEFT JOIN FETCH folder.parent_folder parentFolder " +
            "WHERE f.file_name = :fileName " +
            "AND folder.folder_id = :folderId " +
            "AND f.deleted = FALSE")
    Optional<File> findFileByFilenameAndFolderId(@Param("fileName") String fileName, @Param("folderId") UUID folderId);


    @Modifying
    @Transactional
    @Query("UPDATE File f SET f.file_path = ?2, f.file_type = ?3, f.file_size = ?4, f.updated_at = ?5 WHERE f.id = ?1")
    void updateFileRecord(UUID fileId, String filePath, String fileType, String fileSize, Date updatedAt);

    @Modifying
    @Transactional
    @Query("UPDATE File f SET f.latestVersionId = ?2 WHERE f.id = ?1")
    void updateFileVersion(UUID fileId, UUID latestVersionId);

    @Modifying
    @Transactional
    @Query("UPDATE File f SET f.deleted = TRUE, f.deletedAt = ?2, f.deletedBy = ?3, f.deletedVersionId = ?4, f.deletedByFolder=false where f.id = ?1")
    void deleteFile(UUID fileId, Date deletedAt, String userId, UUID deletedVersionId);

    @Modifying
    @Transactional
    @Query("UPDATE File f SET f.deleted = TRUE, f.deletedAt = ?2, f.deletedBy = ?3, f.deletedVersionId = ?4, f.deletedByFolder=true where f.file_path = ?1")
    void deleteFileByPath(String filePath, Date deletedAt, String userId, UUID deletedVersionId);

    @Modifying
    @Transactional
    @Query("UPDATE File f SET f.deleted = FALSE, f.restoredAt = ?2, f.restoredBy = ?3 where f.id = ?1")
    void restoreFile(UUID fileId, Date restoredAt, String userId);

    @Query("SELECT new com.digitalchain.common.dto.files.FileDTO(f.id, f.file_name, f.file_path, f.file_type, f.file_size, " +
            "COALESCE(f.folder.folder_id, null), COALESCE(f.folder.folder_name, 'Root'), COALESCE(f.folder.folderPath, ''), " +
            "f.latestVersionId, NULL, " +
            "new com.digitalchain.common.dto.files.LockInfoDTO(f.isLocked, f.lockedBy, f.lockedAt), " +
            "new com.digitalchain.common.dto.files.SensitivityInfoDTO(f.isSensitive, f.sensitivityScale, f.markedAsSensitiveBy, f.markedAsSensitiveAt), " +
            "f.user_id, f.created_at, f.updatedBy, f.updated_at) " +
            "FROM File f LEFT JOIN f.folder WHERE f.file_path LIKE :folderPath")
    List<FileDTO> findFileByFolderPath(@Param("folderPath") String folderPath);

    void deleteById(UUID fileId);
}
