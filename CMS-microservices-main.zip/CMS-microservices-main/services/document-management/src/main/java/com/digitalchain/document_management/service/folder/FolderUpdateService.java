package com.digitalchain.document_management.service.folder;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.document_management.config.OCIConfig;
import com.digitalchain.document_management.dto.folder.CreateFolderDTO;
import com.digitalchain.document_management.exception.ResourceNotFoundException;
import com.digitalchain.document_management.model.document.File;
import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.repository.FoldersRepository;
import com.digitalchain.document_management.service.file.FileUpdateService;
import com.digitalchain.document_management.service.file.FilesService;
import com.digitalchain.document_management.utils.oci.OciObjectStorageUtil;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Objects;
import java.util.UUID;

@Service
@Slf4j
@Transactional
public class FolderUpdateService {

    @Autowired
    private FoldersRepository foldersRepository;

    @Autowired
    private FileUpdateService fileUpdateService;

    @Autowired
    private FilesService filesService;

    @Autowired
    private OciObjectStorageUtil ociObjectStorageUtil;

    @Autowired
    private OCIConfig ociConfig;

    @Autowired
    private FoldersService foldersService;

    public String moveFolder(UUID sourceFolderId, UUID destinationFolderId, UserDTO user, boolean isMove, boolean isRootOp, String newName) throws Exception {
        log.info("Starting to {} folder with ID: {} to destination folder with ID: {}", (isMove ? "move" : "copy"), sourceFolderId, destinationFolderId);

        // Find source and destination folders
        Folder sourceFolder = foldersRepository.findFolderWithFilesAndSubfolders(sourceFolderId);

        if (sourceFolder == null){
            throw new ResourceNotFoundException("Source folder does not exist");
        }

        Folder destinationFolder;
        if (destinationFolderId != null) {
            //todo validation for folders destination
            if (sourceFolderId.equals(destinationFolderId)) {
                throw new IllegalArgumentException("Source and destination can't be the same");
            }

            destinationFolder = foldersRepository.findById(destinationFolderId).orElseThrow(
                    () -> new ResourceNotFoundException("Destination folder not found")
            );
        } else if (isRootOp) {
            destinationFolder = null;
        } else {
            destinationFolder = sourceFolder.getParent_folder();
        }

        log.info("Source folder: {} found, Destination folder: {}", sourceFolder.getFolder_name(), destinationFolder != null ? destinationFolder.getFolder_name() : "Root");
        // Create a new folder in the destinxation folder
        Folder newFolder = createNewFolder(sourceFolder, destinationFolder, newName, user);

        log.info("Created new folder in destination with name: {}, new folder ID: {}", newFolder.getFolder_name(), newFolder.getFolder_id());

        // Move or copy files in the source folder to the new folder
        moveFiles(sourceFolder, newFolder, user, isMove);

        // Recursively move or copy subfolders
        moveSubFoldersRecursively(sourceFolder, newFolder, user, isMove);

        if (isMove) {
            // Delete the original source folder and its contents after moving
            log.info("Deleting source folder and contents after move.");
            deleteSourceFolder(sourceFolder);
        }

        log.info("Folder and all subfolders {} successfully from source folder ID: {} to destination folder ID: {}",
                (isMove ? "moved" : "copied"), sourceFolderId, destinationFolderId);

        return isMove ? "Moved folder and files successfully" : "Copied folder and files successfully";
    }

    private Folder createNewFolder(Folder sourceFolder, Folder destinationFolder, String folderName, UserDTO user) {
        UUID newFolderId = destinationFolder != null ? destinationFolder.getFolder_id() : null;
        log.debug("Creating new folder under destination folder: {}, source folder: {}",
                destinationFolder != null ? destinationFolder.getFolder_name() : "Root", sourceFolder.getFolder_name());

        // Check if the source folder is being duplicated in the same parent folder
        String newFolderName = folderName == null ? sourceFolder.getFolder_name() : folderName;

        boolean isValidFolderCondition = (sourceFolder.getParent_folder() == null && destinationFolder == null) ||
                (sourceFolder.getParent_folder() != null && sourceFolder.getParent_folder().getFolder_id().equals(newFolderId));

        if (isValidFolderCondition && Objects.equals(newFolderName, sourceFolder.getFolder_name())) {
            // Increment the duplicated count and update the folder name
            Integer duplicatedCount = sourceFolder.getDuplicatedCount() + 1;
            newFolderName = sourceFolder.getFolder_name() + "(" + duplicatedCount + ")";
            sourceFolder.setDuplicatedCount(duplicatedCount);
        }

        Folder newFolder = foldersService.createFolder(CreateFolderDTO.builder()
                .folderName(newFolderName)
                .parentFolderId(newFolderId)
                .build(), user);

        log.debug("New folder created with ID: {}, under destination folder ID: {}",
                newFolder.getFolder_id(), newFolderId);

        return newFolder;
    }


    private void moveFiles(Folder sourceFolder, Folder newFolder, UserDTO user, boolean isMove) throws Exception {
        UUID newFolderId = newFolder != null ? newFolder.getFolder_id() : null;
        log.debug("Moving/copying files from source folder ID: {} to new folder ID: {}", sourceFolder.getFolder_id(), newFolderId);

        for (File file : sourceFolder.getFiles()) {
            log.debug("Moving/copying file ID: {} from source folder ID: {} to new folder ID: {}", file.getId(), sourceFolder.getFolder_id(), newFolderId);

            // If this is a move operation, delete the original file after copying
            if (isMove) {
                fileUpdateService.moveFile(file.getId(), newFolderId, user);
            } else {
                filesService.copyFile(file.getId(), newFolderId, user);
            }
        }

        log.info("All files {} successfully from source folder ID: {} to new folder ID: {}",
                (isMove ? "moved" : "copied"), sourceFolder.getFolder_id(), newFolderId);
    }

    private void moveSubFoldersRecursively(Folder sourceFolder, Folder newFolder, UserDTO user, boolean isMove) throws Exception {
        UUID newFolderId = newFolder != null ? newFolder.getFolder_id() : null;
        log.debug("Moving/copying subfolders from source folder ID: {} to new folder ID: {}", sourceFolder.getFolder_id(), newFolderId);

        for (Folder subFolder : sourceFolder.getSub_folders()) {
            log.debug("Creating new subfolder for subfolder ID: {} under new folder ID: {}", subFolder.getFolder_id(), newFolderId);

            // Create a new subfolder under the newFolder
            Folder newSubFolder = createNewFolder(subFolder, newFolder, null, user);

            log.debug("New subfolder created with ID: {}", newSubFolder.getFolder_id());

            // Move or copy files from the subfolder to the newly created subfolder
            moveFiles(subFolder, newSubFolder, user, isMove);

            // Recursively move or copy the subfolders of this subfolder
            moveSubFoldersRecursively(subFolder, newSubFolder, user, isMove);
        }

        log.info("All subfolders {} successfully from source folder ID: {} to new folder ID: {}",
                (isMove ? "moved" : "copied"), sourceFolder.getFolder_id(), newFolderId);

        // If this is a move operation, delete the source folder
        if (isMove) {
            deleteSourceFolder(sourceFolder);
        }
    }

    private void deleteSourceFolder(Folder sourceFolder) throws Exception {
        // This method deletes the source folder after it has been moved
        log.info("Deleting source folder with ID: {}", sourceFolder.getFolder_id());

        // Delete the source folder from OCI Object Storage (if applicable)
        ociObjectStorageUtil.deleteFolder(ociConfig.getObjectStorageBucket(), sourceFolder.getFolderPath());

        // Delete the folder record from the database
        foldersRepository.delete(sourceFolder);

        log.info("Source folder deleted successfully.");
    }
}
