package com.digitalchain.document_management.utils.oci;

public enum ObjectRetrievalMode {
    FILES_ONLY,
    FOLDERS_ONLY,
    ALL
}
