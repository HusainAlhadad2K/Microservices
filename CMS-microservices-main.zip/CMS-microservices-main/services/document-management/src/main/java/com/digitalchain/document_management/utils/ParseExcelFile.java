package com.digitalchain.document_management.utils;

import com.digitalchain.document_management.dto.folder.ParsedFolderDTO;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeBodyPart;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class ParseExcelFile {
    public static List<ParsedFolderDTO> parse(InputStream file) throws MessagingException, IOException {
        List<ParsedFolderDTO> createFolderDTOList = new ArrayList<>();
        log.info("Starting process to parse folders from Excel file");

        // Read Excel data from the provided file
        try (InputStream inputStream = file) {
            Workbook workbook = WorkbookFactory.create(inputStream);
            Sheet sheet = workbook.getSheetAt(0);

            // Iterate over rows and skip the header (row 0)
            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // Skip header row

                // Add the parsed folder information (folder name and parent folder name) to the list
                createFolderDTOList.add(
                        ParsedFolderDTO.builder()
                                .folderName(getCellValue(row.getCell(0))) // Folder Name
                                .parentFolderName(getCellValue(row.getCell(1))) // Parent Folder Name
                                .build()
                );
            }

            // Create folders based on the parsed data
        } catch (Exception e) {
            log.error("Error processing Excel file for folder creation: {}", e.getMessage(), e);
            throw e;
        }

        return createFolderDTOList;
    }

    /**
     * Helper method to extract the value from an Excel cell.
     *
     * @param cell The Excel cell from which to extract the value.
     * @return The extracted value as a String.
     */
    private static String getCellValue(Cell cell) {
        if (cell == null) return null;
        // Extract the value based on the cell type (String or Numeric)
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue();
            case NUMERIC -> String.valueOf(cell.getNumericCellValue());
            default -> null;
        };
    }
}
