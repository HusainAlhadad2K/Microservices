package com.digitalchain.document_management.utils;

import lombok.Getter;
import org.springframework.http.MediaType;

@Getter
public enum FileMediaType {
    PDF("application/pdf", MediaType.APPLICATION_PDF),
    JPEG("image/jpeg", MediaType.IMAGE_JPEG),
    PNG("image/png", MediaType.IMAGE_PNG),
    GIF("image/gif", MediaType.IMAGE_GIF),
    HTML("text/html", MediaType.TEXT_HTML),
    TEXT_PLAIN("text/plain", MediaType.TEXT_PLAIN),
    OCTET_STREAM("application/octet-stream", MediaType.APPLICATION_OCTET_STREAM);

    private final String type;
    private final MediaType mediaType;

    FileMediaType(String type, MediaType mediaType) {
        this.type = type;
        this.mediaType = mediaType;
    }

    public static MediaType getMediaTypeFromType(String type) {
        for (FileMediaType fileMediaType : values()) {
            if (fileMediaType.getType().equalsIgnoreCase(type)) {
                return fileMediaType.getMediaType();
            }
        }
        return null;
    }
}
