package com.digitalchain.document_management.exception;

public class UnsupportedMediaTypeException extends RuntimeException {
    public UnsupportedMediaTypeException(String message){super(message);}
}
