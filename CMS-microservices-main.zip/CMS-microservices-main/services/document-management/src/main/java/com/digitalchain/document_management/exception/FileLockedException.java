package com.digitalchain.document_management.exception;

public class FileLockedException extends RuntimeException {
    public FileLockedException(String message) {
        super(message);
    }
}