package com.digitalchain.document_management.enums;

public enum FolderActions {
    MOVE,
    COPY,
    RENAME,
    DUPLICATE
}
