package com.digitalchain.document_management.dto.folder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SeedFolderDTO {
    private UUID folderId;
    private String folderName;
    private String userId;
    private Date createdAt;
    private Date updatedAt;
}
