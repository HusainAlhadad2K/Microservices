package com.digitalchain.document_management.repository;

import com.digitalchain.document_management.dto.folder.SeedFolderDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.document_management.model.document.Folder;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface  FoldersRepository extends JpaRepository<Folder, UUID> {
    @Query("SELECT new com.digitalchain.common.dto.folders.FolderDTO(f.folder_id, f.folder_name, " +
            "COALESCE(f.parent_folder.folder_id, null), COALESCE(f.parent_folder.folder_name, null), " +
            "f.folderPath, f.user_id, f.created_at, f.updated_at, f.isSeedFolder, " +
            "new com.digitalchain.common.dto.folders.ProjectInfoDTO(f.isProject, f.projectStatus, f.projectName, f.customerName, f.description, f.startDate, f.endDate, " +
            "f.addressLine1, f.addressLine2, f.city, f.state, f.country, f.zipCode, f.projectCreatedBy, f.projectCreatedAt)) " +
            "FROM Folder f LEFT JOIN f.parent_folder WHERE f.folder_id = ?1 AND f.deleted = false")
    Optional<FolderDTO> findFolderById(UUID folderId);

    @Query("SELECT new com.digitalchain.common.dto.folders.FolderDTO(f.folder_id, f.folder_name, " +
            "COALESCE(f.parent_folder.folder_id, null), COALESCE(f.parent_folder.folder_name, null), " +
            "f.folderPath, f.user_id, f.created_at, f.updated_at, f.isSeedFolder, " +
            "new com.digitalchain.common.dto.folders.ProjectInfoDTO(f.isProject, f.projectStatus, f.projectName, f.customerName, f.description, f.startDate, f.endDate, " +
            "f.addressLine1, f.addressLine2, f.city, f.state, f.country, f.zipCode, f.projectCreatedBy, f.projectCreatedAt)) " +
            "FROM Folder f LEFT JOIN f.parent_folder " +
            "WHERE (f.parent_folder.folder_id = ?1 OR (f.parent_folder.folder_id IS NULL AND ?1 IS NULL)) " +
            "AND (?2 IS NULL OR f.folder_name = ?2) " +
            "AND f.deleted = false")
    List<FolderDTO> findFoldersByParentFolderId(UUID parentFolderId, String folderName);

    @Query("SELECT new com.digitalchain.common.dto.folders.FolderDTO(f.folder_id, f.folder_name, " +
            "COALESCE(f.parent_folder.folder_id, null), COALESCE(f.parent_folder.folder_name, null), " +
            "f.folderPath, f.user_id, f.created_at, f.updated_at, f.isSeedFolder, " +
            "new com.digitalchain.common.dto.folders.ProjectInfoDTO(f.isProject, f.projectStatus, f.projectName, f.customerName, f.description, f.startDate, f.endDate, " +
            "f.addressLine1, f.addressLine2, f.city, f.state, f.country, f.zipCode, f.projectCreatedBy, f.projectCreatedAt)) " +
            "FROM Folder f LEFT JOIN f.parent_folder WHERE f.folderPath IN ?1 AND f.deleted = false")
    List<FolderDTO> findFoldersByPath(List<String> path);

    @Query("SELECT new com.digitalchain.common.dto.folders.FolderDTO(f.folder_id, f.folder_name, " +
            "COALESCE(f.parent_folder.folder_id, null), COALESCE(f.parent_folder.folder_name, null), " +
            "f.folderPath, f.user_id, f.created_at, f.updated_at, f.isSeedFolder, " +
            "new com.digitalchain.common.dto.folders.ProjectInfoDTO(f.isProject, f.projectStatus, f.projectName, f.customerName, f.description, f.startDate, f.endDate, " +
            "f.addressLine1, f.addressLine2, f.city, f.state, f.country, f.zipCode, f.projectCreatedBy, f.projectCreatedAt)) " +
            "FROM Folder f LEFT JOIN f.parent_folder WHERE f.folderPath = ?1 AND f.deleted = false")
    FolderDTO findFolderByPath(String path);

    @Query("SELECT new com.digitalchain.common.dto.folders.FolderDTO(f.folder_id, f.folder_name, " +
            "COALESCE(f.parent_folder.folder_id, null), COALESCE(f.parent_folder.folder_name, null), " +
            "f.folderPath, f.user_id, f.created_at, f.updated_at, f.isSeedFolder, " +
            "new com.digitalchain.common.dto.folders.ProjectInfoDTO(f.isProject, f.projectStatus, f.projectName, f.customerName, f.description, f.startDate, f.endDate, " +
            "f.addressLine1, f.addressLine2, f.city, f.state, f.country, f.zipCode, f.projectCreatedBy, f.projectCreatedAt)) " +
            "FROM Folder f LEFT JOIN f.parent_folder WHERE f.folder_id = ?1 AND f.deleted = true")
    Optional<FolderDTO> findDeletedFolderById(UUID folderId);

    @Query("SELECT new com.digitalchain.common.dto.folders.FolderDTO(f.folder_id, f.folder_name, " +
            "COALESCE(f.parent_folder.folder_id, null), COALESCE(f.parent_folder.folder_name, null), " +
            "f.folderPath, f.user_id, f.created_at, f.updated_at, f.isSeedFolder, " +
            "new com.digitalchain.common.dto.folders.ProjectInfoDTO(f.isProject, f.projectStatus, f.projectName, f.customerName, f.description, f.startDate, f.endDate, " +
            "f.addressLine1, f.addressLine2, f.city, f.state, f.country, f.zipCode, f.projectCreatedBy, f.projectCreatedAt)) " +
            "FROM Folder f LEFT JOIN f.parent_folder WHERE f.deleted = true AND f.deletedByFolder != TRUE")
    Page<FolderDTO> findAllDeletedFolders(Pageable pageable);

    @Query("SELECT new com.digitalchain.common.dto.folders.FolderDTO(f.folder_id, f.folder_name, " +
            "COALESCE(f.parent_folder.folder_id, null), COALESCE(f.parent_folder.folder_name, null), " +
            "f.folderPath, f.user_id, f.created_at, f.updated_at, f.isSeedFolder, " +
            "new com.digitalchain.common.dto.folders.ProjectInfoDTO(f.isProject, f.projectStatus, f.projectName, f.customerName, f.description, f.startDate, f.endDate, " +
            "f.addressLine1, f.addressLine2, f.city, f.state, f.country, f.zipCode, f.projectCreatedBy, f.projectCreatedAt)) " +
            "FROM Folder f LEFT JOIN f.parent_folder WHERE f.folder_name = :folderName AND f.folderPath IN :ociFolders AND f.deleted = false")
    List<FolderDTO> findFoldersByNameAndPath(@Param("folderName") String folderName, @Param("ociFolders") List<String> ociFolders);

    @Query("SELECT new com.digitalchain.document_management.dto.folder.SeedFolderDTO(" +
            "f.folder_id, " +
            "f.folder_name, " +
            "f.user_id, " +
            "f.created_at, " +
            "f.updated_at) " +
            "FROM Folder f " +
            "WHERE f.isSeedFolder = true")
    List<SeedFolderDTO> findAllSeedFolders();

    @Query("SELECT f FROM Folder f " +
            "LEFT JOIN FETCH f.files files " +
            "LEFT JOIN FETCH f.sub_folders subfolders " +
            "LEFT JOIN FETCH subfolders.files subfolderFiles " +
            "WHERE f.folder_id = ?1")
    Folder findFolderWithFilesAndSubfolders(UUID folderId);

    @Modifying
    @Transactional
    @Query("UPDATE Folder f SET f.isSeedFolder = ?2 WHERE f.id = ?1")
    void updateIsSeedFolder(UUID folderId, Boolean isSeedFolder);

    @Modifying
    @Transactional
    @Query("UPDATE Folder f SET f.deleted = TRUE, f.deletedAt = :deletedAt, f.deletedBy = :deletedBy, f.deletedByFolder = TRUE, f.deletedByFolderId = :folderId WHERE f.folderPath LIKE :folderPath AND f.folder_id != :folderId")
    void softDeleteFoldersByPath(@Param("folderPath") String folderPath, @Param("deletedAt") Date deletedAt, @Param("deletedBy") String deletedBy, @Param("folderId") UUID folderId);

    @Modifying
    @Transactional
    @Query("UPDATE Folder f SET f.deleted = TRUE, f.deletedAt = :deletedAt, f.deletedBy = :deletedBy WHERE f.folder_id = :id")
    void softDeleteFolderById(@Param("id") UUID folderId, @Param("deletedAt") Date deletedAt, @Param("deletedBy") String deletedBy);

    @Modifying
    @Transactional
    @Query("UPDATE Folder f SET f.deleted = FALSE, f.restoredAt = :restoredAt, f.restoredBy = :restoredBy WHERE f.folder_id = :id")
    void restoreFolder(@Param("id") UUID folderId, @Param("restoredAt") Date restoredAt, @Param("restoredBy") String restoredBy);

    @Modifying
    @Transactional
    @Query("UPDATE Folder f SET f.deleted = FALSE, f.restoredAt = :restoredAt, f.restoredBy = :restoredBy, f.deletedByFolder = FALSE, f.deletedByFolderId = NULL WHERE f.folderPath LIKE :folderPath AND f.deletedByFolderId = :folderId")
    void restoreFolderByPath(@Param("folderPath") String folderPath, @Param("folderId") UUID folderId, @Param("restoredAt") Date restoredAt, @Param("restoredBy") String restoredBy);

    @Query("SELECT CASE WHEN COUNT(f) > 0 THEN true ELSE false END FROM Folder f WHERE f.parent_folder.folder_id = :parentFolderId AND f.deleted = false")
    boolean existsByParentFolderId(@Param("parentFolderId") UUID parentFolderId);

    void deleteById(UUID folderId);
}
