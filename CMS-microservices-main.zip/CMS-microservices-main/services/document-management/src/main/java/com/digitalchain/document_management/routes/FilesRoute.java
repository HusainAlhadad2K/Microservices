package com.digitalchain.document_management.routes;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.document_management.config.BaseRouteBuilder;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.document_management.dto.file.FileDownloadDTO;
import com.digitalchain.document_management.dto.file.SensitivityRequestDTO;
import com.digitalchain.document_management.exception.UnsupportedMediaTypeException;
import com.digitalchain.document_management.model.document.File;
import com.digitalchain.document_management.model.document.FileVersion;
import com.digitalchain.document_management.service.file.DeleteFilesService;
import com.digitalchain.document_management.service.file.FileUpdateService;
import com.digitalchain.document_management.service.file.FileVersionService;
import com.digitalchain.document_management.service.file.FilesService;
import com.digitalchain.document_management.utils.FileMediaType;
import io.micrometer.core.instrument.util.IOUtils;
import jakarta.activation.DataHandler;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.transaction.Transactional;
import jakarta.validation.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.attachment.AttachmentMessage;
import org.apache.camel.converter.stream.InputStreamCache;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Component
@Slf4j
public class FilesRoute extends BaseRouteBuilder {

    @Autowired
    FilesService filesService;

    @Autowired
    FileUpdateService fileUpdateService;

    @Autowired
    DeleteFilesService deleteFilesService;

    @Autowired
    FileVersionService fileVersionService;

    @Override
    public void configure() throws Exception {
        super.configure();

        // Route for listing files
        rest("/files")
                .get()
                .description("List all files in the specified bucket and optional folder ID.")
                .param().name("folderId").type(RestParamType.query).description("The ID of the folder").dataType("UUID").required(false).endParam()
                .param().name("fileId").type(RestParamType.query).description("The ID of the file").dataType("UUID").required(false).endParam()
                .responseMessage().code(200).message("Files listed successfully").responseModel(FileDTO[].class).endResponseMessage()
                .to("direct:listFiles")

                .get("/deleted")
                .description("List all files in the specified bucket and optional folder ID.")
                .param().name("page").type(RestParamType.query).description("Page number to retrieve").dataType("Integer").required(false).endParam()
                .param().name("size").type(RestParamType.query).description("Number of records per page").dataType("Integer").required(false).endParam()
                .param().name("sortBy").type(RestParamType.query).description("Field to sort by").dataType("String").required(false).endParam()
                .param().name("sortDirection").type(RestParamType.query).description("Sort direction (ASC or DESC)").dataType("String").required(false).endParam()
                .responseMessage().code(200).message("Deleted files listed successfully").responseModel(FileDTO[].class).endResponseMessage()
                .to("direct:listDeletedFiles")

                .get("/{fileId}/versions")
                .description("List all versions of the specified file.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file").dataType("UUID").endParam()
                .responseMessage().code(200).message("File versions listed successfully").responseModel(FileVersion[].class).endResponseMessage()
                .to("bean:fileVersionService?method=getFileVersions(${header.fileId})")

                .get("/{fileId}")
                .description("Download a file from the specified bucket and object ID.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file").dataType("UUID").endParam()
                .param().name("versionId").type(RestParamType.query).description("Version ID, if null latest will be applied").required(false).endParam()
                .param().name("forceDownload").type(RestParamType.query).description("Whether to force download").dataType("boolean").defaultValue("true").required(false).endParam()
                .responseMessage().code(200).message("File downloaded successfully").responseModel(InputStreamResource.class).endResponseMessage()
                .to("direct:downloadFile")

                .delete("/{fileId}")
                .description("Delete a file from the specified folder ID.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file").dataType("UUID").endParam()
                .responseMessage().code(200).message("File deleted successfully").responseModel(String.class).endResponseMessage()
                .to("direct:deleteFile")

                .delete("/{fileId}/permanently")
                .description("Delete a file permanently")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file").dataType("UUID").endParam()
                .responseMessage().code(200).message("File deleted successfully").responseModel(String.class).endResponseMessage()
                .to("direct:deleteFilePermanently")

                .patch("/{fileId}/restore")
                .description("Restore a Deleted file by file ID.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file").dataType("UUID").endParam()
                .responseMessage().code(200).message("File restored successfully").responseModel(String.class).endResponseMessage()
                .to("direct:restoreFile")

                .patch("/{fileId}/move")
                .description("Move a file to a specified folder ID.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file").dataType("UUID").endParam()
                .param().name("destinationFolderId").type(RestParamType.query).description("The ID of the destination folder").dataType("UUID").required(false).endParam()
                .responseMessage().code(200).message("File moved successfully").responseModel(String.class).endResponseMessage()
                .to("direct:moveFile")

                .patch("{fileId}/rename")
                .description("Rename a file with the specified file ID.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file to rename").dataType("UUID").endParam()
                .param().name("newFileName").type(RestParamType.query).description("The new file name").dataType("String").endParam()
                .responseMessage().code(200).message("File renamed successfully").responseModel(String.class).endResponseMessage()
                .to("direct:renameFile")

                .patch("/{fileId}/lock")
                .description("Lock a file with the specified file ID.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file").dataType("UUID").endParam()
                .param().name("lock").type(RestParamType.query).description("Lock or unlock file").dataType("Boolean").required(false).endParam()
                .responseMessage().code(200).message("File locked successfully").responseModel(String.class).endResponseMessage()
                .to("direct:lockFile")

                .put("/{fileId}/sensitive")
                .type(SensitivityRequestDTO.class)
                .description("Mark a file as sensitive with the specified file ID.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file").dataType("UUID").endParam()
                .responseMessage().code(200).message("File marked as sensitive successfully").responseModel(String.class).endResponseMessage()
                .to("direct:sensitiveFile")

                .patch("/{fileId}/copy")
                .description("Copy a file to the specified folder ID.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file to copy").dataType("UUID").endParam()
                .param().name("destinationFolderId").type(RestParamType.query).description("The ID of the destination folder").dataType("UUID").required(false).endParam()
                .responseMessage().code(200).message("File copied successfully").responseModel(FileDTO.class).endResponseMessage()
                .to("direct:copyFile")

                .patch("/{fileId}/duplicate")
                .description("Duplicate a file in the same folder, appending a unique number to the filename.")
                .param().name("fileId").type(RestParamType.path).description("The ID of the file to duplicate").dataType("UUID").endParam()
                .responseMessage().code(200).message("File duplicated successfully").responseModel(FileDTO.class).endResponseMessage()
                .to("direct:duplicateFile")

                .post()
                .bindingMode(RestBindingMode.off)
                .consumes("multipart/form-data")
                .produces(MediaType.APPLICATION_JSON_VALUE)
                .description("Upload a file to the specified folder ID.")
                .param().name("folderId").type(RestParamType.query).description("The ID of the folder").dataType("UUID").endParam()
                .param().name("file").type(RestParamType.body).description("The file to upload").dataType("file").endParam()
                .responseMessage().code(200).message("File uploaded successfully").responseModel(File.class).endResponseMessage()
                .to("direct:uploadFile");

        from("direct:listFiles")
                .routeId("listFiles")
                .process(this::fetchFiles)
                .log("received body ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:listDeletedFiles")
                .routeId("listDeletedFiles")
                .process(this::fetchDeletedFiles)
                .log("received body ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        // Route for downloading a file
        from("direct:downloadFile")
                .routeId("downloadFile")
                .process(this::downloadFile)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        // Route for uploading a file
        from("direct:uploadFile")
                .unmarshal().mimeMultipart()
                .routeId("uploadFile")
                .setHeader("RestBindingMode", constant("off"))
                .process(this::uploadFile)
                .marshal().json()
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:deleteFile")
                .routeId("deleteFile")
                .process(this::deleteFile)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:deleteFilePermanently")
                .routeId("deleteFilePermanently")
                .process(this::deleteFilePermanently)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:restoreFile")
                .routeId("restoreFile")
                .process(this::restoreFile)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:moveFile")
                .routeId("moveFile")
                .process(this::moveFile)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:renameFile")
                .routeId("renameFile")
                .process(this::renameFile)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:lockFile")
                .routeId("lockFile")
                .log("Locking file with ID: ${header.fileId}")
                .process(this::lockFile)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                .log("File locked successfully, response: ${body}");

        from("direct:sensitiveFile")
                .routeId("sensitiveFile")
                .log("Marking file as sensitive with ID: ${header.fileId}")
                .process(this::sensitiveFile)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                .log("File marked as sensitive successfully, response: ${body}");

        from("direct:copyFile")
                .routeId("copyFile")
                .process(this::copyFile)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:duplicateFile")
                .routeId("duplicateFile")
                .process(this::duplicateFile)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
    }

    private void fetchFiles(Exchange exchange) throws Exception {
        Optional<UUID> folderId = Optional.ofNullable(exchange.getIn().getHeader("folderId", UUID.class));
        Optional<UUID> fileId = Optional.ofNullable(exchange.getIn().getHeader("fileId", UUID.class));
        List<FileDTO> files = filesService.getObjects(folderId, fileId);
        exchange.getIn().setBody(files);
    }

    private void fetchDeletedFiles(Exchange exchange) throws Exception {
        Integer page = exchange.getIn().getHeader("page", Integer.class);
        Integer size = exchange.getIn().getHeader("size", Integer.class);

        String sortBy = exchange.getIn().getHeader("sortBy", String.class);
        String sortDirection = exchange.getIn().getHeader("sortDirection", String.class);

        if (page == null) {
            page = 0;
        }
        if (size == null) {
            size = 10;
        }

        // Default to sorting by "deletedAt" in descending order if no sorting parameters are provided
        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "deletedAt";
        }

        if (sortDirection == null || sortDirection.isEmpty()) {
            sortDirection = "DESC";
        }

        Page<FileDTO> files = deleteFilesService.getDeletedFiles(page, size, sortBy, sortDirection);
        exchange.getIn().setBody(files);
    }

    private void downloadFile(Exchange exchange) throws Exception {
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        boolean forceDownload = exchange.getIn().getHeader("forceDownload", Boolean.class);
        UUID versionId = exchange.getIn().getHeader("versionId", UUID.class);
        Optional<UUID> optionalVersionId = Optional.ofNullable(versionId);

        UserDTO user = exchange.getProperty("user", UserDTO.class);

        FileDownloadDTO file = filesService.getObject(fileId, optionalVersionId, user, !forceDownload);
        InputStreamResource resource = new InputStreamResource(file.getInputStream());

        MediaType mediaType;

        if (forceDownload) {
            exchange.getIn().setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFileName() + "\"");
            mediaType = MediaType.APPLICATION_OCTET_STREAM;
        } else {
            mediaType = FileMediaType.getMediaTypeFromType(file.getFileType());
            exchange.getIn().setHeader(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + file.getFileName() + "\"");
        }

        if (mediaType == null) {
            throw new UnsupportedMediaTypeException("MediaType " + file.getFileType() + " not supported");
        }

        exchange.getIn().setHeader(HttpHeaders.CONTENT_TYPE, mediaType);
        exchange.getIn().setBody(resource);
    }

    private void uploadFile(Exchange exchange) throws Exception {
        String folderId = exchange.getIn().getBody(String.class);

        AttachmentMessage attachmentMessage = exchange.getIn(AttachmentMessage.class);

        // Retrieve the attachments (multipart form data)
        Map<String, DataHandler> attachments = attachmentMessage.getAttachments();
        Map.Entry<String, DataHandler> entry = attachments.entrySet().iterator().next();

        String fileName = entry.getKey();  // This is the file name (e.g., "version_test.txt")
        DataHandler fileHandler = entry.getValue();

        log.info("Attachment File Name: {}", fileName);

        // Get InputStream and ContentType
        InputStream fileInputStream = fileHandler.getInputStream();
        String contentType = fileHandler.getContentType();

        UserDTO user = exchange.getProperty("user", UserDTO.class);

        UUID folder = null;
        try {
            folder = UUID.fromString(folderId);
        }catch (Exception e){
        }

        FileDTO f = filesService.uploadFile(folder, user, fileInputStream, contentType, fileHandler.getName());

        exchange.getIn().setBody(f);
    }

    private void deleteFile(Exchange exchange) throws Exception {
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        deleteFilesService.deleteObject(fileId, user);
        exchange.getIn().setBody("file deleted successfully");
    }

    private void deleteFilePermanently(Exchange exchange) throws Exception {
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        deleteFilesService.permanentlyDeleteFile(fileId, user);
        exchange.getIn().setBody("file permanently deleted successfully");
    }

    private void restoreFile(Exchange exchange) throws Exception {
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        String fileRestored = deleteFilesService.restoreObject(fileId, user);
        exchange.getIn().setBody("File restored successfully");
    }

    private void moveFile(Exchange exchange) throws Exception {
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        UUID destinationFolderId = exchange.getIn().getHeader("destinationFolderId", UUID.class);

        // Get user information from the exchange properties (assuming it is set somewhere in the flow)
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the service to move the file
        String result = fileUpdateService.moveFile(fileId, destinationFolderId, user);

        // Set the result in the body for the response
        exchange.getIn().setBody(result);
    }

    private void renameFile(Exchange exchange) throws Exception {
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        String newFileName = exchange.getIn().getHeader("newFileName", String.class);

        // Get user information from the exchange properties (assuming it is set somewhere in the flow)
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the service to rename the file
        String result = fileUpdateService.renameFile(fileId, newFileName, user);

        // Set the result in the body for the response
        exchange.getIn().setBody(result);
    }

    private void lockFile(Exchange exchange) throws Exception {
        // Retrieve fileId from the request path
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        Boolean lock = exchange.getIn().getHeader("lock", true, Boolean.class);

        // Retrieve user information from the exchange properties (assuming user is available in the context)
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the service to lock the file
        String result = fileUpdateService.lockFile(fileId, lock, user);

        // Set the result in the body for the response
        exchange.getIn().setBody(result);
    }
    private void sensitiveFile(Exchange exchange) throws Exception {
        // Retrieve fileId from the request path
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        SensitivityRequestDTO sensitivityRequestDTO = exchange.getIn().getBody(SensitivityRequestDTO.class);

        // Retrieve user information from the exchange properties (assuming user is available in the context)
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the service to lock the file
        String result = fileUpdateService.sensitiveFile(fileId, sensitivityRequestDTO, user);

        // Set the result in the body for the response
        exchange.getIn().setBody(result);
    }

    private void copyFile(Exchange exchange) throws Exception {
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        UUID destinationFolderId = exchange.getIn().getHeader("destinationFolderId", UUID.class);

        // Get user information from the exchange properties (assuming it is set somewhere in the flow)
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the service to copy the file
        FileDTO copiedFile = filesService.copyFile(fileId, destinationFolderId, user);

        // Set the copied file DTO in the body for the response
        exchange.getIn().setBody(copiedFile);
    }

    private void duplicateFile(Exchange exchange) throws Exception {
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);

        // Get user information from the exchange properties (assuming it is set somewhere in the flow)
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the service to duplicate the file
        FileDTO duplicatedFile = filesService.duplicateFile(fileId, user);

        // Set the duplicated file DTO in the body for the response
        exchange.getIn().setBody(duplicatedFile);
    }
}
