package com.digitalchain.document_management.dto.file;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.InputStream;

@Data
@AllArgsConstructor
public class FileDownloadDTO {
    private InputStream inputStream;
    private String fileName;
    private String fileType;
}
