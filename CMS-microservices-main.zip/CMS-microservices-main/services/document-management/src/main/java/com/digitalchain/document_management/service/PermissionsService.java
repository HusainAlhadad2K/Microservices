package com.digitalchain.document_management.service;


import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.permissions.FilterFolderPermissionsDTO;
import com.digitalchain.common.dto.permissions.FilterFolderPermissionsRequestDTO;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.UUID;
@Service
@Slf4j
public class PermissionsService {

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    public List<FilterFolderPermissionsDTO> validateFolderAccess(Map<UUID, String> folderIdPathMap, UserDTO user) throws IllegalAccessException {
        try {
            Exchange exchange = producerTemplate.request("direct:validateFolderAccess", e -> {
                e.getIn().setHeader("jwtToken", user.getJwtToken()); // Pass the JWT token to the route
                e.getIn().setBody(new FilterFolderPermissionsRequestDTO(folderIdPathMap));
            });

            int responseCode = exchange.getMessage().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
            if (responseCode == 200) {
                String responseBody = exchange.getMessage().getBody(String.class);

                return objectMapper.readValue(responseBody, new TypeReference<List<FilterFolderPermissionsDTO>>() {});
            } else {
                throw new IllegalAccessException("Failed to validate folder access");
            }
        } catch (Exception ex) {
            throw new IllegalAccessException("Failed to validated folder access");
        }
    }
}
