package com.digitalchain.document_management.dto.folder;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectRequestDTO {
    @NotNull
    private boolean project;
    private String projectStatus;
    private String projectName;
    private String customerName;
    private String description;
    private Date startDate;
    private Date endDate;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String country;
    private String zipCode;
}
