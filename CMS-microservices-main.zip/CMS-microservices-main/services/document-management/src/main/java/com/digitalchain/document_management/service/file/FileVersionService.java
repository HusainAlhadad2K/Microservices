package com.digitalchain.document_management.service.file;

import com.digitalchain.document_management.dto.file.FileVersionDTO;
import com.digitalchain.document_management.exception.ResourceNotFoundException;
import com.digitalchain.document_management.model.document.File;
import com.digitalchain.document_management.model.document.FileVersion;
import com.digitalchain.document_management.repository.FileVersionRepository;
import com.digitalchain.document_management.repository.FilesRepository;
import jakarta.mail.internet.MimeBodyPart;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class FileVersionService {

    @Autowired
    private FileVersionRepository fileVersionRepository;

    @Autowired
    private FilesRepository filesRepository;

    /**
     * Get file versions for a specific file.
     */
    public List<FileVersionDTO> getFileVersions(UUID fileId) throws Exception {
        if (filesRepository.findFileById(fileId).isEmpty()) {
            throw new ResourceNotFoundException(String.format("File with id %s does not exist", fileId));
        }

        try {
            return fileVersionRepository.findByFileId(fileId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Create a new file version based on the file's state and metadata.
     */
    public void createFileVersion(File file, UUID versionId, UUID previousVersionId, String filePath, String contentType, Long size) throws Exception {
        log.debug("Creating new file version for file: {}", file.getFile_name());

        // Create a new file version object
        FileVersion fileVersion = new FileVersion();
        fileVersion.setVersionId(versionId);
        fileVersion.setFile(file);
        fileVersion.setVersionNumber(getNewVersionNumber(previousVersionId));
        fileVersion.setFilePath(filePath);
        fileVersion.setFileType(contentType != null ? contentType : file.getFile_type());
        fileVersion.setFileSize(size != null ? String.valueOf(size) : file.getFile_size());
        fileVersion.setCreatedAt(new Date());

        // Save the new file version to the repository
        fileVersionRepository.save(fileVersion);

        log.info("New file version created for file '{}' with version ID: {}", file.getFile_name(), versionId);
    }

    /**
     * Helper method to calculate the new version number for a file.
     */
    private int getNewVersionNumber(UUID previousVersionId) {
        // Fetch version number from the repository
        return fileVersionRepository.findVersionNumberById(previousVersionId)
                .map(versionNumber -> {
                    log.debug("Current version number found: {}", versionNumber);
                    int newVersion = versionNumber + 1;
                    log.debug("Calculated new version number: {}", newVersion);
                    return newVersion;
                })
                .orElseGet(() -> {
                    log.debug("No version found, starting with version 1");
                    return 1;
                });
    }

}
