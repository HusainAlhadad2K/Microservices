package com.digitalchain.document_management.utils;


import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.common.dto.files.FileLogDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.document_management.model.document.File;
import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.service.FileLogProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
public class FileLogger {

    @Autowired
    FileLogProducerService fileLogProducerService;

    public void log(File fileDTO, FileLogAction action, UserDTO user){
        FileLogDTO log = FileLogDTO.builder()
                .fileId(fileDTO.getId())
                .fileVersion(fileDTO.getLatestVersionId())
                .filePath(fileDTO.getFile_path())
                .action(action)
                .actionInfo(action.getDescription())
                .userId(user.getUser_id())
                .userName(user.getSub())
                .ipAddress(user.getIpAddress())
                .actionTime(new Date())
                .build();

        fileLogProducerService.sendFileLog(log);
    }
    public void log(FileDTO fileDTO, FileLogAction action, UserDTO user){
        FileLogDTO log = FileLogDTO.builder()
                .fileId(fileDTO.getId())
                .fileVersion(fileDTO.getLatestVersionId())
                .filePath(fileDTO.getFilePath())
                .action(action)
                .actionInfo(action.getDescription())
                .userId(user.getUser_id())
                .userName(user.getSub())
                .ipAddress(user.getIpAddress())
                .actionTime(new Date())
                .build();

        fileLogProducerService.sendFileLog(log);
    }
    public void log(FileDTO fileDTO, FileLogAction action, UserDTO user, UUID versionId){
        FileLogDTO log = FileLogDTO.builder()
                .fileId(fileDTO.getId())
                .fileVersion(versionId)
                .filePath(fileDTO.getFilePath())
                .action(action)
                .actionInfo(action.getDescription())
                .userId(user.getUser_id())
                .userName(user.getSub())
                .ipAddress(user.getIpAddress())
                .actionTime(new Date())
                .build();

        fileLogProducerService.sendFileLog(log);
    }
    public void log(Folder folder, FileLogAction action, UserDTO user){
        FileLogDTO log = FileLogDTO.builder()
                .fileId(folder.getFolder_id())
                .filePath(folder.getFolderPath())
                .action(action)
                .actionInfo(action.getDescription())
                .userId(user.getUser_id())
                .userName(user.getSub())
                .ipAddress(user.getIpAddress())
                .actionTime(new Date())
                .build();

        fileLogProducerService.sendFileLog(log);
    }
    public void log(FolderDTO folder, FileLogAction action, UserDTO user){
        FileLogDTO log = FileLogDTO.builder()
                .fileId(folder.getFolderId())
                .filePath(folder.getFolderPath())
                .action(action)
                .actionInfo(action.getDescription())
                .userId(user.getUser_id())
                .ipAddress(user.getIpAddress())
                .userName(user.getSub())
                .actionTime(new Date())
                .build();

        fileLogProducerService.sendFileLog(log);
    }
}
