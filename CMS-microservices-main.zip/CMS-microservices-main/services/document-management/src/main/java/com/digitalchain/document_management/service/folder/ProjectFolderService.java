package com.digitalchain.document_management.service.folder;


import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.document_management.dto.folder.ProjectRequestDTO;
import com.digitalchain.document_management.exception.ResourceNotFoundException;
import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.repository.FoldersRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Transactional
@Service
@Slf4j
public class ProjectFolderService {

    @Autowired
    private FoldersRepository foldersRepository;

    // Method to toggle the folder's isProject flag
    public String updateProjectDetails(UUID folderId, ProjectRequestDTO projectRequestDTO, UserDTO userDTO) throws Exception {
        log.info("Updating project details for folder ID: {}", folderId);

        // Find the folder by ID
        Folder folder = foldersRepository.findById(folderId).orElseThrow(
                () -> new ResourceNotFoundException("Folder not found")
        );

        // Update the isProject flag and other project-related fields
        folder.setIsProject(projectRequestDTO.isProject());

        if (projectRequestDTO.isProject()) {
            folder.setProjectName(projectRequestDTO.getProjectName());
            folder.setCustomerName(projectRequestDTO.getCustomerName());
            folder.setDescription(projectRequestDTO.getDescription());
            folder.setStartDate(projectRequestDTO.getStartDate());
            folder.setEndDate(projectRequestDTO.getEndDate());
            folder.setAddressLine1(projectRequestDTO.getAddressLine1());
            folder.setAddressLine2(projectRequestDTO.getAddressLine2());
            folder.setCity(projectRequestDTO.getCity());
            folder.setState(projectRequestDTO.getState());
            folder.setCountry(projectRequestDTO.getCountry());
            folder.setZipCode(projectRequestDTO.getZipCode());
            folder.setProjectCreatedBy(userDTO.getUser_id());
            folder.setProjectCreatedAt(new Date());
            folder.setProjectStatus(projectRequestDTO.getProjectStatus());
        } else {
            // Clear project-related details if it's no longer a project
            folder.setProjectName(null);
            folder.setCustomerName(null);
            folder.setDescription(null);
            folder.setStartDate(null);
            folder.setEndDate(null);
            folder.setAddressLine1(null);
            folder.setAddressLine2(null);
            folder.setCity(null);
            folder.setState(null);
            folder.setCountry(null);
            folder.setZipCode(null);
            folder.setProjectCreatedBy(null);
            folder.setProjectCreatedAt(null);
        }

        // Save the folder with updated details
        foldersRepository.save(folder);

        log.info("Folder ID: {} updated with project details: {}", folderId, projectRequestDTO);
        return "Folder project details updated successfully";
    }


    // Method to update the project status
    public String updateProjectStatus(UUID folderId, String projectStatus) throws Exception {
        log.info("Updating project status for folder ID: {}, new project status: {}", folderId, projectStatus);

        // Find the folder by ID
        Folder folder = foldersRepository.findById(folderId).orElseThrow(
                () -> new ResourceNotFoundException("Folder not found")
        );

        if (!folder.getIsProject()){
            throw new IllegalAccessException("Folder is not a project");
        }

        // Update the project status
        folder.setProjectStatus(projectStatus);

        // Save the folder
        foldersRepository.save(folder);

        log.info("Folder ID: {} updated with project status: {}", folderId, projectStatus);
        return "Folder project status updated successfully";
    }
}
