package com.digitalchain.document_management.routes;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.common.dto.folders.ProjectInfoDTO;
import com.digitalchain.document_management.config.BaseRouteBuilder;
import com.digitalchain.document_management.dto.folder.*;
import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.service.folder.*;
import jakarta.activation.DataHandler;
import jakarta.validation.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.attachment.AttachmentMessage;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Component
@Slf4j
public class FolderRoute extends BaseRouteBuilder {

    @Autowired
    private FoldersService foldersService;

    @Autowired
    private DeleteFoldersService deleteFoldersService;

    @Autowired
    private FolderVersionService folderVersionService;

    @Autowired
    private ExcelFolderService excelFolderService;

    @Autowired
    private FolderUpdateService folderUpdateService;

    @Autowired
    private ProjectFolderService projectFolderService;

    @Override
    public void configure() throws Exception {
        super.configure();

        // Route for managing folders
        rest("/folders")
                .get()
                .description("List all folders.")
                .param().name("parentFolderId").type(RestParamType.query).description("Parent folder ID").dataType("UUID").required(false).endParam()
                .responseMessage().code(200).message("Folders listed successfully").responseModel(FolderDTO[].class).endResponseMessage()
                .to("direct:listFolders")

                .get("/deleted")
                .description("List all deleted folders.")
                .param().name("page").type(RestParamType.query).description("Page number to retrieve").dataType("Integer").required(false).endParam()
                .param().name("size").type(RestParamType.query).description("Number of records per page").dataType("Integer").required(false).endParam()
                .param().name("sortBy").type(RestParamType.query).description("Field to sort by").dataType("String").required(false).endParam()
                .param().name("sortDirection").type(RestParamType.query).description("Sort direction (ASC or DESC)").dataType("String").required(false).endParam()
                .responseMessage().code(200).message("Deleted folders listed successfully").responseModel(FolderDTO[].class).endResponseMessage()
                .to("direct:listDeletedFolders")

                .patch("/{folderId}/restore")
                .description("Restore deleted folders.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder").dataType("UUID").endParam()
                .responseMessage().code(200).message("Restored folder successfully").responseModel(FolderDTO[].class).endResponseMessage()
                .to("direct:restoreFolder")

                .get("/{folderId}/versions")
                .description("List all versions of the specified folder.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder").dataType("UUID").endParam()
                .responseMessage().code(200).message("Folder versions listed successfully").responseModel(FolderDTO[].class).endResponseMessage()
                .to("direct:getFolderVersions")

                .get("/{folderId}")
                .description("Retrieve a folder by ID.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder").dataType("UUID").endParam()
                .responseMessage().code(200).message("Folder retrieved successfully").responseModel(FolderDTO.class).endResponseMessage()
                .to("direct:getFolderById")

                .delete("/{folderId}")
                .description("Delete a folder by ID.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder").dataType("UUID").endParam()
                .responseMessage().code(200).message("Folder deleted successfully").responseModel(String.class).endResponseMessage()
                .to("direct:deleteFolder")

                .delete("/{folderId}/permanently")
                .description("Delete a folder permanently by ID.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder").dataType("UUID").endParam()
                .responseMessage().code(200).message("Folder deleted successfully").responseModel(String.class).endResponseMessage()
                .to("direct:deleteFolderPermanently")

                .post("/create")
                .consumes(MediaType.APPLICATION_JSON_VALUE)
                .produces(MediaType.APPLICATION_JSON_VALUE)
                .type(CreateFolderDTO.class)
                .description("Create a new folder.")
                .param().name("body").type(RestParamType.body).description("The folder creation request").required(true).endParam()
                .responseMessage().code(201).message("Folder created successfully").responseModel(FolderDTO.class).endResponseMessage()
                .to("direct:createFolder")

                .post("/upload-csv")
                .bindingMode(RestBindingMode.off)
                .consumes(MediaType.MULTIPART_FORM_DATA_VALUE)
                .produces(MediaType.APPLICATION_JSON_VALUE)
                .description("Upload CSV/Excel file to create a folder hierarchy.")
                .param().name("folderId").type(RestParamType.query).description("The ID of the folder").dataType("UUID").endParam()
                .param().name("file").type(RestParamType.body).description("The file to upload").dataType("file").endParam()
                .responseMessage().code(201).message("Folder created successfully").endResponseMessage()
                .to("direct:createFolderFromCSV")

                .patch("/{folderId}/move")
                .description("Move a folder to a new destination.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder to move").dataType("UUID").endParam()
                .param().name("destinationFolderId").type(RestParamType.query).description("The ID of the destination folder").dataType("UUID").required(false).endParam()
                .responseMessage().code(200).message("Folder moved successfully").responseModel(FolderDTO.class).endResponseMessage()
                .to("direct:moveFolder")

                .patch("/{folderId}/copy")
                .description("Copy a folder to a new destination.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder to copy").dataType("UUID").endParam()
                .param().name("destinationFolderId").type(RestParamType.query).description("The ID of the destination folder").dataType("UUID").required(false).endParam()
                .responseMessage().code(200).message("Folder copied successfully").responseModel(FolderDTO.class).endResponseMessage()
                .to("direct:copyFolder")

                .patch("/{folderId}/duplicate")
                .description("Duplicate a folder in the same folder, appending a unique number to the folder name.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder to duplicate").dataType("UUID").endParam()
                .responseMessage().code(200).message("Folder duplicated successfully").responseModel(FolderDTO.class).endResponseMessage()
                .to("direct:duplicateFolder")

                .patch("/{folderId}/rename")
                .description("Rename a folder.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder to rename").dataType("UUID").endParam()
                .param().name("newName").type(RestParamType.query).description("The new name for the folder").dataType("String").required(true).endParam()
                .responseMessage().code(200).message("Folder renamed successfully").responseModel(FolderDTO.class).endResponseMessage()
                .to("direct:renameFolder")

                .put("/{folderId}/project")
                .type(ProjectRequestDTO.class)
                .description("Toggle the isProject flag of a folder.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder to toggle project flag").dataType("UUID").endParam()
                .responseMessage().code(200).message("Folder project flag updated successfully").endResponseMessage()
                .to("direct:toggleIsProject")

                .patch("/{folderId}/project/status")
                .description("Update the project status of a folder.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder to update project status").dataType("UUID").endParam()
                .param().name("projectStatus").type(RestParamType.query).description("The new project status").dataType("String").endParam()
                .responseMessage().code(200).message("Folder project status updated successfully").endResponseMessage()
                .to("direct:updateProjectStatus")

                .get("/{folderId}/download")
                .description("Download a folder as a zip file.")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder").dataType("UUID").endParam()
                .param().name("folderId").type(RestParamType.query).description("Include sub folders or not").dataType("Boolean").required(false).endParam()
                .produces("application/zip")
                .responseMessage().code(200).message("Folder downloaded successfully").endResponseMessage()
                .to("direct:downloadFolder");

        from("direct:toggleIsProject")
                .routeId("toggleIsProject")
                .process(this::toggleIsProject)
                .log("Toggled isProject flag: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:updateProjectStatus")
                .routeId("updateProjectStatus")
                .process(this::updateProjectStatus)
                .log("Updated project status: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:listFolders")
                .routeId("listFolders")
                .process(this::fetchFolders)
                .log("Fetched folders: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:restoreFolder")
                .routeId("restoreFolder")
                .process(this::restoreFolder)
                .log("Restored folders: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:listDeletedFolders")
                .routeId("listDeletedFolders")
                .process(this::fetchDeletedFolders)
                .log("Fetched deleted folders: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:getFolderById")
                .routeId("getFolderById")
                .process(this::getFolderById)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:createFolder")
                .routeId("createFolder")
                .process(this::createFolder)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(201))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:createFolderFromCSV")
                .unmarshal().mimeMultipart()
                .routeId("createFolderFromCSV")
                .setHeader("RestBindingMode", constant("off"))
                .process(this::createFolderFromCSV)
                .marshal().json()
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(201))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:deleteFolder")
                .routeId("deleteFolder")
                .process(this::deleteFolder)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:deleteFolderPermanently")
                .routeId("deleteFolderPermanently")
                .process(this::deleteFolderPermanently)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:getFolderVersions")
                .routeId("getFolderVersions")
                .process(this::getFolderVersions)
                .log("Fetched folder versions: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:downloadFolder")
                .routeId("downloadFolder")
                .process(this::downloadFolder)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader("Content-Disposition", simple("attachment; filename=folder_${header.folderId}.zip"))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/zip"));

        from("direct:moveFolder")
                .routeId("moveFolder")
                .process(this::moveFolder)
                .log("Moved folder: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:copyFolder")
                .routeId("copyFolder")
                .process(this::copyFolder)
                .log("Copied folder: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:duplicateFolder")
                .routeId("duplicateFolder")
                .process(this::duplicateFolder)
                .log("Duplicated folder: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:renameFolder")
                .routeId("renameFolder")
                .process(this::renameFolder)
                .log("Renamed folder: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
    }

    private void fetchFolders(Exchange exchange) throws Exception {
        UUID parentFolderId = exchange.getIn().getHeader("parentFolderId", UUID.class);
        String folderName = exchange.getIn().getHeader("folderName", String.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        List<FolderDTO> folders = foldersService.getAllFolders(parentFolderId, folderName, user);
        exchange.getIn().setBody(folders);
    }

    private void fetchDeletedFolders(Exchange exchange) throws Exception {
        Integer page = exchange.getIn().getHeader("page", Integer.class);
        Integer size = exchange.getIn().getHeader("size", Integer.class);

        String sortBy = exchange.getIn().getHeader("sortBy", String.class);
        String sortDirection = exchange.getIn().getHeader("sortDirection", String.class);

        if (page == null) {
            page = 0;
        }
        if (size == null) {
            size = 10;
        }

        // Default to sorting by "deletedAt" in descending order if no sorting parameters are provided
        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "deletedAt";
        }

        if (sortDirection == null || sortDirection.isEmpty()) {
            sortDirection = "DESC";
        }

        Page<FolderDTO> folders = deleteFoldersService.getDeletedFolders(page, size, sortBy, sortDirection);
        exchange.getIn().setBody(folders);
    }

    private void getFolderById(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        FolderDTO folder = foldersService.getFolderById(folderId);

        exchange.getIn().setBody(folder);
    }

    private void createFolder(Exchange exchange) throws Exception {
        CreateFolderDTO folderDTO = exchange.getIn().getBody(CreateFolderDTO.class);
        log.debug("Received request body: {}", folderDTO);

        if (folderDTO == null || folderDTO.getFolderName() == null) {
            log.error("Received null FolderDTO or missing folder name in request body");
            throw new ValidationException("Body is null or missing");
        }

        UserDTO user = exchange.getProperty("user", UserDTO.class);
        Folder createdFolder = foldersService.createFolder(folderDTO, user);

        exchange.getIn().setBody(convertToDTO(createdFolder));
    }

    private void createFolderFromCSV(Exchange exchange) throws Exception {
        String folderId = exchange.getIn().getBody(String.class);

        AttachmentMessage attachmentMessage = exchange.getIn(AttachmentMessage.class);
        // Retrieve the attachments (multipart form data)
        Map<String, DataHandler> attachments = attachmentMessage.getAttachments();
        Map.Entry<String, DataHandler> entry = attachments.entrySet().iterator().next();

        String fileName = entry.getKey();  // This is the file name (e.g., "version_test.txt")
        DataHandler fileHandler = entry.getValue();

        log.info("Attachment File Name: {}", fileName);

        // Get InputStream and ContentType
        InputStream fileInputStream = fileHandler.getInputStream();
        String contentType = fileHandler.getContentType();

        UserDTO user = exchange.getProperty("user", UserDTO.class);

        UUID folder = null;

        try {
            folder = UUID.fromString(folderId);
        }catch (Exception e){
        }

        excelFolderService.createFromExcelFile(fileInputStream, contentType, folder, user);

        exchange.getIn().setBody("Successfully created folders from Excel");
    }

    private void deleteFolder(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        deleteFoldersService.softDeleteFolder(folderId, user);
        exchange.getIn().setBody("Folder deleted successfully");
    }
    private void deleteFolderPermanently(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        deleteFoldersService.permanentlyDeleteFolder(folderId, user);
        exchange.getIn().setBody("Folder deleted permanently successfully");
    }

    private void restoreFolder(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        deleteFoldersService.restoreDeletedFolder(folderId, user);
        exchange.getIn().setBody("Folder restored successfully");
    }

    private void getFolderVersions(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        List<FolderVersionDTO> versions = folderVersionService.getFolderVersions(folderId);

        if (versions == null || versions.isEmpty()) {
            String message = "This folder doesn't have a version.";
            exchange.getIn().setBody(message);
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, constant(404));
        } else {
            FolderDTO folderDTO = new FolderDTO();
            folderDTO.setFolderId(folderId);
            exchange.getIn().setBody(folderDTO);
        }
    }

    private void downloadFolder(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        Boolean includeSubFolders = exchange.getIn().getHeader("includeSubFolders", true, Boolean.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        ByteArrayOutputStream zipStream = foldersService.downloadFolderAsZip(folderId, user, includeSubFolders);
        exchange.getIn().setBody(zipStream.toByteArray());
    }

    private void moveFolder(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        UUID destinationFolderId = exchange.getIn().getHeader("destinationFolderId", UUID.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the foldersService to move the folder
        String movedFolder = folderUpdateService.moveFolder(folderId, destinationFolderId, user, true, destinationFolderId == null,null);

        // Return the moved folder details as a FolderDTO
        exchange.getIn().setBody(movedFolder);
    }

    private void copyFolder(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        UUID destinationFolderId = exchange.getIn().getHeader("destinationFolderId", UUID.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the foldersService to move the folder
        String movedFolder = folderUpdateService.moveFolder(folderId, destinationFolderId, user, false, destinationFolderId == null, null);

        // Return the moved folder details as a FolderDTO
        exchange.getIn().setBody(movedFolder);
    }
    private void duplicateFolder(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the foldersService to move the folder
        String movedFolder = folderUpdateService.moveFolder(folderId, null, user, false,  false,null);

        // Return the moved folder details as a FolderDTO
        exchange.getIn().setBody("Duplicated folder successfully");
    }

    private void renameFolder(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        String newName = exchange.getIn().getHeader("newName", String.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the FolderUpdateService to rename the folder
        String renamedFolder = folderUpdateService.moveFolder(folderId, null, user, true, false, newName);

        // Return the renamed folder details
        exchange.getIn().setBody("Renamed folder successfully");
    }

    private FolderDTO convertToDTO(Folder folder) {
        return new FolderDTO(
                folder.getFolder_id(),
                folder.getFolder_name(),
                folder.getParent_folder() != null ? folder.getParent_folder().getFolder_id() : null,
                folder.getParent_folder() != null ? folder.getParent_folder().getFolder_name() : null,
                folder.getFolderPath(),
                folder.getUser_id(),
                folder.getCreated_at(),
                folder.getUpdated_at(),
                false,
                new ProjectInfoDTO()
        );
    }

    private void toggleIsProject(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        ProjectRequestDTO project = exchange.getIn().getBody(ProjectRequestDTO.class);

        UserDTO user = exchange.getProperty("user", UserDTO.class);

        // Call the FolderUpdateService to toggle the isProject flag
        String result = projectFolderService.updateProjectDetails(folderId, project, user);

        // Return the result
        exchange.getIn().setBody(result);
    }

    private void updateProjectStatus(Exchange exchange) throws Exception {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        String projectStatus = exchange.getIn().getHeader("projectStatus", String.class);

        // Call the FolderUpdateService to update the project status
        String result = projectFolderService.updateProjectStatus(folderId, projectStatus);

        // Return the result
        exchange.getIn().setBody(result);
    }
}
