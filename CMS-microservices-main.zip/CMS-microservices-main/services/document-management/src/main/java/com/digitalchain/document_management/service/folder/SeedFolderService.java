package com.digitalchain.document_management.service.folder;


import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.document_management.config.OCIConfig;
import com.digitalchain.document_management.dto.folder.SeedFolderDTO;
import com.digitalchain.document_management.model.document.File;
import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.repository.FilesRepository;
import com.digitalchain.document_management.repository.FoldersRepository;
import com.digitalchain.document_management.utils.oci.OciObjectStorageUtil;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class SeedFolderService {

    @Autowired
    private FoldersRepository foldersRepository;

    @Autowired
    private FilesRepository filesRepository;

    @Autowired
    private OciObjectStorageUtil ociObjectStorageUtil;

    @Autowired
    private OCIConfig ociConfig;

    @Autowired
    private FolderUpdateService folderUpdateService;

    public List<SeedFolderDTO> getSeedFolders(){
        return foldersRepository.findAllSeedFolders();
    }

    /**
     * Marks a folder as a seed folder (template).
     */
    @Transactional
    public void updateIsSeedFolder(UUID folderId, Boolean isSeedFolder) {
        foldersRepository.findById(folderId).orElseThrow(() -> {
            log.error("Folder with ID {} not found", folderId);
            return new IllegalArgumentException("Folder not found");
        });

        foldersRepository.updateIsSeedFolder(folderId, isSeedFolder);
        log.info("Folder with ID {} marked as seed folder", folderId);
    }

    @Transactional
    public void duplicateSeedFolder(UUID seedFolderId, UUID targetFolderId, String targetFolderName, UserDTO user) throws Exception {
        folderUpdateService.moveFolder(
                seedFolderId,
                targetFolderId,
                user,
                false,
                targetFolderId == null,
                targetFolderName
        );
    }
}
