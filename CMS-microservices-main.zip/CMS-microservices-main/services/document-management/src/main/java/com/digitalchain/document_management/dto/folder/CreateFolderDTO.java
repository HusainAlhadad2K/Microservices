package com.digitalchain.document_management.dto.folder;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateFolderDTO {
    @NotNull(message = "Folder name cannot be null")
    @Size(min = 1, max = 255, message = "Folder name must be between 1 and 255 characters")
    private String folderName;

    private UUID parentFolderId;
    private boolean isProject = false;
}
