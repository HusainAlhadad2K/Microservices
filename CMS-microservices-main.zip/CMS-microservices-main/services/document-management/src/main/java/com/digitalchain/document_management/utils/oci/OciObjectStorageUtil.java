package com.digitalchain.document_management.utils.oci;

import com.oracle.bmc.ConfigFileReader;
import com.oracle.bmc.Region;
import com.oracle.bmc.auth.AuthenticationDetailsProvider;
import com.oracle.bmc.auth.ConfigFileAuthenticationDetailsProvider;
import com.oracle.bmc.objectstorage.ObjectStorageAsync;
import com.oracle.bmc.objectstorage.ObjectStorageAsyncClient;
import com.oracle.bmc.objectstorage.model.*;
import com.oracle.bmc.objectstorage.requests.*;
import com.oracle.bmc.objectstorage.responses.*;
import jakarta.mail.internet.MimeBodyPart;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class OciObjectStorageUtil {

    private final ObjectStorageAsync client;
    private final String namespaceName;

    public OciObjectStorageUtil(@Value("${oci.configFile}") String configFilePath,
                                @Value("${oci.profile}") String profile) throws Exception {
        final ConfigFileReader.ConfigFile configFile = ConfigFileReader.parse(configFilePath, profile);
        final AuthenticationDetailsProvider provider = new ConfigFileAuthenticationDetailsProvider(configFile);
        this.client = ObjectStorageAsyncClient.builder().region(Region.EU_FRANKFURT_1).build(provider);

        ResponseHandler<GetNamespaceRequest, GetNamespaceResponse> namespaceHandler = new ResponseHandler<>();
        client.getNamespace(GetNamespaceRequest.builder().build(), namespaceHandler);
        GetNamespaceResponse namespaceResponse = namespaceHandler.waitForCompletion();
        this.namespaceName = namespaceResponse.getValue();
    }

    // ===============================================================
    // File-related operations
    // ===============================================================

    public GetObjectResponse getObject(String bucketName, String objectName, String versionId) throws Exception {
        ResponseHandler<GetObjectRequest, GetObjectResponse> objectHandler = new ResponseHandler<>();
        GetObjectRequest.Builder getObjectRequest = GetObjectRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .objectName(objectName);

        if (versionId != null) {
            getObjectRequest.versionId(versionId);
        }

        client.getObject(getObjectRequest.build(), objectHandler);
        GetObjectResponse getResponse = objectHandler.waitForCompletion();

        return getResponse;
    }

    public GetObjectResponse copyObject(String bucketName, String sourceObjectName, String targetBucketName, String targetObjectName, boolean getObjectDetails) throws Exception {
        CopyObjectDetails details = CopyObjectDetails.builder()
                .sourceObjectName(sourceObjectName)
                .destinationBucket(targetBucketName)
                .destinationObjectName(targetObjectName)
                .destinationRegion("eu-frankfurt-1")
                .destinationNamespace(namespaceName)
                .build();

        CopyObjectRequest copyObjectRequest = CopyObjectRequest.builder()
                .namespaceName(namespaceName)
                .copyObjectDetails(details)
                .bucketName(bucketName)
                .build();

        ResponseHandler<CopyObjectRequest, CopyObjectResponse> copyObjectHandler = new ResponseHandler<>();
        client.copyObject(copyObjectRequest, copyObjectHandler);
        CopyObjectResponse copyObjectResponse = copyObjectHandler.waitForCompletion();

        if (getObjectDetails) {
            GetObjectResponse copiedObjectDetails = null;
            int retryCount = 0;
            int maxRetries = 5;
            int waitTime = 1000; // 2 seconds wait time between retries

            while (retryCount < maxRetries) {
                try {
                    log.debug("Attempting to retrieve copied object (attempt {}): '{}' from bucket '{}'", retryCount + 1, targetObjectName, targetBucketName);
                    copiedObjectDetails = getObject(targetBucketName, targetObjectName, null);
                    break;  // If successful, break out of the loop
                } catch (Exception e) {
                    log.warn("Failed to retrieve copied object on attempt {}: {}", retryCount + 1, e.getMessage());
                    Thread.sleep(waitTime);  // Wait before retrying
                    retryCount++;
                }
            }

            return copiedObjectDetails;
        }

        return null;
    }

    public String uploadObject(String bucketName, String objectName, MimeBodyPart file, InputStream test, String contentType) throws Exception {
        try (InputStream inputStream = test) {
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .namespaceName(namespaceName)
                    .bucketName(bucketName)
                    .objectName(objectName)
                    .putObjectBody(inputStream)
                    .contentType(contentType)
                    .build();

            ResponseHandler<PutObjectRequest, PutObjectResponse> putObjectHandler = new ResponseHandler<>();
            client.putObject(putObjectRequest, putObjectHandler);
            PutObjectResponse putObjectResponse = putObjectHandler.waitForCompletion();

            return putObjectResponse.getVersionId();
        }
    }

    public String createFolder(String bucketName, String objectName) throws Exception {
        String content = "";
        InputStream contentStream = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));

        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .objectName(objectName)
                .putObjectBody(contentStream)
                .contentLength(0L)
                .build();

        ResponseHandler<PutObjectRequest, PutObjectResponse> putObjectHandler = new ResponseHandler<>();
        client.putObject(putObjectRequest, putObjectHandler);
        PutObjectResponse putObjectResponse = putObjectHandler.waitForCompletion();

        return putObjectResponse.getOpcRequestId();
    }

    public String deleteObject(String bucketName, String objectName) throws Exception {
        log.debug("Deleting object: {} from bucket: {}", objectName, bucketName);

        DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .objectName(objectName)
                .build();

        ResponseHandler<DeleteObjectRequest, DeleteObjectResponse> deleteObjectHandler = new ResponseHandler<>();
        client.deleteObject(deleteObjectRequest, deleteObjectHandler);
        DeleteObjectResponse deleteObjectResponse = deleteObjectHandler.waitForCompletion();

        log.debug("Object deleted successfully: {}", objectName);
        return deleteObjectResponse.getVersionId();
    }

    public String restoreObject(String bucketName, String objectName, String versionId) throws Exception {
        DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .objectName(objectName)
                .versionId(versionId)
                .build();

        ResponseHandler<DeleteObjectRequest, DeleteObjectResponse> deleteObjectHandler = new ResponseHandler<>();
        client.deleteObject(deleteObjectRequest, deleteObjectHandler);
        DeleteObjectResponse deleteObjectResponse = deleteObjectHandler.waitForCompletion();


        return deleteObjectResponse.getVersionId();
    }

    public List<ObjectVersionSummary> listObjectVersions(String bucketName, String objectName) throws Exception {
        ListObjectVersionsRequest request = ListObjectVersionsRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .prefix(objectName)  // Specify the object name to filter versions
                .build();

        ResponseHandler<ListObjectVersionsRequest, ListObjectVersionsResponse> listObjectsResponseHandler = new ResponseHandler<>();

        client.listObjectVersions(request, listObjectsResponseHandler);

        ListObjectVersionsResponse response = listObjectsResponseHandler.waitForCompletion();

        for (ObjectVersionSummary version : response.getObjectVersionCollection().getItems()) {
            System.out.println("Version ID: " + version.getVersionId());
            System.out.println("Lifecycle State: " + version.getIsDeleteMarker());
            System.out.println("Object Name: " + version.getName());
        }

        return response.getObjectVersionCollection().getItems();
    }

    public List<String> listObjectsInFolder(String bucketName, String folderPath, ObjectRetrievalMode mode, String delimiter) throws Exception {
        ResponseHandler<ListObjectsRequest, ListObjectsResponse> listObjectsHandler = new ResponseHandler<>();

        ListObjectsRequest.Builder listObjectsRequest = ListObjectsRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
//                .delimiter(delimiter)
                .prefix(folderPath);  // Filter objects by the folder path prefix

        if (delimiter != null) {
            listObjectsRequest.delimiter(delimiter);
        }

        client.listObjects(listObjectsRequest.build(), listObjectsHandler);
        ListObjectsResponse listObjectsResponse = listObjectsHandler.waitForCompletion();

        List<String> objectNames = listObjectsResponse.getListObjects().getObjects().stream()
                .map(ObjectSummary::getName)
                .toList();  // Return the list of object names

        List<String> commonPrefixes = listObjectsResponse.getListObjects().getPrefixes();

        if (mode == ObjectRetrievalMode.ALL) {
            List<String> allObjects = new ArrayList<>(objectNames);   // Add files

            if (commonPrefixes != null) {
                allObjects.addAll(commonPrefixes); // Add folders
            }

            return allObjects;
        } else if (mode == ObjectRetrievalMode.FOLDERS_ONLY) {
            return commonPrefixes;
        }

        return objectNames;
    }

    public List<Map<String, String>> deleteFolder(String bucketName, String folderPath) throws Exception {
        List<Map<String, String>> deletedObjectsInfo = new ArrayList<>();

        List<String> objectsToDelete = listObjectsInFolder(bucketName, folderPath, ObjectRetrievalMode.ALL, null);

        for (String objectName : objectsToDelete) {
            String versionId = deleteObject(bucketName, objectName);
            Map<String, String> objectInfo = new HashMap<>();

            objectInfo.put("path", objectName);
            objectInfo.put("versionId", versionId);

            // Add the map to the result list
            deletedObjectsInfo.add(objectInfo);
        }

        return deletedObjectsInfo;
    }

    public GetObjectResponse moveObject(String bucketName, String sourceObjectName, String targetBucketName, String targetObjectName) throws Exception {
        // Step 1: Copy the object
        log.debug("Copying object '{}' from bucket '{}' to target object '{}' in bucket '{}'",
                sourceObjectName, bucketName, targetObjectName, targetBucketName);

        // Perform the copy operation and ensure it completes before proceeding
        GetObjectResponse copiedObjectDetails = copyObject(bucketName, sourceObjectName, targetBucketName, targetObjectName, true);
        log.debug("Object copied successfully from '{}' to '{}'", sourceObjectName, targetObjectName);

        if (copiedObjectDetails == null) {
            throw new RuntimeException("Failed to retrieve the copied object");
        }

        // Step 3: Delete the original object
        log.debug("Deleting source object '{}' from bucket '{}'", sourceObjectName, bucketName);
        deleteObject(bucketName, sourceObjectName);
        log.debug("Source object '{}' deleted successfully from bucket '{}'", sourceObjectName, bucketName);

        // Step 4: Return the details of the copied object
        return copiedObjectDetails;
    }

    public String renameFile(String bucketName, String sourceObjectName, String newName) throws Exception {
        RenameObjectDetails renameObjectDetails = RenameObjectDetails
                .builder()
                .newName(newName)
                .sourceName(sourceObjectName)
                .build();

        RenameObjectRequest renameObjectRequest = RenameObjectRequest.builder()
                .renameObjectDetails(renameObjectDetails)
                .bucketName(bucketName)
                .namespaceName(namespaceName)
                .build();

        ResponseHandler<RenameObjectRequest, RenameObjectResponse> responseHandler = new ResponseHandler<>();
        client.renameObject(renameObjectRequest, responseHandler);
        RenameObjectResponse response = responseHandler.waitForCompletion();

        return response.getVersionId();
    }

    public void createBucketIfNotExists(String compartmentId, String bucketName) throws Exception {
        ResponseHandler<GetBucketRequest, GetBucketResponse> getBucketHandler = new ResponseHandler<>();
        GetBucketRequest getBucketRequest = GetBucketRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .build();

        try {
            log.debug("Checking if bucket '{}' exists in namespace '{}'", bucketName, namespaceName);
            client.getBucket(getBucketRequest, getBucketHandler);
            getBucketHandler.waitForCompletion();  // If this succeeds, bucket exists
            log.debug("Bucket '{}' already exists", bucketName);
        } catch (Exception e) {
            log.debug("Bucket '{}' does not exist. Creating new bucket.", bucketName);
            CreateBucketRequest createBucketRequest = CreateBucketRequest.builder()
                    .namespaceName(namespaceName)
                    .createBucketDetails(CreateBucketDetails.builder()
                            .compartmentId(compartmentId)
                            .name(bucketName)
                            .build())
                    .build();

            ResponseHandler<CreateBucketRequest, CreateBucketResponse> createBucketHandler = new ResponseHandler<>();
            client.createBucket(createBucketRequest, createBucketHandler);
            createBucketHandler.waitForCompletion();
            log.debug("Bucket '{}' created successfully.", bucketName);
        }
    }
}
