package com.digitalchain.document_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentManagementService {
	public static void main(String[] args) {
		SpringApplication.run(DocumentManagementService.class, args);
	}
}
