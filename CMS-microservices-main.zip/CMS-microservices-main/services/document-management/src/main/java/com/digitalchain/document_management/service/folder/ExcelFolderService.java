package com.digitalchain.document_management.service.folder;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.document_management.dto.folder.CreateFolderDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.document_management.dto.folder.ParsedFolderDTO;
import com.digitalchain.document_management.repository.FoldersRepository;
import com.digitalchain.document_management.utils.ParseCsvFile;
import com.digitalchain.document_management.utils.ParseExcelFile;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class ExcelFolderService {

    @Autowired
    private FoldersService foldersService;

    @Autowired
    private FoldersRepository foldersRepository;

    /**
     * Processes an Excel file containing folder hierarchy and creates the corresponding folders in the system.
     *
     * @param file   The Excel file containing folder and parent folder information.
     * @param user The ID of the user performing the operation.
     * @throws Exception If there is an error during folder creation.
     */
    public void createFromExcelFile(InputStream file, String contentType, UUID parentFolderId, UserDTO user) throws Exception {
        log.info("Starting the parser for {}", contentType);
        List<ParsedFolderDTO> foldersToCreate;

        // Determine file type based on MIME type
        if (contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") || contentType.equals("application/vnd.ms-excel")) {
            log.info("Detected Excel file. Parsing as Excel.");
            foldersToCreate = ParseExcelFile.parse(file);  // Call Excel parser
        } else if (contentType.equals("text/csv")) {
            log.info("Detected CSV file. Parsing as CSV.");
            foldersToCreate = ParseCsvFile.parse(file);  // Call CSV parser
        } else {
            throw new IllegalArgumentException("Unsupported file type: " + contentType);
        }

        createFolder(foldersToCreate, parentFolderId, user);
    }

    /**
     * Iterates over the parsed folder list and creates folders and subfolders based on the hierarchy.
     *
     * @param parsedFolderDTOS The list of parsed folder data from the Excel file.
     * @param user           The ID of the user performing the folder creation.
     */
    private void createFolder(List<ParsedFolderDTO> parsedFolderDTOS, UUID mainParentFolderId, UserDTO user) {
        log.info("Starting folder creation process for {} folders by user {}", parsedFolderDTOS.size(), user.getUser_id());

        FolderDTO mainFolder = null;
        if (mainParentFolderId != null){
            mainFolder = foldersRepository.findFolderById(mainParentFolderId).orElseThrow();
        }

        for (ParsedFolderDTO parsedFolderDTO : parsedFolderDTOS) {
            log.info("Processing folder: {} and parent: {}", parsedFolderDTO.getFolderName(), parsedFolderDTO.getParentFolderName());
            UUID parentFolderId = null;

            // If the folder has a parent, attempt to find its parent folder's ID by its path
            if (parsedFolderDTO.getParentFolderName() != null && !parsedFolderDTO.getParentFolderName().isEmpty()) {
                log.info("Looking up parent folder for: {}", parsedFolderDTO.getParentFolderName());

                // Build the full path for the parent folder
                String path = buildFolderPath(parsedFolderDTO.getFolderName(), parsedFolderDTOS);
                if (mainFolder != null) {
                    path = mainFolder.getFolderPath() + path;
                }
                log.info("Resolved parent folder path: {}", path);

                if (!path.isEmpty()) {
                    FolderDTO folderDTO = foldersRepository.findFolderByPath(path);

                    if (folderDTO != null) {
                        parentFolderId = folderDTO.getFolderId();
                        log.info("Found parent folder with ID: {}", parentFolderId);
                    } else {
                        log.warn("Parent folder not found for path: {}", path);
                    }
                }
            }

            log.info("Creating folder: {} with parent folder ID: {}", parsedFolderDTO.getFolderName(), parentFolderId);

            try {
                // Create folder using the folder service
                foldersService.createFolder(
                        CreateFolderDTO.builder()
                                .folderName(parsedFolderDTO.getFolderName())
                                .parentFolderId(parentFolderId == null ? mainParentFolderId : parentFolderId)
                                .build(),
                        user
                );
                log.info("Successfully created folder: {}", parsedFolderDTO.getFolderName());
            } catch (Exception e) {
                log.error("Failed to create folder: {}. Error: {}", parsedFolderDTO.getFolderName(), e.getMessage(), e);
                throw e;
            }
        }

        log.info("Folder creation process completed for user: {}", user.getUser_id());
    }

    /**
     * Recursively builds the full folder path by finding the parent folder and appending its name.
     *
     * @param folderName       The name of the folder for which the path is being constructed.
     * @param parsedFolderDTOS The list of all parsed folder data from the Excel file.
     * @return The fully constructed folder path.
     */
    public String buildFolderPath(String folderName, List<ParsedFolderDTO> parsedFolderDTOS) {
        log.info("Building path for folder {}", folderName);
        // Find the folder by its name
        ParsedFolderDTO folder = parsedFolderDTOS.stream()
                .filter(f -> f.getFolderName().equals(folderName))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Folder not found: " + folderName));

        // If there is no parent folder, return an empty string (root folder)
        if (folder.getParentFolderName() == null) {
            return "";
        }

        // Recursively build the parent folder's path and append the parent folder's name
        String parentPath = buildFolderPath(folder.getParentFolderName(), parsedFolderDTOS);
        log.info("Built parent folder path: {}", parentPath + folder.getParentFolderName() + "/");

        return parentPath + folder.getParentFolderName() + "/";
    }
}
