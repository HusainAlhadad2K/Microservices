package com.digitalchain.document_management.service.folder;


import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.document_management.config.OCIConfig;
import com.digitalchain.document_management.exception.ResourceNotFoundException;
import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.repository.FileVersionRepository;
import com.digitalchain.document_management.repository.FilesRepository;
import com.digitalchain.document_management.repository.FoldersRepository;
import com.digitalchain.document_management.service.PermissionsService;
import com.digitalchain.document_management.service.file.DeleteFilesService;
import com.digitalchain.document_management.utils.FileLogger;
import com.digitalchain.document_management.utils.oci.OciObjectStorageUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
@Slf4j
public class DeleteFoldersService {

    @Autowired
    private FoldersRepository foldersRepository;

    @Autowired
    private FilesRepository filesRepository;

    @Autowired
    private FileVersionRepository fileVersionRepository;

    @Autowired
    private OciObjectStorageUtil ociObjectStorageUtil;

    @Autowired
    private DeleteFilesService deleteFilesService;

    @Autowired
    private OCIConfig ociConfig;

    @Autowired
    private FileLogger fileLogger;

    @Autowired
    private PermissionsService permissionsService;

    @Transactional
    public void softDeleteFolder(UUID id, UserDTO user) {
        try {
            Folder folder = foldersRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Folder with ID " + id + " not found"));

            String folderPath = folder.getFolderPath();

            List<Map<String, String>> deletedFilesInfo = ociObjectStorageUtil.deleteFolder(ociConfig.getObjectStorageBucket(), folderPath);

            for (Map<String, String> fileInfo : deletedFilesInfo) {
                String filePath = fileInfo.get("path");
                String versionId = fileInfo.get("versionId");

                filesRepository.deleteFileByPath(filePath, new Date(), user.getUser_id(), UUID.fromString(versionId));
            }

            foldersRepository.softDeleteFolderById(id, new Date(), user.getUser_id());
            foldersRepository.softDeleteFoldersByPath(folderPath + "%", new Date(), user.getUser_id(), id);

            fileLogger.log(folder, FileLogAction.DELETE, user);
        } catch (Exception e) {
            log.error("Failed to delete folder with ID: {}", id, e);
            throw new RuntimeException("Failed to delete folder", e);
        }
    }

    public Page<FolderDTO> getDeletedFolders(int page, int size, String sortBy, String sortDirection) {
        Sort.Direction direction = Sort.Direction.fromString(sortDirection);
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));
        return foldersRepository.findAllDeletedFolders(pageable);
    }

    @Transactional
    public void restoreDeletedFolder(UUID folderId, UserDTO user) throws Exception {
        FolderDTO folder = foldersRepository.findDeletedFolderById(folderId).orElseThrow(() -> new ResourceNotFoundException("Folder does not exist"));
        List<FileDTO> files = filesRepository.findFileByFolderPath(folder.getFolderPath() + "%");

        foldersRepository.restoreFolder(folderId, new Date(), user.getUser_id());
        foldersRepository.restoreFolderByPath(folder.getFolderPath() + "%", folderId, new Date(), user.getUser_id());

        for (FileDTO file : files) {
            deleteFilesService.restoreObject(file.getId(), user);
        }

        fileLogger.log(folder, FileLogAction.RESTORE, user);
    }

    @Transactional
    public void permanentlyDeleteFolder(UUID folderId, UserDTO user){
        FolderDTO folder = foldersRepository.findDeletedFolderById(folderId).orElseThrow(() -> new ResourceNotFoundException("Folder does not exist"));
        List<FileDTO> files = filesRepository.findFileByFolderPath(folder.getFolderPath() + "%");
        for (FileDTO file : files) {
            deleteFilesService.permanentlyDeleteFile(file.getId(), user);
        }

        foldersRepository.deleteById(folderId);
    }
}
