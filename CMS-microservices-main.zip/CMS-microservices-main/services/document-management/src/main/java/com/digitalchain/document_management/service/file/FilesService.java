package com.digitalchain.document_management.service.file;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.common.dto.files.LockInfoDTO;
import com.digitalchain.common.dto.files.SensitivityInfoDTO;
import com.digitalchain.document_management.config.OCIConfig;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.document_management.dto.file.FileDownloadDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.document_management.exception.ResourceNotFoundException;
import com.digitalchain.document_management.model.document.File;
import com.digitalchain.document_management.model.document.Folder;
import com.digitalchain.document_management.repository.FileVersionRepository;
import com.digitalchain.document_management.repository.FilesRepository;
import com.digitalchain.document_management.repository.FoldersRepository;
import com.digitalchain.document_management.utils.FileLogger;
import com.digitalchain.document_management.utils.oci.ObjectRetrievalMode;
import com.digitalchain.document_management.utils.oci.OciObjectStorageUtil;
import com.oracle.bmc.objectstorage.responses.GetObjectResponse;
import jakarta.mail.MessagingException;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.*;

@Service
@Slf4j
public class FilesService {
    @Autowired
    private FilesRepository filesRepository;
    @Autowired
    private FileVersionRepository fileVersionRepository;
    @Autowired
    private FoldersRepository foldersRepository;
    @Autowired
    private OciObjectStorageUtil ociObjectStorageUtil;
    @Autowired
    private OCIConfig ociConfig;
    @Autowired
    private FileVersionService fileVersionService;

    @Autowired
    private FileLogger fileLogger;

    @Transactional
    public FileDTO uploadFile(UUID folderId, UserDTO user, InputStream inputStream, String contentType, String fileName) {
        try {
            Optional<File> existingFile = filesRepository.findFileByFilenameAndFolderId(fileName, folderId);

            UUID fileId = existingFile.map(File::getId).orElse(UUID.randomUUID());
            UUID previousVersionId = existingFile.map(File::getLatestVersionId).orElse(null);

            Folder folder = folderId != null ? foldersRepository.findById(folderId).orElse(null) : null;

            String cloudFileName = folder != null ? folder.getFolderPath() + fileName : "/" + fileName;

            String versionId = ociObjectStorageUtil.uploadObject(
                    ociConfig.getObjectStorageBucket(),
                    cloudFileName,
                    null,
                    inputStream,
                    contentType
            );

            GetObjectResponse uploadedFile = ociObjectStorageUtil.getObject(ociConfig.getObjectStorageBucket(), cloudFileName, versionId);

            File savedFile = createOrUpdateFileRecord(existingFile, folder, user.getUser_id(), cloudFileName, fileId, UUID.fromString(versionId), contentType, fileName, uploadedFile.getContentLength());

            fileVersionService.createFileVersion(savedFile, UUID.fromString(versionId), previousVersionId, cloudFileName, contentType, uploadedFile.getContentLength());

            fileLogger.log(savedFile, FileLogAction.UPLOAD, user);

            return convertToFileDTO(savedFile);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public FileDTO copyFile(UUID fileId, UUID destinationFolderId, UserDTO user) throws Exception {
        File file = filesRepository.findById(fileId).orElseThrow(() -> new ResourceNotFoundException("File not found"));
        Folder destinationFolder = null;

        if (destinationFolderId != null){
            destinationFolder = foldersRepository.findById(destinationFolderId).orElseThrow(
                    () -> new ResourceNotFoundException("Destination folder not found")
            );
        }

        String newPath = destinationFolder == null ? "/" + file.getFile_name() : destinationFolder.getFolderPath() + file.getFile_name();

        // Use the reusable method for copying and creating new file entity
        File copiedFile = handleFileCopyOrMove(file, newPath, file.getFile_name(), destinationFolder, user, "copy");

        fileLogger.log(file, FileLogAction.COPY, user);
        // Convert the copied file to DTO and return
        return convertToFileDTO(copiedFile);
    }

    public FileDTO duplicateFile(UUID fileId, UserDTO user) throws Exception {
        File file = filesRepository.findById(fileId).orElseThrow(() -> new ResourceNotFoundException("File not found"));

        int duplicatedCount = file.getDuplicatedCount() + 1;

        String duplicatedFileName = generateDuplicatedFileName(file.getFile_name(), duplicatedCount);
        Folder destFolder = file.getFolder();
        String newPath = destFolder == null ? "/" + duplicatedFileName : destFolder.getFolderPath() + duplicatedFileName;

        // Increment duplicated count
        file.setDuplicatedCount(duplicatedCount);
        filesRepository.save(file);

        // Use the reusable method for copying and creating new file entity
        File duplicatedFile = handleFileCopyOrMove(file, newPath, duplicatedFileName, file.getFolder(), user, "duplication");

        fileLogger.log(file, FileLogAction.DUPLICATE, user);
        // Convert the duplicated file to DTO and return
        return convertToFileDTO(duplicatedFile);
    }

    public FileDownloadDTO getObject(UUID objectId, Optional<UUID> versionId, UserDTO user, Boolean isPreview) throws Exception {
        Optional<FileDTO> fileOpt = filesRepository.findFileById(objectId);

        if (fileOpt.isPresent()) {
            FileDTO file = fileOpt.get();

            String version = String.valueOf(versionId.orElse(file.getLatestVersionId()));

            InputStream stream = ociObjectStorageUtil.getObject(ociConfig.getObjectStorageBucket(), file.getFilePath(), version).getInputStream();

            fileLogger.log(file, isPreview ? FileLogAction.PREVIEW : FileLogAction.DOWNLOAD, user, UUID.fromString(version));
            return new FileDownloadDTO(stream, file.getFileName(), file.getFileType());
        } else {
            throw new ResourceNotFoundException("File not found");
        }
    }

    public List<FileDTO> getObjects(Optional<UUID> folderId, Optional<UUID> fileId) throws Exception {
        try {
            String ociPath = "/";  // Default path (root)

            FileDTO fileDTO = null;

            if (fileId.isPresent()) {
                fileDTO = filesRepository.findFileById(fileId.get())
                        .orElseThrow(() -> new Exception("File with ID " + fileId.get() + " not found"));

                ociPath = fileDTO.getFilePath();
            }

            if (folderId.isPresent()) {
                FolderDTO folder = foldersRepository.findFolderById(folderId.get()).orElseThrow(() -> new Exception("Folder not found"));
                if (fileDTO != null) {
                    log.debug("ID: " + fileDTO.getFolderId() + " " + folder.getFolderId());
                    if (!fileDTO.getFolderId().equals(folder.getFolderId())) {
                        throw new ResourceNotFoundException("File with ID " + fileDTO.getId() + " not found");
                    }
                }
                ociPath = Objects.equals(ociPath, "/") ? folder.getFolderPath() : ociPath;
            }

            List<String> ociObjects = ociObjectStorageUtil.listObjectsInFolder(
                    ociConfig.getObjectStorageBucket(),
                    ociPath,
                    ObjectRetrievalMode.FILES_ONLY,
                    "/"
            );

            return filesRepository.findFilesByPath(ociObjects);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private File handleFileCopyOrMove(File originalFile, String newPath, String newName, Folder destinationFolder, UserDTO user, String fileAction) throws Exception {
        log.info("Starting {} process for file with ID: {}", fileAction, originalFile.getId());

        // Copy/move the file in the OCI Object Storage
        GetObjectResponse copiedObject = ociObjectStorageUtil.copyObject(
                ociConfig.getObjectStorageBucket(),
                originalFile.getFile_path(),
                ociConfig.getObjectStorageBucket(),
                newPath,
                true
        );
        log.info("File successfully {} to new path: {}", fileAction, newPath);

        // Create a new UUID for the duplicated/moved file
        UUID newFileId = UUID.randomUUID();

        // Get the version ID from the copied/moved object
        UUID versionId = UUID.fromString(copiedObject.getVersionId());
        log.info("Version ID for the {} file: {}", fileAction, versionId);

        // Create a new File entity for the duplicated/moved file
        File newFile = new File();
        newFile.setId(newFileId);
        if (destinationFolder != null){
            newFile.setFolder(destinationFolder);  // Set the same folder as the original
        }
        newFile.setUser_id(user.getUser_id());
        newFile.setFile_name(newName);
        newFile.setFile_path(newPath);
        newFile.setFile_type(originalFile.getFile_type());
        newFile.setFile_size(originalFile.getFile_size());
        newFile.setLatestVersionId(versionId);
        log.info("New File entity created for {} file with ID: {}", fileAction, newFileId);

        // Save the new file entity to the repository
        File savedFile = filesRepository.save(newFile);
        log.info("{} file successfully saved with ID: {}", fileAction, newFileId);

        // Create a new version for the file
        fileVersionService.createFileVersion(savedFile, versionId, null, newPath, null, null);  // Null for MimeBodyPart, adjust if needed
        log.info("File version created for {} file with ID: {}", fileAction, newFileId);

        return savedFile;
    }

    // Method for converting a File entity to FileDTO
    private FileDTO convertToFileDTO(File file) {
        SensitivityInfoDTO sensitivityInfo = SensitivityInfoDTO.builder()
                .sensitive(file.getIsSensitive())
                .sensitivityScale(file.getSensitivityScale())
                .markedAsSensitiveBy(file.getMarkedAsSensitiveBy())
                .markedAsSensitiveAt(file.getMarkedAsSensitiveAt())
                .build();
        LockInfoDTO lockInfo = LockInfoDTO.builder()
                .locked(file.getIsLocked())
                .lockedBy(file.getLockedBy())
                .lockedAt(file.getLockedAt())
                .build();

        return new FileDTO(
                file.getId(),
                file.getFile_name(),
                file.getFile_path(),
                file.getFile_type(),
                file.getFile_size(),
                Optional.ofNullable(file.getFolder()).map(Folder::getFolder_id).orElse(null),
                Optional.ofNullable(file.getFolder()).map(Folder::getFolder_name).orElse("Root"),
                Optional.ofNullable(file.getFolder()).map(Folder::getFolderPath).orElse(null),
                file.getLatestVersionId(),
                null,
                lockInfo,
                sensitivityInfo,
                file.getUser_id(),
                file.getCreated_at(),
                file.getUpdatedBy(),
                file.getUpdated_at()
        );
    }

    private String generateDuplicatedFileName(String originalFileName, int duplicatedCount) {
        // Find the last dot (.) in the file name to split the base name and the extension
        int dotIndex = originalFileName.lastIndexOf(".");

        // If the file has an extension (i.e., the dot is found)
        if (dotIndex != -1) {
            String baseName = originalFileName.substring(0, dotIndex);  // Get the base name (before the dot)
            String extension = originalFileName.substring(dotIndex);    // Get the extension (including the dot)
            return baseName + "(" + duplicatedCount + ")" + extension;  // Combine base name, duplicated count, and extension
        } else {
            // If no extension is found, just append the duplicated count
            return originalFileName + "(" + duplicatedCount + ")";
        }
    }

    private File createOrUpdateFileRecord(Optional<File> existingFile, Folder folder, String userId, String filePath, UUID fileId, UUID versionId, String contentType, String fileName, Long size) throws MessagingException {
        File fileRecord;
        File savedFile;
        if (existingFile.isPresent()) {
            fileRecord = existingFile.get();
            fileRecord.setFile_path(filePath);
            fileRecord.setFile_type(contentType);
            fileRecord.setFile_size(String.valueOf(size));
            fileRecord.setUpdatedBy(userId);
            fileRecord.setUpdated_at(new Date());
            fileRecord.setLatestVersionId(versionId);

            filesRepository.updateFileRecord(
                    fileRecord.getId(),
                    filePath,
                    contentType,
                    String.valueOf(size),
                    new Date()
            );
            savedFile = fileRecord;
        } else {
            fileRecord = new File();
            fileRecord.setId(fileId);
            fileRecord.setFolder(folder);
            fileRecord.setUser_id(userId);
            fileRecord.setFile_name(fileName);
            fileRecord.setFile_path(filePath);
            fileRecord.setFile_type(contentType);
            fileRecord.setFile_size(String.valueOf(size));
            fileRecord.setLatestVersionId(versionId);

            savedFile = filesRepository.save(fileRecord);
        }

        return savedFile;
    }
}