package com.digitalchain.document_management.exception;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class GlobalErrorHandler extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        from("direct:error")
                .log("Error occurred: ${exception.message}")
                .process(new GlobalErrorProcessor())
                .setHeader(Exchange.HTTP_RESPONSE_CODE, simple("${in.header." + Exchange.HTTP_RESPONSE_CODE + "}"))
                .setHeader(Exchange.CONTENT_TYPE, simple("${in.header." + Exchange.CONTENT_TYPE + "}"))
                .choice()
                .when(simple("${header.RestBindingMode} != null && ${header.RestBindingMode} == 'off'"))
                .marshal().json()
                .log("Responding with status: ${header.CamelHttpResponseCode} and body: ${body}")
                .end();
    }
}
