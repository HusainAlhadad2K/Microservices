package com.digitalchain.document_management.repository;

import com.digitalchain.document_management.dto.file.FileVersionDTO;
import com.digitalchain.document_management.model.document.FileVersion;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface FileVersionRepository extends JpaRepository<FileVersion, UUID> {
    @Query("SELECT new com.digitalchain.document_management.dto.file.FileVersionDTO(" +
            "fv.versionId, fv.file.id, fv.versionNumber, fv.filePath, fv.fileType, " +
            "fv.fileSize, fv.deleted, fv.deletedAt, fv.createdAt, fv.updatedAt) " +
            "FROM FileVersion fv WHERE fv.file.id = ?1")
    List<FileVersionDTO> findByFileId(UUID fileId);

    @Query("SELECT fv.versionNumber FROM FileVersion fv WHERE fv.versionId = ?1")
    Optional<Integer> findVersionNumberById(UUID versionId);

    @Modifying
    @Transactional
    @Query("UPDATE FileVersion fv SET fv.deleted = ?2, fv.deletedAt = ?3 WHERE fv.file.id = ?1")
    void toggleFileVersionsDeletion(UUID fileId, boolean deleted, Date deletedAt);

    void deleteByFileId(UUID fileId);
}
