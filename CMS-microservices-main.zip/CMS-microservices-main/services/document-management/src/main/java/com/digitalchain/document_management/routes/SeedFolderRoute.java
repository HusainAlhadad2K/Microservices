package com.digitalchain.document_management.routes;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.document_management.config.BaseRouteBuilder;
import com.digitalchain.document_management.dto.folder.DuplicateSeedFolderDTO;
import com.digitalchain.document_management.dto.folder.SeedFolderDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.document_management.service.folder.SeedFolderService;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
@Slf4j
public class SeedFolderRoute extends BaseRouteBuilder {

    @Autowired
    private SeedFolderService seedFolderService;

    @Override
    public void configure() throws Exception {
        super.configure();

        rest("/folders")
                // Route to mark folder as a seed folder
                .patch("/{folderId}/seed")
                .description("Mark folder as a seed folder (template).")
                .param().name("folderId").type(RestParamType.path).description("The ID of the folder").dataType("UUID").endParam()
                .param().name("isSeedFolder").type(RestParamType.query).description("If the folder is seed or not").dataType("Boolean").endParam()
                .responseMessage().code(200).message("Folder marked as seed folder successfully").responseModel(String.class).endResponseMessage()
                .to("direct:markAsSeedFolder")

                .get("/seed")
                .description("Get all seed folders.")
                .responseMessage().code(200).message("Seed folders retrieved successfully").responseModel(FolderDTO[].class).endResponseMessage()
                .to("direct:getAllSeedFolders")

                // Route to duplicate a seed folder
                .post("/{seedFolderId}/seed/duplicate")
                .description("Duplicate a seed folder to a new location.")
                .param().name("seedFolderId").type(RestParamType.path).description("The ID of the seed folder").dataType("UUID").endParam()
                .param().name("targetFolderId").type(RestParamType.body).description("The ID of the target folder").dataType("UUID").endParam()
                .param().name("targetFolderName").type(RestParamType.body).description("The Name of the target folder").dataType("String").endParam()
                .type(DuplicateSeedFolderDTO.class)
                .responseMessage().code(201).message("Seed folder duplicated successfully").responseModel(FolderDTO.class).endResponseMessage()
                .to("direct:duplicateSeedFolder");

        // Process to mark a folder as seed folder
        from("direct:markAsSeedFolder")
                .routeId("markAsSeedFolder")
                .process(this::markFolderAsSeed)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                .setBody(constant("Folder marked as seed folder successfully"));

        // Process to duplicate a seed folder
        from("direct:duplicateSeedFolder")
                .routeId("duplicateSeedFolder")
                .process(this::duplicateSeedFolder)
                .log("Body ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(201))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:getAllSeedFolders")
                .routeId("getAllSeedFolders")
                .process(this::getAllSeedFolders)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
    }

    /**
     * Process method for marking a folder as a seed folder.
     */
    private void markFolderAsSeed(Exchange exchange) {
        UUID folderId = exchange.getIn().getHeader("folderId", UUID.class);
        Boolean isSeedFolder = exchange.getIn().getHeader("isSeedFolder", Boolean.class);
        log.info("Marking folder with ID {} as a seed folder", folderId);

        seedFolderService.updateIsSeedFolder(folderId, isSeedFolder);
    }

    private void getAllSeedFolders(Exchange exchange) {
        log.info("Fetching all seed folders");

        List<SeedFolderDTO> seedFolders = seedFolderService.getSeedFolders();
        exchange.getIn().setBody(seedFolders);
    }

    /**
     * Process method for duplicating a seed folder.
     */
    private void duplicateSeedFolder(Exchange exchange) throws Exception {
        DuplicateSeedFolderDTO duplicateSeedFolderDTO = exchange.getIn().getBody(DuplicateSeedFolderDTO.class);
        UUID seedFolderId = exchange.getIn().getHeader("seedFolderId", UUID.class);

        UserDTO user = exchange.getProperty("user", UserDTO.class);

        log.info("Duplicating seed folder with ID {} to target folder with ID {}", seedFolderId, duplicateSeedFolderDTO.getTargetFolderId());

        seedFolderService.duplicateSeedFolder(seedFolderId, duplicateSeedFolderDTO.getTargetFolderId(), duplicateSeedFolderDTO.getTargetFolderName(), user);
        exchange.getIn().setBody("Seed folder created successfully");
    }
}
