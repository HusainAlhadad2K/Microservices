package com.digitalchain.document_management.service;


import com.digitalchain.common.dto.files.FileLogDTO;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FileLogProducerService {

    @Autowired
    private ProducerTemplate producerTemplate;

    public void sendFileLog(FileLogDTO logDTO) {
        // Send the log message to the Kafka topic through the Camel route
        producerTemplate.sendBody("direct:sendFileLog", logDTO);
    }
}
