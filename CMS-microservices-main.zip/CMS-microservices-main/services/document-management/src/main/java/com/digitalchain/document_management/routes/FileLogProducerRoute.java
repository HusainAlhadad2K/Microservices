package com.digitalchain.document_management.routes;


import com.digitalchain.document_management.config.BaseRouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class FileLogProducerRoute extends BaseRouteBuilder {
    @Override
    public void configure() throws Exception {
        super.configure();
        // Kafka Producer route for sending log messages to Kafka topic
        from("direct:sendFileLog")
                .routeId("sendFileLogRoute")
                .marshal().json()  // Convert the object to JSON
                .to("kafka:{{file.activity.logging.topic}}?brokers={{camel.component.kafka.brokers}}")
                .log("Sent message to Kafka: ${body}");
    }
}
