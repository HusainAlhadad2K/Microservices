package com.digitalchain.document_management.dto.file;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FileVersionDTO {
    private UUID versionId;
    private UUID fileId;  // To represent the associated file's ID
    private int versionNumber;
    private String filePath;
    private String fileType;
    private String fileSize;
    private Boolean deleted;
    private Date deletedAt;
    private Date createdAt;
    private Date updatedAt;
}
