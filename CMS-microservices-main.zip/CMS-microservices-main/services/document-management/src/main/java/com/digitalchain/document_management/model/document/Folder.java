package com.digitalchain.document_management.model.document;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;
import java.util.Set;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "folders")
public class Folder {
    @Id
    @GeneratedValue
    @Column(name = "folder_id")
    private UUID folder_id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_folder_id")
    private Folder parent_folder;

    @Column(name = "user_id")
    private String user_id;

    @Column(name = "folder_name", nullable = false)
    private String folder_name;

    @Column(name = "folder_path")
    private String folderPath;

    @Column(name = "is_seed_folder")
    private Boolean isSeedFolder = false;

    @OneToMany(mappedBy = "parent_folder", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private Set<Folder> sub_folders;

    @OneToMany(mappedBy = "folder", cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    private Set<File> files;

    @Column(name = "duplicated_count")
    private Integer duplicatedCount = 0;

    @Column(name = "is_project")
    private Boolean isProject = false;

    @Column(name = "project_created_by")
    private String projectCreatedBy;

    @Column(name = "project_created_at")
    private Date projectCreatedAt;

    @Column(name = "project_status")
    private String projectStatus;

    // New fields for project details
    @Column(name = "project_name")
    private String projectName;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "description")
    private String description;

    @Column(name = "start_date")
    private Date startDate;

    @Column(name = "end_date")
    private Date endDate;

    // New fields for project address
    @Column(name = "address_line_1")
    private String addressLine1;

    @Column(name = "address_line_2")
    private String addressLine2;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "country")
    private String country;

    @Column(name = "zip_code")
    private String zipCode;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date created_at;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updated_at;

    @Column(name = "deleted", nullable = false)
    private boolean deleted = false;

    @Column(name = "deleted_at")
    private Date deletedAt;

    @Column(name = "deleted_by")
    private String deletedBy;

    @Column(name = "deleted_by_folder")
    private Boolean deletedByFolder = false;

    @Column(name = "deleted_by_folder_id")
    private UUID deletedByFolderId;

    @Column(name = "restored_at")
    private Date restoredAt;

    @Column(name = "restored_by")
    private String restoredBy;
}
