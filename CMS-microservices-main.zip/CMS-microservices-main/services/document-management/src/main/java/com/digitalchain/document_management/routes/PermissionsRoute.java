package com.digitalchain.document_management.routes;

import com.digitalchain.document_management.config.BaseRouteBuilder;
import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

@Component
public class PermissionsRoute extends BaseRouteBuilder {

    @Override
    public void configure() throws Exception {
        // Define the route for validating folder access
        from("direct:validateFolderAccess")
                .routeId("validateFolderAccess")
                .setHeader(Exchange.HTTP_METHOD, constant("POST")) // Set HTTP method to POST
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json")) // Set content type to JSON
                .setHeader("Authorization", simple("${header.jwtToken}")) // Pass Authorization header
                .marshal().json()
                .toD("{{application.config.permissions-url}}/validate-folder-access") // Dynamic endpoint based on configuration
                .log("{{application.config.permissions-url}}/validate-folder-access")
                .choice()
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(200))
                .log("Folder access validated successfully")
                .setBody(simple("${body}")) // Use the response body as the output
                .otherwise()
                .log("Failed to validate folder access")
                .setBody(constant(null)) // Set body to null if validation fails
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(400)) // Optionally set a failure response code
                .end();
    }
}
