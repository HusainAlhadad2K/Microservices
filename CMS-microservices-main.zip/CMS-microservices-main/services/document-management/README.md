# Construction CMS API

This project is a RESTful API for managing files within a Construction CMS, built using Java Spring Boot and integrated with Oracle Cloud Infrastructure (OCI) Object Storage. It provides endpoints for file uploading, downloading, listing, and versioning.

For detailed API documentation, please visit the [Swagger UI](http://localhost:8080/swagger-ui.html).





# Keycloak Authentication and Authorization

## Introduction
This project is a Spring Boot application that demonstrates how to integrate Keycloak for securing REST APIs. The application provides several endpoints protected by Keycloak, and it includes configurations to handle JWT tokens.

## Prerequisites
Before you can run this application, you need to have the following:
- JDK 17 or later
- Maven 3.6.3 or later
- Keycloak server running locally or on a remote server

## Project Structure
The project contains the following main packages:
- `com.KeycloakApp.KeycloakApp.config`: Contains configuration classes, including RestTemplate configuration.
- `com.KeycloakApp.KeycloakApp.controller`: Contains REST controllers.
- `com.KeycloakApp.KeycloakApp.security`: Contains security-related classes and configurations.

## Running the Application
To run the application, use the following Maven command:
```sh
mvn spring-boot:run
```

## Testing with Postman
You can test the endpoints using Postman. Below are the details on how to do that:

### 1. Obtain an Access Token
Before accessing the secured endpoints, you need to obtain an access token from Keycloak. Follow these steps:

- **POST Request**
- URL Format: `http://<KEYCLOAK_SERVER>:<PORT>/realms/<REALM_NAME>/protocol/openid-connect/token`
- URL: `http://localhost:8081/realms/MySuperApplicationRealm/protocol/openid-connect/token`
- Headers:
  - `Content-Type: application/x-www-form-urlencoded`
- Body (x-www-form-urlencoded):
  - `grant_type`: `password`
  - `client_id`: `<CLIENT_ID>`
  - `username`: `<USERNAME>`
  - `password`: `<PASSWORD>`

The response will contain an `access_token` which you will use to authenticate your requests to the secured endpoints.

![img.png](img.png)

### 2. Accessing the Endpoints
Use the obtained `access_token` to access the secured endpoints. Add the token to the `Authorization` header in the following format: `Bearer <access_token>`

#### Endpoint: `/api/hello`
- **GET Request**
- URL: `http://localhost:8081/api/hello`
- Description: This endpoint is public and does not require authentication.

#### Endpoint: `/api/admin`
- **GET Request**
- URL: `http://localhost:8081/api/admin`
- Description: This endpoint requires an admin role.
- Headers:
  - `Authorization`: `Bearer <access_token>`

#### Endpoint: `/api/user`
- **GET Request**
- URL: `http://localhost:8081/api/user`
- Description: This endpoint requires a user role.
- Headers:
  - `Authorization`: `Bearer <access_token>`

#### Endpoint: `/api/roles`
- **GET Request**
- URL: `http://localhost:8081/api/roles`
- Description: This endpoint returns the roles of the authenticated user.
- Headers:
  - `Authorization`: `Bearer <access_token>`
