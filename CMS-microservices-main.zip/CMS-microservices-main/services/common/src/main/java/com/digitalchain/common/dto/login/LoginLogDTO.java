package com.digitalchain.common.dto.login;

import com.digitalchain.common.dto.AccessMethod;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@Data
@NoArgsConstructor
@Builder
public class LoginLogDTO {
    private LoginLogAction action;  // Action performed on the file (e.g., "Upload", "Delete", "Preview", "Download")
    private String userId;        // ID of the user who performed the action
    private String userName;      // Name of the user (optional, if available)
    private String device;        // Device used to perform the action (e.g., "Web UI", "Mobile App")
    private AccessMethod accessMethod;  // Method of access (e.g., "System", "Web UI")
    private String ipAddress;     // IP address from where the action was performed
    private Date actionTime;      // Timestamp of the action
    private String actionInfo;    // Additional info about the action (e.g., success/failure messages)
    private String logoutAt;
}
