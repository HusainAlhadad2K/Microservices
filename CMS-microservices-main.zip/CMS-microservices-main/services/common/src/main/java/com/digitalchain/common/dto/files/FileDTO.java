package com.digitalchain.common.dto.files;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileDTO {
    private UUID id;
    private String fileName;
    private String filePath;
    private String fileType;
    private String fileSize;
    private UUID folderId;
    private String folderName;
    private String folderPath;
    private UUID latestVersionId;

    @JsonIgnore
    private UUID deletedVersionId;

    private LockInfoDTO lockInfo;   // Nested LockInfoDTO
    private SensitivityInfoDTO sensitivityInfo; // Nested SensitivityInfoDTO

    private String createdBy;
    private Date createdAt;

    private String updatedBy;
    private Date updatedAt;
}