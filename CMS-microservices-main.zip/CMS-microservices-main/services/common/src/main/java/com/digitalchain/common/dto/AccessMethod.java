package com.digitalchain.common.dto;


public enum AccessMethod {
    WEB
}
