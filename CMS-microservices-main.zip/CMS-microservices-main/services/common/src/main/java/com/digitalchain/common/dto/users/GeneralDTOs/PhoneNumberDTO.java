package com.digitalchain.common.dto.users.GeneralDTOs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PhoneNumberDTO {
    private String value;
    private Boolean primary;
    private String type;
}
