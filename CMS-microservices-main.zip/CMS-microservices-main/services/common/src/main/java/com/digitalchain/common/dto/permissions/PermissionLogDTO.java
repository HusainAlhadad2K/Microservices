package com.digitalchain.common.dto.permissions;


import com.digitalchain.common.enums.permissions.ChangeType;
import com.digitalchain.common.enums.permissions.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@AllArgsConstructor
@Data
@NoArgsConstructor
@Builder
public class PermissionLogDTO {
    private UUID folderId;
    private String folderPath;
    private ChangeType changeType;
    private String changedFor;
    private Role previousRole;
    private Role newRole;
    private String changedById;
    private String changedByName;
    private String changedByIp;
    private Date actionTime;
    private String actionInfo;
}
