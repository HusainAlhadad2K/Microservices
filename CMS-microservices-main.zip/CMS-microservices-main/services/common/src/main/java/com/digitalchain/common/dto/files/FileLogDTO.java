package com.digitalchain.common.dto.files;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileLogDTO {
    private UUID fileId;         // ID of the file
    private String filePath;      // Path where the file is stored
    private FileLogAction action;  // Action performed on the file (e.g., "Upload", "Delete", "Preview", "Download")
    private String userId;        // ID of the user who performed the action
    private String userName;      // Name of the user (optional, if available)
    private String device;        // Device used to perform the action (e.g., "Web UI", "Mobile App")
    private String accessMethod;  // Method of access (e.g., "System", "Web UI")
    private String ipAddress;     // IP address from where the action was performed
    private Date actionTime;      // Timestamp of the action
    private String actionInfo;    // Additional info about the action (e.g., success/failure messages)
    private String checksum;      // Optional: file checksum if needed for file validation
    private UUID fileVersion;   // Version of the file if versioning is supported
}
