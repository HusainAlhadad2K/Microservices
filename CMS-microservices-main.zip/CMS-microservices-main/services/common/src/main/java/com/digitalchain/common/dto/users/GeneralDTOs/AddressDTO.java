package com.digitalchain.common.dto.users.GeneralDTOs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressDTO {
    private String streetAddress;  // Street address part of the user's address
    private String locality;       // City or locality
    private String region;         // State or region
    private String postalCode;     // Postal or zip code
    private String country;        // Country code (ISO 3166-1 Alpha-2 code)
    private String type;           // Address type (e.g., Work, Home)
    private Boolean primary;       // Is this the primary address?
}
