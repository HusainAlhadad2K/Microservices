package com.digitalchain.common.dto.folders;

import com.digitalchain.common.enums.permissions.Role;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
public class FolderDTO {
    private UUID folderId;
    private String folderName;
    private UUID parentFolderId;
    private String parentFolderName;
    private String folderPath;
    private String userId;
    private Date createdAt;
    private Date updatedAt;

    private boolean isExpandable;
    private boolean isSeedFolder;
    private ProjectInfoDTO projectInfo;
    private Role role;

    public FolderDTO(UUID folderId, String folderName, UUID parentFolderId, String parentFolderName, String folderPath, String userId, Date createdAt, Date updatedAt, boolean isSeedFolder, ProjectInfoDTO projectStatus) {
        this.folderId = folderId;
        this.folderName = folderName;
        this.parentFolderId = parentFolderId;
        this.parentFolderName = parentFolderName;
        this.folderPath = folderPath;
        this.userId = userId;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.isSeedFolder = isSeedFolder;
        this.projectInfo = projectStatus;
    }
}
