package com.digitalchain.common.enums.permissions;

public enum Role {
    ADMIN,
    NONE,
    FULL,
    OWNER,
    VIEW
}
