package com.digitalchain.common.dto.users;


import lombok.Data;
import java.util.List;

@Data
public class GroupResponseDTO {
    private String groupId;
    private String displayName;
    private String created;
    private List<String> userIds;  // Store the user IDs of members
}

