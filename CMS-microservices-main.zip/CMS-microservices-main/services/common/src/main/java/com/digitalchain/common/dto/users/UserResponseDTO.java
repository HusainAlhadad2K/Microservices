package com.digitalchain.common.dto.users;

import com.digitalchain.common.dto.users.GeneralDTOs.AddressDTO;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserResponseDTO {
    private String userId;
    private String name;
    private String email;
    private String userName;
    private String created;
    private String lastModified;
    private String phoneNumber;
    private Boolean active;
    private String position;
    private String role;
    private String department;
    private List<AddressDTO> addresses;
    private String honorificPrefix;
    private String honorificSuffix;
    private String title;
    private String description;
}
