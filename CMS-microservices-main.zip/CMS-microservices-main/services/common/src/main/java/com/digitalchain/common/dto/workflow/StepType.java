package com.digitalchain.common.dto.workflow;

public enum StepType {
    TODO,
    REVIEW,
    APPROVE
}
