package com.digitalchain.common.dto.login;

import lombok.Getter;

@Getter
public enum LoginLogAction {
    LOGIN("Login"),
    LOGOUT("Logout"),
    FAILED_ATTEMPT("Failed Attempt");

    private final String description;

    LoginLogAction(String description) {
        this.description = description;
    }
}
