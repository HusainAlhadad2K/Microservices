package com.digitalchain.common.dto.workflow;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkflowLogDTO implements Serializable {
    private UUID workflowId;
    private String userId;
    private String fileId;
    private String folderId;
    private WorkflowAction action;
    private String workflowType;
    private StepType stepType;
    private String message;
    private Date createdAt;
}