package com.digitalchain.common.dto.workflow;

import lombok.Getter;

@Getter
public enum WorkflowAction {
    // Workflow related actions
    WORKFLOW_CREATED("Workflow created"),
    WORKFLOW_UPDATED("Workflow updated"),
    WORKFLOW_DELETED("Workflow deleted"),

    // Approval related actions
    APPROVAL_TASK_APPROVED("Approval task approved"),
    APPROVAL_TASK_CANCELLED("Approval task cancelled"),
    APPROVAL_TASK_REJECTED("Approval task rejected"),

    // TODO related actions
    TODO_TASK_COMPLETED("To-Do task completed"),

    REVIEW_TASK_COMPLETED("Review task completed"),
    REVIEW_TASK_CANCELED("Review task canceled"),

    // Comment related actions
    COMMENT_ADDED("Comment added"),

    // Step related actions
    STEP_ACTIVATED("Step activated"),
    STEP_COMPLETED("Step completed");

    private final String description;

    WorkflowAction(String description) {
        this.description = description;
    }
}
