package com.digitalchain.common.dto.links;

import java.util.Date;
import java.util.UUID;

import com.digitalchain.common.dto.AccessMethod;
import com.digitalchain.common.dto.LocationDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class LinkLogDTO {
    private UUID link_id;
    private UUID target_id;
    private String target_type;
    private String target_name;
    private String userId;        // ID of the user who performed the action if available
    private String userName;      // Name of the user (optional, if available)
    private String device;        // Device used to perform the action (e.g., "Web UI", "Mobile App")
    private AccessMethod accessMethod;  // Method of access (e.g., "System", "Web UI")
    private String ipAddress;     // IP address from where the action was performed
    private String city;
    private String country;
    private Date actionTime;      // Timestamp of the action
}
