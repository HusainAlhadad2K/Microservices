package com.digitalchain.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDTO {
    private String user_id;
    private String user_displayname;
    private String sub;
    private String ipAddress;
    private String userRole;

    @JsonIgnore
    private transient String jwtToken;

    @Override
    public String toString() {
        return "UserDTO{" +
                "user_id='" + user_id + '\'' +
                ", user_displayname='" + user_displayname + '\'' +
                ", sub='" + sub + '\'' +
                ", ipAddress='" + ipAddress + '\'' +
                '}';
    }
}
