package com.digitalchain.common.dto.files;

import lombok.Getter;

@Getter
public enum FileLogAction {
        CREATE_FOLDER("Folder created"),
        UPLOAD("File uploaded"),
        PREVIEW("File previewed"),
        DOWNLOAD("File downloaded"),
        DELETE("File deleted"),
        RENAME("File renamed"),
        RESTORE("File restored"),
        DUPLICATE("File duplicated"),
        COPY("File copied"),
        MOVE("Filer Moved");

        private final String description;

        FileLogAction(String description) {
                this.description = description;
        }
}