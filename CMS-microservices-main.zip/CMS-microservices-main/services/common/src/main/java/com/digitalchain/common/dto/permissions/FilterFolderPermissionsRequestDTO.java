package com.digitalchain.common.dto.permissions;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FilterFolderPermissionsRequestDTO {
    private Map<UUID, String> folderIdPathMap;
}
