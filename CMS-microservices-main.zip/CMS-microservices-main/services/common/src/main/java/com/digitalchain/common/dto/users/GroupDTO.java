package com.digitalchain.common.dto.users;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GroupDTO {
    private String groupId;
    private String displayName;
    @JsonInclude(JsonInclude.Include.NON_NULL) // Only include if non-null
    private String created;


}
