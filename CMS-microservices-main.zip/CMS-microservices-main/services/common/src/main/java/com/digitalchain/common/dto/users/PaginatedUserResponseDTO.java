package com.digitalchain.common.dto.users;

import com.digitalchain.common.dto.users.UserResponseDTO;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaginatedUserResponseDTO {
    private List<UserResponseDTO> users;
    private int totalResults;
    private int startIndex;
    private int itemsPerPage;
    private int currentPage;
    private int totalPages;
}

