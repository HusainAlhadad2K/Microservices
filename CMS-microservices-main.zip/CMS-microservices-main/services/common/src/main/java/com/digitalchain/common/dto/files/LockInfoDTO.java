package com.digitalchain.common.dto.files;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LockInfoDTO {
    private boolean locked;
    private String lockedBy;
    private Date lockedAt;
}
