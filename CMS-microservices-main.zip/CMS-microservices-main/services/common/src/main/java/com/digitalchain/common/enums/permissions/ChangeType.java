package com.digitalchain.common.enums.permissions;

public enum ChangeType {
    FOR_GROUP,
    VIA_GROUP,
    FOR_USER
}