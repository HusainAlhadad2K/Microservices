package com.digitalchain.common.dto.users;

import com.digitalchain.common.dto.users.GeneralDTOs.AddressDTO;
import com.digitalchain.common.dto.users.GeneralDTOs.EmailDTO;
import com.digitalchain.common.dto.users.GeneralDTOs.PhoneNumberDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDetailsDTO {
    private String userId;
    private String userName;
    private String givenName;
    private String familyName;
    private String middleName;
    private String honorificPrefix;
    private String honorificSuffix;
    private String title;
    private String description;
    private String preferredLanguage;
    private String timezone;
    private List<EmailDTO> emails;
    private List<PhoneNumberDTO> phoneNumbers;
    private String department;
    private String division;
    private String employeeNumber;
    private String costCenter;
    private String organizationName;
    private List<AddressDTO> addresses;
    private String userType;
    private String role;
    private List<GroupDTO> groups;
    private List<GroupDTO> position;

}
