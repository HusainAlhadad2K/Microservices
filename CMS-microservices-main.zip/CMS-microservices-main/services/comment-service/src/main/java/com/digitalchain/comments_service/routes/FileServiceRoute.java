package com.digitalchain.comments_service.routes;

import com.digitalchain.comments_service.config.BaseRouteBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class FileServiceRoute extends BaseRouteBuilder {
    @Value("${application.config.document-url}")
    private String documentUrl;

    @Override
    public void configure() throws Exception {
        super.configure();
        // Route to check if a file exists by fileId
        from("direct:validateFile")
                .routeId("validateFileRoute")
                .log("Validating file with ID: ${header.fileId}")

                // Start the doTry block for handling risky operations
                .doTry()
                // Communicate with the file service (assuming it exposes a REST API)
                .toD(documentUrl + "?fileId=${header.fileId}&bridgeEndpoint=true")

                // Process the response to check if the file exists (HTTP 200)
                .choice()
                .when(header(Exchange.HTTP_RESPONSE_CODE).isEqualTo(200))
                .log("File exists.")
                .otherwise()
                .log("File does not exist. Throwing an exception.")
                .throwException(new RuntimeException("File not found or other error occurred."))
                .endChoice()
                .endDoTry()

                // Catching HttpOperationFailedException specifically, e.g., for 4xx and 5xx errors
                .doCatch(HttpOperationFailedException.class)
                .process(exchange -> {
                    HttpOperationFailedException cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, HttpOperationFailedException.class);
                    int statusCode = cause.getStatusCode();

                    if (statusCode == 404) {
                        log.warn("File not found (404) with ID: ${header.fileId}");
                        throw new RuntimeException("File not found (404).");
                    } else {
                        log.error("HTTP operation failed with status code: " + statusCode);
                        throw new RuntimeException("HTTP operation failed with status code: " + statusCode);
                    }
                })
                .end();
    }
}
