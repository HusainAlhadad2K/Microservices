package com.digitalchain.comments_service.service;

import com.digitalchain.comments_service.dto.CreateComment;
import com.digitalchain.comments_service.model.Comments;
import com.digitalchain.comments_service.repository.CommentsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
public class CommentsService {
    @Autowired
    private CommentsRepository commentsRepository;

    public Comments saveComment(CreateComment createComment, String userId){
        Comments.CommentsBuilder comment = Comments.builder()
                .commentId(UUID.randomUUID())
                .comment(createComment.getComment())
                .taggedUserIds(createComment.getTaggedUserIds())
                .userId(userId)
                .createdAt(new Date());

        if (createComment.getFileId() != null){
            comment.fileId(createComment.getFileId());
        }
        if (createComment.getWorkflowId() != null){
            comment.workflowId(createComment.getWorkflowId());
        }

        return commentsRepository.save(comment.build());
    }

    public Page<Comments> getCommentsByFileId(UUID fileId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size); // Create pageable object
        return commentsRepository.findByFileId(fileId, pageable);
    }
    public Page<Comments> getCommentsByWorkflowId(UUID workflowId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size); // Create pageable object
        return commentsRepository.findByWorkflowId(workflowId, pageable);
    }
}
