package com.digitalchain.comments_service.exception;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class ExceptionDetails {
    private final Integer errorCode;
    private final String errorName;
}
