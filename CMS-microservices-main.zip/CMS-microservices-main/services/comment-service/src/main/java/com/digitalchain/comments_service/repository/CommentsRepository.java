package com.digitalchain.comments_service.repository;

import com.digitalchain.comments_service.model.Comments;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.UUID;

public interface CommentsRepository extends MongoRepository<Comments, String> {
    Page<Comments> findByFileId(UUID fileId, Pageable pageable);
    Page<Comments> findByWorkflowId(UUID workflowId, Pageable pageable);
}
