package com.digitalchain.comments_service.dto;

import jakarta.validation.ValidationException;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateComment {
    @NotNull(message = "Comment is required")
    private String comment;

    private UUID fileId;
    private UUID workflowId;

    private List<String> taggedUserIds;

    public void validate() {
        if (fileId == null && workflowId == null) {
            throw new ValidationException("Either fileId or workflowId must be provided");
        }
        if (fileId != null && workflowId != null) {
            throw new ValidationException("Only one of fileId or workflowId must be provided");
        }
    }
}
