package com.digitalchain.comments_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorDTO {
    private String errorCode;
    private String errorMessage;
    private Date timestamp;
    private String details;
}
