package com.digitalchain.comments_service.routes;

import com.digitalchain.comments_service.config.BaseRouteBuilder;
import com.digitalchain.comments_service.dto.CreateComment;
import com.digitalchain.comments_service.dto.UserDTO;
import com.digitalchain.comments_service.model.Comments;
import com.digitalchain.comments_service.service.CommentsService;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class CommentsRoute extends BaseRouteBuilder {
    @Autowired
    private CommentsService commentsService;

    @Override
    public void configure() throws Exception {
        super.configure();

        rest("/comments")
                .post()
                .type(CreateComment.class)
                .to("direct:saveComment")

                .get("/file/{fileId}")
                .param().name("page").type(RestParamType.query).defaultValue("0").endParam()
                .param().name("size").type(RestParamType.query).defaultValue("10").endParam()
                .to("direct:getCommentsByFileId")

                .get("/workflows/{workflowId}")
                .param().name("page").type(RestParamType.query).defaultValue("0").endParam()
                .param().name("size").type(RestParamType.query).defaultValue("10").endParam()
                .to("direct:getCommentsByWorkflowId");

        from("direct:getCommentsByFileId")
                .routeId("getCommentsByFileId")
                .to("direct:validateFile")
                .process(this::getCommentsByFileId);

        from("direct:getCommentsByWorkflowId")
                .routeId("getCommentsByWorkflowId")
                .process(this::getCommentsByWorkflowId);

        from("direct:saveComment")
                .routeId("saveComment")
                .process(this::saveComment);
    }

    private void saveComment(Exchange exchange) {
        CreateComment createComment = exchange.getIn().getBody(CreateComment.class);
        createComment.validate();

        UserDTO user = exchange.getProperty("user", UserDTO.class);

        Comments comment = commentsService.saveComment(createComment, user.getUser_id());

        exchange.getIn().setBody(comment);
    }
    private void getCommentsByFileId(Exchange exchange) {
        // Extract fileId, page, and size from request
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        int page = exchange.getIn().getHeader("page", 0, Integer.class); // Default to page 0
        int size = exchange.getIn().getHeader("size", 10, Integer.class); // Default size is 10

        // Call the service to get paginated comments
        Page<Comments> commentsPage = commentsService.getCommentsByFileId(fileId, page, size);

        // Set the paginated result as the response body
        exchange.getIn().setBody(commentsPage);
    }
    private void getCommentsByWorkflowId(Exchange exchange) {
        // Extract fileId, page, and size from request
        UUID workflowId = exchange.getIn().getHeader("workflowId", UUID.class);
        int page = exchange.getIn().getHeader("page", 0, Integer.class); // Default to page 0
        int size = exchange.getIn().getHeader("size", 10, Integer.class); // Default size is 10

        // Call the service to get paginated comments
        Page<Comments> commentsPage = commentsService.getCommentsByWorkflowId(workflowId, page, size);

        // Set the paginated result as the response body
        exchange.getIn().setBody(commentsPage);
    }
}
