package com.digitalchain.comments_service.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "comments")
public class Comments {
    @Id
    private UUID commentId;

    private UUID fileId;
    private UUID workflowId;

    private String userId;
    private String comment;
    private Date createdAt;

    private List<String> taggedUserIds;
}
