package com.digitalchain.activity_logging.routes.files;

import com.digitalchain.activity_logging.config.BaseRouteBuilder;
import com.digitalchain.activity_logging.dto.files.FileReportCriteria;
import com.digitalchain.activity_logging.enumerations.Services;
import com.digitalchain.activity_logging.model.FileActivityLog;
import com.digitalchain.activity_logging.model.LoginActivityLog;
import com.digitalchain.activity_logging.model.Reports;
import com.digitalchain.activity_logging.service.CsvExportService;
import com.digitalchain.activity_logging.service.FileActivityService;
import com.digitalchain.activity_logging.service.ReportService;
import com.digitalchain.common.dto.UserDTO;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

import static org.apache.camel.model.rest.RestParamType.path;
import static org.apache.camel.model.rest.RestParamType.query;

@Component
public class FileActivityLogRoute extends BaseRouteBuilder {

    @Autowired
    private FileActivityService fileActivityService;

    @Autowired
    private ReportService reportService;

    @Autowired
    private CsvExportService csvExportService;

    @Override
    public void configure() throws Exception {
        super.configure();

        // Define REST endpoints for file activity logging
        rest("/reports/files").description("File activity logging and report management APIs")

                .get().description("Get paginated list of file activity reports")
                .param().name("page").type(query).description("Page number for pagination").dataType("int").required(false).endParam()
                .param().name("size").type(query).description("Number of records per page").dataType("int").required(false).endParam()
                .responseMessage().code(200).message("List of reports").responseModel(Page.class).endResponseMessage()
                .responseMessage().code(400).message("Bad Request").endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:getReportsForFileActivity")

                .get("/{reportId}/export").description("Export file activity logs to CSV")
                .param().name("reportId").type(path).description("UUID of the report to export").dataType("uuid").endParam()
                .produces("text/csv")
                .responseMessage().code(200).message("CSV file with exported logs").endResponseMessage()
                .responseMessage().code(404).message("Report not found").endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:exportFileLogsToCsv")

                .get("/{reportId}").description("Get paginated file activity logs by report ID")
                .param().name("reportId").type(path).description("UUID of the report").dataType("uuid").endParam()
                .param().name("page").type(query).description("Page number for pagination").dataType("int").defaultValue("0").required(false).endParam()
                .param().name("size").type(query).description("Number of records per page").dataType("int").defaultValue("10").required(false).endParam()
                .param().name("sortField").type(query).description("Field to sort logs").dataType("string").defaultValue("action_time").required(false).endParam()
                .param().name("sortDirection").type(query).description("Sort direction (ASC/DESC)").dataType("string").defaultValue("DESC").required(false).endParam()
                .responseMessage().code(200).message("List of paginated logs").responseModel(Page.class).endResponseMessage()
                .responseMessage().code(404).message("Report not found").endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:getFileLogsForReport")

                .get("/activity/{userId}").description("Get latest file activity logs")
                .param().name("userId").type(path).description("ID of the user").dataType("string").endParam()
                .param().name("page").type(query).description("Page number for pagination").dataType("int").defaultValue("0").required(false).endParam()
                .param().name("size").type(query).description("Number of records per page").dataType("int").defaultValue("10").required(false).endParam()
                .param().name("sortField").type(query).description("Field to sort logs").dataType("string").defaultValue("action_time").required(false).endParam()
                .param().name("sortDirection").type(query).description("Sort direction (ASC/DESC)").dataType("string").defaultValue("DESC").required(false).endParam()
                .responseMessage().code(200).message("List of latest files activity logs").responseModel(List.class).endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:getLatestFileLogs")

                .post().description("Generate a new file activity report")
                .type(FileReportCriteria.class)
                .responseMessage().code(201).message("Report created").responseModel(Reports.class).endResponseMessage()
                .responseMessage().code(400).message("Invalid input data").endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:generateFileActivityReport")

                .delete("/{reportId}").description("Delete a file activity report by report ID")
                .param().name("reportId").type(path).description("UUID of the report to delete").dataType("uuid").endParam()
                .responseMessage().code(200).message("Report deleted successfully").endResponseMessage()
                .responseMessage().code(404).message("Report not found").endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:deleteFileReport");

        // Route for generating the file activity report
        from("direct:generateFileActivityReport")
                .routeId("generateFileActivityReport")
                .process(this::generateReport);

        // Route for getting paginated reports
        from("direct:getReportsForFileActivity")
                .routeId("getReportsForFileActivity")
                .process(this::getReports);

        // Route for getting paginated logs
        from("direct:getFileLogsForReport")
                .routeId("getFileLogsForReport")
                .process(this::getPaginatedLogs);

        // Route for exporting logs to CSV
        from("direct:exportFileLogsToCsv")
                .routeId("exportFileLogsToCsv")
                .process(this::exportLogsToCsv)
                .setHeader(Exchange.CONTENT_TYPE, constant("text/csv"))
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        // Route for deleting a file report
        from("direct:deleteFileReport")
                .routeId("deleteFileReport")
                .process(this::deleteFileReport);

        from("direct:getLatestFileLogs")
                .routeId("getLatestFileLogs")
                .process(this::getActivityForUser);
    }

    // Method to generate the file activity report based on criteria
    private void generateReport(Exchange exchange) {
        FileReportCriteria criteria = exchange.getIn().getBody(FileReportCriteria.class);

        UserDTO user = exchange.getProperty("user", UserDTO.class);

        Reports report = fileActivityService.generateReport(criteria, user.getUser_id());

        exchange.getIn().setBody(report);
    }

    // Method to get paginated reports for file activity
    private void getReports(Exchange exchange){
        int size = exchange.getIn().getHeader("size", 10, Integer.class);
        int page = exchange.getIn().getHeader("page", 0, Integer.class);

        Pageable pageable = PageRequest.of(page, size);

        Page<Reports> reports = reportService.getReportsByReportFor(Services.DOCUMENT_MANAGEMENT, pageable);

        exchange.getIn().setBody(reports);
    }

    private void getActivityForUser(Exchange exchange){
        int size = exchange.getIn().getHeader("size", 10, Integer.class);
        int page = exchange.getIn().getHeader("page", 0, Integer.class);
        String sortField = exchange.getIn().getHeader("sortField", "action_time", String.class);
        String sortDirection = exchange.getIn().getHeader("sortDirection", "DESC", String.class);

        String userId = exchange.getIn().getHeader("userId",  String.class);

        Sort sort = Sort.by(Sort.Direction.fromString(sortDirection), sortField);

        Pageable pageable = PageRequest.of(page, size, sort);

        Page<FileActivityLog> fileActivityLogs = fileActivityService.getLatestLogsForUser(pageable, userId);

        exchange.getIn().setBody(fileActivityLogs);
    }


    // Method to get paginated logs for a report
    private void getPaginatedLogs(Exchange exchange) throws Exception {
        UUID reportId = exchange.getIn().getHeader("reportId", UUID.class);

        // Get paging and sorting parameters from headers
        int page = exchange.getIn().getHeader("page", 0, Integer.class);
        int size = exchange.getIn().getHeader("size", 10, Integer.class);
        String sortField = exchange.getIn().getHeader("sortField", "action_time", String.class);
        String sortDirection = exchange.getIn().getHeader("sortDirection", "DESC", String.class);

        // Fetch paginated logs
        Page<FileActivityLog> logs = fileActivityService.getPaginatedLogs(reportId, page, size, sortField, sortDirection);

        exchange.getIn().setBody(logs);
    }

    // Method to export file activity logs to CSV
    private void exportLogsToCsv(Exchange exchange) throws Exception {
        UUID reportId = exchange.getIn().getHeader("reportId", UUID.class);

        List<FileActivityLog> logs = fileActivityService.getLogsForExport(reportId); // Fetch file activity logs

        // Generate CSV data dynamically using CsvExportService
        String csvData = csvExportService.exportToCsv(logs);

        // Set the CSV data as the response body
        exchange.getIn().setBody(csvData);

        String fileName = "file-report-" + reportId.toString() + ".csv";

        exchange.getIn().setHeader("Content-Disposition", "attachment; filename=" + fileName);
    }

    // Method to delete a file report
    private void deleteFileReport(Exchange exchange) {
        UUID reportId = exchange.getIn().getHeader("reportId", UUID.class);

        reportService.deleteReport(reportId, Services.DOCUMENT_MANAGEMENT);

        exchange.getIn().setBody("Report deleted successfully.");
    }
}
