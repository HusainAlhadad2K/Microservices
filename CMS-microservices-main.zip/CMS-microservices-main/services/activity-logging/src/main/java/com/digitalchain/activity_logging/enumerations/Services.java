package com.digitalchain.activity_logging.enumerations;

public enum Services {
    WORKFLOW,
    DOCUMENT_MANAGEMENT,
    LOGIN,
    PERMISSIONS
}
