package com.digitalchain.activity_logging.model;

import com.digitalchain.common.dto.AccessMethod;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.UUID;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "link_activity_logs")
public class LinkActivityLog {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;  // Unique identifier for the log entry
    @Column(name = "link_id", nullable = false)
    private UUID linkId;  // ID of the link
    @Column(name = "target_id", nullable = false)
    private UUID target_id;  // ID of the shared content
    @Column(name = "target_type", nullable = false)
    private String target_type;  // type of the shared content
    @Column(name = "target_name", nullable = false)
    private String target_name;
    @Column(name = "user_id")
    private String userId;        // ID of the user who performed the action if available
    @Column(name = "user_name")
    private String userName;  // Name of the user (optional, if available)
    @Column(name = "access_method", nullable = false)
    @Enumerated(EnumType.STRING)
    private AccessMethod accessMethod = AccessMethod.WEB;  // Method of access (e.g., System, Web UI)
    @Column(name = "device")
    private String device;        // Device used to perform the action (e.g., "Web UI")
    @Column(name = "ip_address")
    private String ipAddress;  // IP address from where the action was performed
    @Column(name ="city")
    private String city;
    @Column(name ="country")
    private String country;
    @Column(name = "action_time", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date actionTime;  // Timestamp of the action

}
