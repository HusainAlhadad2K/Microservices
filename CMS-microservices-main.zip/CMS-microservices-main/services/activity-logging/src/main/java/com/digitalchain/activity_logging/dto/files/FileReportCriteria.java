package com.digitalchain.activity_logging.dto.files;

import com.digitalchain.common.dto.files.FileLogAction;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.Date;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileReportCriteria {
    @NotNull
    private String reportName;
    private Date startDate;
    private Date endDate = new Date();
    private List<String> userId = Collections.emptyList();
    private FileLogAction action;
    private String filePath;
    private List<String> folderPath = Collections.emptyList();
}
