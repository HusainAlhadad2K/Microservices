package com.digitalchain.activity_logging.model;


import com.digitalchain.common.dto.AccessMethod;
import com.digitalchain.common.dto.login.LoginLogAction;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.UUID;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@Table(name = "login_activity_logs")
public class LoginActivityLog {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;  // Unique identifier for the log entry

    @Enumerated(EnumType.STRING)
    @Column(name = "action", nullable = false)
    private LoginLogAction action;

    @Column(name = "user_id", nullable = false)
    private String userId;  // ID of the user who performed the action

    @Column(name = "user_name")
    private String userName;  // Name of the user (optional)

    @Column(name = "access_method", nullable = false)
    @Enumerated(EnumType.STRING)
    private AccessMethod accessMethod = AccessMethod.WEB;  // Method of access (e.g., System, Web UI)

    @Column(name = "ip_address")
    private String ipAddress;  // IP address from where the action was performed

    @Column(name = "logout_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date logoutAt;  // Timestamp of the action

    @Column(name = "action_time", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date actionTime;  // Timestamp of the action

    @Column(name = "action_info", columnDefinition = "TEXT")
    private String actionInfo;  // Additional info about the action (e.g., success/failure messages)
}
