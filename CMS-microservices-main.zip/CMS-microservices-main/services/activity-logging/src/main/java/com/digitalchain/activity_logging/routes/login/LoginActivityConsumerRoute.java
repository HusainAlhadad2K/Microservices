package com.digitalchain.activity_logging.routes.login;

import com.digitalchain.activity_logging.service.LoginActivityLogService;
import com.digitalchain.common.dto.files.FileLogDTO;
import com.digitalchain.common.dto.login.LoginLogDTO;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class LoginActivityConsumerRoute extends RouteBuilder {

    @Autowired
    private LoginActivityLogService loginActivityLogService;

    @Override
    public void configure() throws Exception {
        from("kafka:{{login.activity.logging.topic}}?brokers={{camel.component.kafka.brokers}}")
                .routeId("kafkaLoginActivityLoggingRoute")
                .log("Received login log from Kafka: ${body}")
                .unmarshal().json(LoginLogDTO.class)  // Deserialize JSON to FileLogDTO
                .process(exchange -> {
                    // Extract the FileLogDTO object from the Kafka message
                    LoginLogDTO fileLogDTO = exchange.getIn().getBody(LoginLogDTO.class);
                    loginActivityLogService.logLoginActivity(fileLogDTO);  // Call your service to process the log
                });
    }
}
