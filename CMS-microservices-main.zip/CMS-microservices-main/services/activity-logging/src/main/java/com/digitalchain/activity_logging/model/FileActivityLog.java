package com.digitalchain.activity_logging.model;

import com.digitalchain.common.dto.files.FileLogAction;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.UUID;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "file_activity_logs")
public class FileActivityLog {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;  // Unique identifier for the log entry

    @Column(name = "file_id", nullable = false)
    private UUID fileId;  // ID of the file

    @Column(name = "file_path", nullable = false)
    private String filePath;  // Path where the file is stored

    @Enumerated(EnumType.STRING)
    @Column(name = "action", nullable = false)
    private FileLogAction action;  // Action performed on the file (e.g., Upload, Delete, Preview, Download)

    @Column(name = "user_id", nullable = false)
    private String userId;  // ID of the user who performed the action

    @Column(name = "user_name")
    private String userName;  // Name of the user (optional)

    @Column(name = "device")
    private String device;  // Device used to perform the action (e.g., Web UI, Mobile App)

    @Column(name = "access_method", nullable = false)
    private String accessMethod = "Web";  // Method of access (e.g., System, Web UI)

    @Column(name = "ip_address")
    private String ipAddress;  // IP address from where the action was performed

    @Column(name = "action_time", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date actionTime;  // Timestamp of the action

    @Column(name = "action_info", columnDefinition = "TEXT")
    private String actionInfo;  // Additional info about the action (e.g., success/failure messages)

    @Column(name = "checksum")
    private String checksum;  // Optional: file checksum if needed for file validation

    @Column(name = "file_version")
    private UUID fileVersion;  // Version of the file if versioning is supported
}
