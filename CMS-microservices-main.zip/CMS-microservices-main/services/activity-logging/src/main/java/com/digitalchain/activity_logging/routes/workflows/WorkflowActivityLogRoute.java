package com.digitalchain.activity_logging.routes.workflows;

import com.digitalchain.activity_logging.config.BaseRouteBuilder;
import com.digitalchain.activity_logging.dto.workflow.WorkflowReportCriteria;
import com.digitalchain.activity_logging.enumerations.Services;
import com.digitalchain.activity_logging.model.WorkflowActivityLog;
import com.digitalchain.activity_logging.model.Reports;
import com.digitalchain.activity_logging.service.CsvExportService;
import com.digitalchain.activity_logging.service.ReportService;
import com.digitalchain.activity_logging.service.WorkflowActivityService;
import com.digitalchain.common.dto.UserDTO;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

import static org.apache.camel.model.rest.RestParamType.path;
import static org.apache.camel.model.rest.RestParamType.query;

@Component
public class WorkflowActivityLogRoute extends BaseRouteBuilder {
    @Autowired
    private WorkflowActivityService workflowActivityService;

    @Autowired
    private ReportService reportService;

    @Autowired
    private CsvExportService csvExportService;

    @Override
    public void configure() throws Exception {
        super.configure();

        // Define REST endpoints for workflow activity logging with detailed Swagger documentation
        rest("/reports/workflow").description("Workflow activity logging and report management APIs")

                // Get paginated reports
                .get().description("Get paginated list of workflow activity reports")
                .param().name("page").type(query).description("Page number for pagination").dataType("int").defaultValue("0").required(false).endParam()
                .param().name("size").type(query).description("Number of records per page").dataType("int").defaultValue("10").required(false).endParam()
                .responseMessage().code(200).message("Successful response").endResponseMessage()
                .responseMessage().code(500).message("Server error").endResponseMessage()
                .to("direct:getReportsForWorkflow")

                // Export workflow logs to CSV
                .get("/{reportId}/export").description("Export workflow activity logs to CSV")
                .param().name("reportId").type(path).description("UUID of the report to export").dataType("uuid").required(true).endParam()
                .produces("text/csv")
                .responseMessage().code(200).message("CSV export successful").endResponseMessage()
                .responseMessage().code(404).message("Report not found").endResponseMessage()
                .to("direct:exportWorkflowLogsToCsv")

                // Get paginated workflow logs by report ID
                .get("/{reportId}").description("Get paginated workflow activity logs by report ID")
                .param().name("reportId").type(path).description("UUID of the report").dataType("uuid").required(true).endParam()
                .param().name("page").type(query).description("Page number for pagination").dataType("int").defaultValue("0").required(false).endParam()
                .param().name("size").type(query).description("Number of records per page").dataType("int").defaultValue("10").required(false).endParam()
                .param().name("sortField").type(query).description("Field to sort logs").dataType("string").defaultValue("created_at").required(false).endParam()
                .param().name("sortDirection").type(query).description("Sort direction (ASC/DESC)").dataType("string").defaultValue("DESC").required(false).endParam()
                .responseMessage().code(200).message("Logs retrieved successfully").endResponseMessage()
                .responseMessage().code(404).message("Report not found").endResponseMessage()
                .to("direct:getLogsForReport")

                // Generate a new workflow report
                .post().description("Generate a new workflow activity report")
                .type(WorkflowReportCriteria.class)
                .responseMessage().code(201).message("Report generated successfully").endResponseMessage()
                .responseMessage().code(400).message("Invalid report criteria").endResponseMessage()
                .to("direct:generateWorkflowReport")

                // Delete a workflow report
                .delete("/{reportId}").description("Delete a workflow activity report by report ID")
                .param().name("reportId").type(path).description("UUID of the report to delete").dataType("uuid").required(true).endParam()
                .responseMessage().code(200).message("Report deleted successfully").endResponseMessage()
                .responseMessage().code(404).message("Report not found").endResponseMessage()
                .to("direct:deleteWorkflowReport");

        // Route for generating the workflow report
        from("direct:generateWorkflowReport")
                .routeId("generateWorkflowReport")
                .process(this::generateReport);

        // Route for getting paginated reports
        from("direct:getReportsForWorkflow")
                .routeId("getReportsForWorkflow")
                .process(this::getReports);

        // Route for getting paginated logs
        from("direct:getLogsForReport")
                .routeId("getLogsForReport")
                .process(this::getReportLogs);

        // Route for exporting logs to CSV
        from("direct:exportWorkflowLogsToCsv")
                .routeId("exportWorkflowLogsToCsv")
                .process(this::exportLogsToCsv)
                .setHeader(Exchange.CONTENT_TYPE, constant("text/csv"))
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        // Route for deleting a workflow report
        from("direct:deleteWorkflowReport")
                .routeId("deleteWorkflowReport")
                .process(this::deleteWorkflowReport);
    }

    // Method to generate the report based on criteria
    private void generateReport(Exchange exchange) {
        WorkflowReportCriteria criteria = exchange.getIn().getBody(WorkflowReportCriteria.class);

        UserDTO user = exchange.getProperty("user", UserDTO.class);

        Reports report = workflowActivityService.generateReport(criteria, user.getUser_id());

        exchange.getIn().setBody(report);
    }

    // Method to get paginated reports for workflow activity
    private void getReports(Exchange exchange) {
        int size = exchange.getIn().getHeader("size", 10, Integer.class);
        int page = exchange.getIn().getHeader("page", 0, Integer.class);

        Pageable pageable = PageRequest.of(page, size);

        Page<Reports> reports = reportService.getReportsByReportFor(Services.WORKFLOW, pageable);

        exchange.getIn().setBody(reports);
    }

    // Method to get paginated logs for a report
    private void getReportLogs(Exchange exchange) throws Exception {
        UUID reportId = exchange.getIn().getHeader("reportId", UUID.class);

        // Get paging and sorting parameters from headers
        int page = exchange.getIn().getHeader("page", 0, Integer.class);
        int size = exchange.getIn().getHeader("size", 10, Integer.class);
        String sortField = exchange.getIn().getHeader("sortField", "created_at", String.class);
        String sortDirection = exchange.getIn().getHeader("sortDirection", "DESC", String.class);

        // Fetch paginated logs
        Page<WorkflowActivityLog> logs = workflowActivityService.getPaginatedLogs(reportId, page, size, sortField, sortDirection);

        exchange.getIn().setBody(logs);
    }

    // Method to export workflow activity logs to CSV
    private void exportLogsToCsv(Exchange exchange) throws Exception {
        UUID reportId = exchange.getIn().getHeader("reportId", UUID.class);

        List<WorkflowActivityLog> logs = workflowActivityService.getLogsByReportId(reportId);

        // Generate CSV data dynamically using CsvExportService
        String csvData = csvExportService.exportToCsv(logs);

        // Set the CSV data as the response body
        exchange.getIn().setBody(csvData);

        String fileName = "workflow-report-" + reportId.toString() + ".csv";
        exchange.getIn().setHeader("Content-Disposition", "attachment; filename=" + fileName);
    }

    // Method to delete a workflow report
    private void deleteWorkflowReport(Exchange exchange) {
        UUID reportId = exchange.getIn().getHeader("reportId", UUID.class);

        reportService.deleteReport(reportId, Services.WORKFLOW);

        exchange.getIn().setBody("Report deleted successfully.");
    }
}
