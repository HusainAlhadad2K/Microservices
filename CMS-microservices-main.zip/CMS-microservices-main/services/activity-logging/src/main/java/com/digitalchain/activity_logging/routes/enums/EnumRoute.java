package com.digitalchain.activity_logging.routes.enums;

import com.digitalchain.activity_logging.config.BaseRouteBuilder;
import com.digitalchain.activity_logging.utils.EnumFormatter;
import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.common.dto.workflow.WorkflowAction;
import com.digitalchain.common.dto.login.LoginLogAction;  // Import the LoginLogAction enum
import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.apache.camel.model.rest.RestParamType.query;

@Component
public class EnumRoute extends BaseRouteBuilder {

    @Override
    public void configure() throws Exception {
        super.configure();

        // Define REST endpoint for enums with detailed Swagger documentation
        rest("/reports/enums").description("Enumeration APIs for actions")
                .get("/workflow-actions").description("Get all available Workflow Actions with descriptions")
                .responseMessage().code(200).message("Successful operation")
                .responseModel(List.class).example("application/json", "[{\"name\": \"WORKFLOW_CREATED\", \"description\": \"Workflow created\"}]").endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:getWorkflowActions")

                .get("/file-actions").description("Get all available File Log Actions with descriptions")
                .responseMessage().code(200).message("Successful operation")
                .responseModel(List.class).example("application/json", "[{\"name\": \"CREATE_FOLDER\", \"description\": \"Create a new folder\"}]").endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:getFileLogActions")

                .get("/login-actions").description("Get all available Login Log Actions with descriptions")  // New endpoint for Login Log Actions
                .responseMessage().code(200).message("Successful operation")
                .responseModel(List.class).example("application/json", "[{\"name\": \"LOGIN_SUCCESS\", \"description\": \"Successful login\"}]").endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:getLoginLogActions");

        // Route to fetch workflow actions
        from("direct:getWorkflowActions")
                .routeId("getWorkflowActions")
                .process(this::getWorkflowActions)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        // Route to fetch file log actions
        from("direct:getFileLogActions")
                .routeId("getFileLogActions")
                .process(this::getFileLogActions)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        // Route to fetch login log actions
        from("direct:getLoginLogActions")  // New route for Login Log Actions
                .routeId("getLoginLogActions")
                .process(this::getLoginLogActions)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));
    }

    // Method to return WorkflowAction enum values with descriptions
    private void getWorkflowActions(Exchange exchange) {
        exchange.getIn().setBody(EnumFormatter.formatEnumWithDescriptions(WorkflowAction.class));
    }

    // Method to return FileLogAction enum values with descriptions
    private void getFileLogActions(Exchange exchange) {
        exchange.getIn().setBody(EnumFormatter.formatEnumWithDescriptions(FileLogAction.class));
    }

    // Method to return LoginLogAction enum values with descriptions
    private void getLoginLogActions(Exchange exchange) {
        exchange.getIn().setBody(EnumFormatter.formatEnumWithDescriptions(LoginLogAction.class));
    }
}