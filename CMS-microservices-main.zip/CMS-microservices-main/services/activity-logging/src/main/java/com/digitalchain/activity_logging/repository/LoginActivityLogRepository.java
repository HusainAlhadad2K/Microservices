package com.digitalchain.activity_logging.repository;

import com.digitalchain.activity_logging.model.LoginActivityLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public interface LoginActivityLogRepository extends JpaRepository<LoginActivityLog, UUID> {
    @Query(value = "SELECT * FROM login_activity_logs log " +
            "WHERE log.action_time >= COALESCE(:startDate, CAST('1970-01-01 00:00:00' AS timestamp)) " +
            "AND log.action_time <= COALESCE(:endDate, CAST('9999-12-31 23:59:59' AS timestamp)) " +
            "AND (:userId IS NULL OR log.user_id IN (:userId)) " +
            "AND (:action IS NULL OR log.action = :action) " +
            "AND (:accessMethod IS NULL OR log.access_method = :accessMethod)",
            nativeQuery = true)
    List<LoginActivityLog> findLogsForReport(@Param("startDate") Date startDate,
                                             @Param("endDate") Date endDate,
                                             @Param("userId") List<String> userId,
                                             @Param("action") String action,
                                             @Param("accessMethod") String accessMethod);

    @Query(value = "SELECT * FROM login_activity_logs log " +
            "WHERE log.action_time >= COALESCE(:startDate, CAST('1970-01-01 00:00:00' AS timestamp)) " +
            "AND log.action_time <= COALESCE(:endDate, CAST('9999-12-31 23:59:59' AS timestamp)) " +
            "AND (:userId IS NULL OR log.user_id IN (:userId)) " +
            "AND (:action IS NULL OR log.action = :action) " +
            "AND (:accessMethod IS NULL OR log.access_method = :accessMethod)",
            nativeQuery = true)
    Page<LoginActivityLog> findLogsForReportWithPaging(@Param("startDate") Date startDate,
                                                       @Param("endDate") Date endDate,
                                                       @Param("userId") List<String> userId,
                                                       @Param("action") String action,
                                                       @Param("accessMethod") String accessMethod,
                                                       Pageable pageable);
}
