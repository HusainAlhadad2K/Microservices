package com.digitalchain.activity_logging.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CriteriaParser {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    // Generic method to parse criteria string into any type of criteria object
    public static <T> T parse(String criteriaString, Class<T> criteriaClass) {
        try {
            return objectMapper.readValue(criteriaString, criteriaClass);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse report criteria", e);
        }
    }
    public static <T> String stringify(T criteriaObject) {
        try {
            return objectMapper.writeValueAsString(criteriaObject);
        } catch (Exception e) {
            throw new RuntimeException("Failed to stringify criteria object", e);
        }
    }
}
