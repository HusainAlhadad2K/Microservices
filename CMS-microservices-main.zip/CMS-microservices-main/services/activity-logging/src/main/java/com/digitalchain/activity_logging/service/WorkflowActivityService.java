package com.digitalchain.activity_logging.service;

import com.digitalchain.activity_logging.dto.workflow.WorkflowReportCriteria;
import com.digitalchain.activity_logging.enumerations.ReportStatus;
import com.digitalchain.activity_logging.enumerations.Services;
import com.digitalchain.activity_logging.model.Reports;
import com.digitalchain.activity_logging.model.WorkflowActivityLog;
import com.digitalchain.activity_logging.repository.ReportsRepository;
import com.digitalchain.activity_logging.repository.WorkflowActivityLogRepository;
import com.digitalchain.activity_logging.utils.CriteriaParser;
import com.digitalchain.common.dto.workflow.WorkflowLogDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class WorkflowActivityService {

    @Autowired
    private WorkflowActivityLogRepository workflowActivityLogRepository;

    @Autowired
    private ReportsRepository reportsRepository;

    // Method to add a workflow activity log to the database
    public void logActivity(WorkflowLogDTO logDTO) {
        // Convert WorkflowLogDTO to WorkflowActivityLog entity
        WorkflowActivityLog activityLog = new WorkflowActivityLog();
        activityLog.setWorkflowId(logDTO.getWorkflowId());
        activityLog.setUserId(logDTO.getUserId());
        activityLog.setStepType(logDTO.getStepType());
        activityLog.setAction(logDTO.getAction());
        activityLog.setWorkflowType(logDTO.getWorkflowType());
        activityLog.setMessage(logDTO.getMessage());
        activityLog.setWorkflowDate(new Date(logDTO.getCreatedAt().getTime()));  // Use timestamp from DTO
        activityLog.setCreatedAt(logDTO.getCreatedAt() != null ? logDTO.getCreatedAt() : new Date()); // Set createdAt if provided, otherwise use current date

        // Save the entity to the database
        workflowActivityLogRepository.save(activityLog);
    }

    public Reports generateReport(WorkflowReportCriteria criteria, String generatedBy) {
        // Create a new report entity
        Reports report = new Reports();
        report.setReportName(criteria.getReportName());
        report.setGeneratedBy(generatedBy);
        report.setCriteria(CriteriaParser.stringify(criteria));
        report.setReportStatus(ReportStatus.PENDING);
        report.setReportFor(Services.WORKFLOW);
        reportsRepository.save(report);

        try {
            // Fetch logs based on the criteria from the DTO
            workflowActivityLogRepository.findWorkflowsWithPaging(
                    criteria.getStartDate(),
                    criteria.getEndDate(),
                    criteria.getUserId(),
                    criteria.getAction() != null ? criteria.getAction().name() : null,
                    criteria.getWorkflowType(),
                    criteria.getFolderPath(),
                    PageRequest.of(0, 1)
            );

            report.setReportStatus(ReportStatus.COMPLETED);

            return reportsRepository.save(report);  // Update the report status in the database
        } catch (Exception e) {
            report.setReportStatus(ReportStatus.FAILED);
            reportsRepository.save(report);

            throw new RuntimeException("Error generating report", e);
        }
    }

    public List<WorkflowActivityLog> getLogsByReportId(UUID reportId) throws Exception {
        Reports report = reportsRepository.findById(reportId)
                .orElseThrow(() -> new RuntimeException("Report not found"));

        if (!report.getReportFor().equals(Services.WORKFLOW)){
            throw new IllegalAccessException("Invalid report");
        }
        // Use the generic parseCriteria method
        WorkflowReportCriteria criteria = CriteriaParser.parse(report.getCriteria(), WorkflowReportCriteria.class);

        return workflowActivityLogRepository.findLogsForReport(
                criteria.getStartDate(),
                criteria.getEndDate(),
                criteria.getUserId(),
                criteria.getAction() != null ? criteria.getAction().name() : null,
                criteria.getWorkflowType(),
                criteria.getFolderPath()
        );
    }
    public Page<WorkflowActivityLog> getPaginatedLogs(UUID reportId, int page, int size, String sortField, String sortDirection) throws Exception {
        Reports report = reportsRepository.findById(reportId)
                .orElseThrow(() -> new RuntimeException("Report not found"));

        if (!report.getReportFor().equals(Services.WORKFLOW)){
            throw new IllegalAccessException("Invalid report");
        }

        // Parse the stored criteria
        WorkflowReportCriteria criteria = CriteriaParser.parse(report.getCriteria(), WorkflowReportCriteria.class);

        // Determine sort order
        Sort sort = Sort.by(Sort.Direction.fromString(sortDirection), sortField);

        // Apply paging logic with sorting
        Pageable pageable = PageRequest.of(page, size, sort);

        return workflowActivityLogRepository.findWorkflowsWithPaging(
                criteria.getStartDate(),
                criteria.getEndDate(),
                criteria.getUserId(),
                criteria.getAction() != null ? criteria.getAction().name() : null,
                criteria.getWorkflowType(),
                criteria.getFolderPath(),
                pageable
        );
    }
}
