package com.digitalchain.activity_logging.utils;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EnumFormatter {

    // Generic utility to format enums with description
    public static <E extends Enum<E>> List<Map<String, String>> formatEnumWithDescriptions(Class<E> enumType) {
        return Arrays.stream(enumType.getEnumConstants())
                .map(enumConstant -> {
                    // Check if the enum has a 'getDescription' method
                    try {
                        String description = (String) enumType.getMethod("getDescription").invoke(enumConstant);
                        return Map.of(
                                "name", enumConstant.name(),
                                "description", description
                        );
                    } catch (Exception e) {
                        // If the enum doesn't have a 'getDescription' method, return only the name
                        return Map.of(
                                "name", enumConstant.name(),
                                "description", "No description available"
                        );
                    }
                })
                .collect(Collectors.toList());
    }
}
