package com.digitalchain.activity_logging.model;

import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.common.enums.permissions.ChangeType;
import com.digitalchain.common.enums.permissions.Role;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.UUID;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "permissions_activity_logs")
public class PermissionsActivityLog {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;  // Unique identifier for the log entry

    @Column(name = "folder_id", nullable = false)
    private UUID folderId;  // ID of the file

    @Column(name = "folder_path", nullable = false)
    private String folderPath;  // Path where the file is stored

    @Column(name = "change_type", nullable = false)
    @Enumerated(EnumType.STRING)
    private ChangeType changeType;

    @Column(name = "changed_for", nullable = false)
    private String changedFor;

    @Enumerated(EnumType.STRING)
    @Column(name = "previous_role", nullable = false)
    private Role previousRole;

    @Enumerated(EnumType.STRING)
    @Column(name = "new_role", nullable = false)
    private Role newRole;

    @Column(name = "user_id", nullable = false)
    private String userId;  // ID of the user who performed the action

    @Column(name = "user_name")
    private String userName;  // Name of the user (optional)

    @Column(name = "ip_address")
    private String ipAddress;  // IP address from where the action was performed

    @Column(name = "action_time", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date actionTime;  // Timestamp of the action

    @Column(name = "action_info", columnDefinition = "TEXT")
    private String actionInfo;  // Additional info about the action (e.g., success/failure messages)

}
