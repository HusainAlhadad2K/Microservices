package com.digitalchain.activity_logging.service;


import com.digitalchain.activity_logging.dto.login.LoginReportCriteria;
import com.digitalchain.activity_logging.enumerations.ReportStatus;
import com.digitalchain.activity_logging.enumerations.Services;
import com.digitalchain.activity_logging.model.FileActivityLog;
import com.digitalchain.activity_logging.model.LoginActivityLog;
import com.digitalchain.activity_logging.model.Reports;
import com.digitalchain.activity_logging.repository.LoginActivityLogRepository;
import com.digitalchain.activity_logging.repository.ReportsRepository;
import com.digitalchain.activity_logging.utils.CriteriaParser;
import com.digitalchain.common.dto.login.LoginLogDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class LoginActivityLogService {
    @Autowired
    private LoginActivityLogRepository loginActivityLogRepository;

    @Autowired
    private ReportsRepository reportsRepository;

    public void logLoginActivity(LoginLogDTO log){
        LoginActivityLog loginLog = LoginActivityLog.builder()
                .accessMethod(log.getAccessMethod())
                .action(log.getAction())
                .actionInfo(log.getActionInfo())
                .actionTime(log.getActionTime())
                .userId(log.getUserId())
                .userName(log.getUserName())
                .ipAddress(log.getIpAddress())
                .build();

        loginActivityLogRepository.save(loginLog);
    }

    public Reports generateReport(LoginReportCriteria criteria, String generatedBy){
        Reports report = Reports.builder()
                .reportName(criteria.getReportName())
                .generatedBy(generatedBy)
                .criteria(CriteriaParser.stringify(criteria))
                .reportStatus(ReportStatus.PENDING)
                .createdAt(new Date())
                .reportFor(Services.LOGIN)
                .build();

        reportsRepository.save(report);

        try {
            // Fetch logs based on the criteria
            Page<LoginActivityLog> log = loginActivityLogRepository.findLogsForReportWithPaging(
                    criteria.getStartDate(),
                    criteria.getEndDate(),
                    criteria.getUserId(),
                    criteria.getAction() != null ? criteria.getAction().name() : null,
                    criteria.getAccessMethod() != null ? criteria.getAccessMethod().name() : null,
                    PageRequest.of(0, 1)
            );

            report.setReportStatus(ReportStatus.COMPLETED);
            reportsRepository.save(report);  // Update report status to completed

            return report;
        } catch (Exception e) {
            report.setReportStatus(ReportStatus.FAILED);
            reportsRepository.save(report);

            throw new RuntimeException("Error generating file activity report", e);
        }
    }
    public List<LoginActivityLog> getLogsForExport(UUID reportId) throws Exception {
        Reports report = reportsRepository.findById(reportId)
                .orElseThrow(() -> new RuntimeException("Report not found"));

        if (!report.getReportFor().equals(Services.LOGIN)) {
            throw new IllegalAccessException("Invalid report");
        }

        // Parse the stored criteria
        LoginReportCriteria criteria = CriteriaParser.parse(report.getCriteria(), LoginReportCriteria.class);

        // Fetch all data without paging for export, with sorting applied
        return loginActivityLogRepository.findLogsForReport(
                criteria.getStartDate(),
                criteria.getEndDate(),
                criteria.getUserId(),
                criteria.getAction() != null ? criteria.getAction().name() : null,
                criteria.getAccessMethod() != null ? criteria.getAccessMethod().name() : null
        );
    }

    public Page<LoginActivityLog> getPaginatedLogs(UUID reportId, int page, int size, String sortField, String sortDirection) throws Exception {
        Reports report = reportsRepository.findById(reportId)
                .orElseThrow(() -> new RuntimeException("Report not found"));

        if (!report.getReportFor().equals(Services.LOGIN)) {
            throw new IllegalAccessException("Invalid report");
        }

        // Parse the stored criteria
        LoginReportCriteria criteria = CriteriaParser.parse(report.getCriteria(), LoginReportCriteria.class);

        System.out.println(sortField + "  " + sortDirection);

        // Determine sort order
        Sort sort = Sort.by(Sort.Direction.fromString(sortDirection), sortField);

        // Apply paging logic with sorting
        Pageable pageable = PageRequest.of(page, size, sort);

        // Fetch paginated data
        return loginActivityLogRepository.findLogsForReportWithPaging(
                criteria.getStartDate(),
                criteria.getEndDate(),
                criteria.getUserId(),
                criteria.getAction() != null ? criteria.getAction().name() : null,
                criteria.getAccessMethod() != null ? criteria.getAccessMethod().name() : null,
                pageable
        );
    }

    public Page<LoginActivityLog> getLatestLogsForUser(Pageable pageable, String userId){
        return loginActivityLogRepository.findLogsForReportWithPaging(null, null, List.of(userId), null, null, pageable);
    }

}
