package com.digitalchain.activity_logging.repository;

import com.digitalchain.activity_logging.model.LinkActivityLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface LinkActivityLogRepository extends JpaRepository<LinkActivityLog, UUID> {
    // Custom query method to find all logs for a specific link_id, with pagination
    Page<LinkActivityLog> findAllByLinkId(UUID link_id, Pageable pageable);
}

