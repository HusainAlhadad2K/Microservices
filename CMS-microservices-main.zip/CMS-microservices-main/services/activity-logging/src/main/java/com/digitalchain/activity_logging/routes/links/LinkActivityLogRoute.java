package com.digitalchain.activity_logging.routes.links;

import com.digitalchain.activity_logging.config.BaseRouteBuilder;
import com.digitalchain.activity_logging.model.LinkActivityLog;
import com.digitalchain.activity_logging.service.LinkActivityLogService;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static org.apache.camel.model.rest.RestParamType.path;
import static org.apache.camel.model.rest.RestParamType.query;

@Component
public class LinkActivityLogRoute extends BaseRouteBuilder {
    @Autowired
    private LinkActivityLogService linkActivityLogService;


    @Override
    public void configure() throws Exception {
        super.configure();
        // Define REST endpoints for link activity logging
        rest("/reports/links").description("link activity logging")
                .get("/access/{linkId}")
                .param().name("page").type(query).description("Page number for pagination").dataType("int").required(false).endParam()
                .param().name("size").type(query).description("Number of records per page").dataType("int").required(false).endParam()
                .param().name("sortBy").type(query).description("Field to sort by").dataType("string").required(false).endParam()  // Sort field
                .param().name("sortDirection").type(query).description("Sort direction: asc or desc").dataType("string").required(false).endParam()  // Sort direction
                .responseMessage().code(200).message("List of reports for a link").responseModel(Page.class).endResponseMessage()
                .responseMessage().code(400).message("Bad Request").endResponseMessage()
                .responseMessage().code(500).message("Internal Server Error").endResponseMessage()
                .to("direct:getLinkLog");

        from("direct:getLinkLog")
                .routeId("getLinkLogRoute")
                .process(this::getLinkLog);
    }
        private void getLinkLog(Exchange exchange){
            int size = exchange.getIn().getHeader("size", 10, Integer.class);
            int page = exchange.getIn().getHeader("page", 0, Integer.class);
            String sortBy = exchange.getIn().getHeader("sortBy", "actionTime", String.class);  // Default sorting by "actionTime"
            String sortDirection = exchange.getIn().getHeader("sortDirection", "desc", String.class);  // Default sorting direction "desc"
            UUID linkId = exchange.getIn().getHeader("linkId", UUID.class);
            // Call the service to fetch the logs with sorting
            Page<LinkActivityLog> logs = linkActivityLogService.getLinkLogs(linkId, page, size, sortBy, sortDirection);

            // Set the result in the body of the exchange
            exchange.getIn().setBody(logs);
        }

    }
