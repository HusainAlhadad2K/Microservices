package com.digitalchain.activity_logging.utils;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.StringWriter;
import java.lang.reflect.Field;
import java.util.List;

public class CsvUtil {

    // Generic method to convert any list of objects into a CSV string using commons-csv
    public static <T> String writeObjectsToCsv(List<T> data) {
        if (data == null || data.isEmpty()) {
            throw new IllegalArgumentException("Data list cannot be null or empty");
        }

        StringWriter writer = new StringWriter();

        try (CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT)) {
            // Get the class of the first object to retrieve fields (assuming all objects are of the same type)
            Class<?> clazz = data.get(0).getClass();

            // Write the header (field names)
            Field[] fields = clazz.getDeclaredFields();
            for (Field field : fields) {
                csvPrinter.print(field.getName());
            }
            csvPrinter.println();

            // Write data rows
            for (T obj : data) {
                for (Field field : fields) {
                    field.setAccessible(true); // Enable access to private fields
                    Object value = field.get(obj);
                    csvPrinter.print(value != null ? value.toString() : "");
                }
                csvPrinter.println();
            }

        } catch (Exception e) {
            throw new RuntimeException("Error generating CSV", e);
        }

        return writer.toString();
    }
}
