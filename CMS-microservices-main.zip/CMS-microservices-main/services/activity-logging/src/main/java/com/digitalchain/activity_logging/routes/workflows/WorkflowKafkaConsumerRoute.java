package com.digitalchain.activity_logging.routes.workflows;

import com.digitalchain.activity_logging.service.WorkflowActivityService;
import com.digitalchain.common.dto.workflow.WorkflowLogDTO;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class WorkflowKafkaConsumerRoute extends RouteBuilder {

    @Autowired
    WorkflowActivityService workflowActivityService;

    @Override
    public void configure() throws Exception {
        // Kafka Consumer route
        from("kafka:{{workflow.activity.logging.topic}}?brokers={{camel.component.kafka.brokers}}")
                .routeId("kafkaActivityLoggingRoute")
                .log("Received message from Kafka: ${body}")
                .unmarshal().json(WorkflowLogDTO.class)  // Deserialize JSON to WorkflowLogDTO
                .process(exchange -> {
                    // Extract the WorkflowLogDTO object from the Kafka message
                    WorkflowLogDTO logDTO = exchange.getIn().getBody(WorkflowLogDTO.class);
                    workflowActivityService.logActivity(logDTO);
                });
    }
}
