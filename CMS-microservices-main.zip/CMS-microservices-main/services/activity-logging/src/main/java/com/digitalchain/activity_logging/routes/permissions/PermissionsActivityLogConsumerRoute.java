package com.digitalchain.activity_logging.routes.permissions;

import com.digitalchain.activity_logging.config.BaseRouteBuilder;
import com.digitalchain.activity_logging.service.PermissionActivityLogService;
import com.digitalchain.common.dto.login.LoginLogDTO;
import com.digitalchain.common.dto.permissions.PermissionLogDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PermissionsActivityLogConsumerRoute extends BaseRouteBuilder {

    @Autowired
    private PermissionActivityLogService permissionActivityLogService;
    @Override
    public void configure() throws Exception {
        from("kafka:{{permissions.activity.logging.topic}}?brokers={{camel.component.kafka.brokers}}")
                .routeId("kafkaPermissionsActivityLoggingRoute")
                .log("Received permissions log from Kafka: ${body}")
                .unmarshal().json(PermissionLogDTO.class)  // Deserialize JSON to FileLogDTO
                .process(exchange -> {
                    // Extract the FileLogDTO object from the Kafka message
                    PermissionLogDTO permissionLogDTO = exchange.getIn().getBody(PermissionLogDTO.class);
                    permissionActivityLogService.logPermissionActivity(permissionLogDTO);
                });
    }
}
