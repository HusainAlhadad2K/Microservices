package com.digitalchain.activity_logging.enumerations;

public enum ReportStatus {
    PENDING,
    COMPLETED,
    FAILED
}