package com.digitalchain.activity_logging.repository;


import com.digitalchain.activity_logging.model.LoginActivityLog;
import com.digitalchain.activity_logging.model.PermissionsActivityLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Repository
public interface PermissionActivityLogRepository extends JpaRepository<PermissionsActivityLog, UUID> {
    @Query(value = "SELECT * FROM permissions_activity_logs log " +
            "WHERE log.action_time >= COALESCE(:startDate, CAST('1970-01-01 00:00:00' AS timestamp)) " +
            "AND log.action_time <= COALESCE(:endDate, CAST('9999-12-31 23:59:59' AS timestamp)) " +
            "AND (:userId IS NULL OR log.user_id IN (:userId)) " +
            "AND (:changedFor IS NULL OR log.changed_for IN (:changedFor)) " +
            "AND (:folderPath IS NULL OR log.file_path LIKE ANY (ARRAY(SELECT CONCAT(:folderPath, '%'))))",
            nativeQuery = true)
    List<PermissionsActivityLog> findLogsForReport(@Param("startDate") Date startDate,
                                                             @Param("endDate") Date endDate,
                                                             @Param("userId") List<String> userId,
                                                             @Param("changedFor") List<String> changedFor,
                                                             @Param("folderPath") List<String> folderPath);

    @Query(value = "SELECT * FROM permissions_activity_logs log " +
            "WHERE log.action_time >= COALESCE(:startDate, CAST('1970-01-01 00:00:00' AS timestamp)) " +
            "AND log.action_time <= COALESCE(:endDate, CAST('9999-12-31 23:59:59' AS timestamp)) " +
            "AND (:userId IS NULL OR log.user_id IN (:userId)) " +
            "AND (:changedFor IS NULL OR log.changed_for IN (:changedFor)) " +
            "AND (:folderPath IS NULL OR log.file_path LIKE ANY (ARRAY(SELECT CONCAT(:folderPath, '%'))))",
            nativeQuery = true)
    Page<PermissionsActivityLog> findLogsForReportWithPaging(@Param("startDate") Date startDate,
                                                       @Param("endDate") Date endDate,
                                                       @Param("userId") List<String> userId,
                                                       @Param("changedFor") List<String> changedFor,
                                                       @Param("folderPath") List<String> folderPath,
                                                       Pageable pageable);
}
