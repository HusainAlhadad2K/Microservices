package com.digitalchain.activity_logging.model;

import com.digitalchain.common.dto.workflow.StepType;
import com.digitalchain.common.dto.workflow.WorkflowAction;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "workflow_activity_logs")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class WorkflowActivityLog {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;  // Unique identifier for each log entry

    @Column(name = "workflow_id", nullable = false)
    private UUID workflowId;  // ID of the workflow being logged

    @Column(name = "user_id", nullable = false)
    private String userId;  // ID of the user who performed the action

    @Column(name = "file_name")
    private String fileName;  // Optional: ID of the file related to the workflow (if applicable)

    @Column(name = "file_path")
    private String filePath;

    @Column(name = "action", nullable = false)
    @Enumerated(EnumType.STRING)
    private WorkflowAction action;

    @Column(name = "step_type")
    @Enumerated(EnumType.STRING)
    private StepType stepType;

    @Column(name = "workflow_type")
    private String workflowType;  // Type of the workflow (if applicable)

    @Column(name = "message")
    private String message;  // Additional message or description

    @Column(name = "workflow_date", nullable = false)
    private Date workflowDate;  // Date when the workflow was processed

    @Column(name = "created_at", nullable = false)
    private Date createdAt;  // Timestamp of when the log was created
}
