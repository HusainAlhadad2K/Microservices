package com.digitalchain.activity_logging.service;

import com.digitalchain.activity_logging.utils.CsvUtil;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CsvExportService {

    // Generic method to generate CSV for any type of object list
    public <T> String exportToCsv(List<T> data) {
        return CsvUtil.writeObjectsToCsv(data);
    }
}
