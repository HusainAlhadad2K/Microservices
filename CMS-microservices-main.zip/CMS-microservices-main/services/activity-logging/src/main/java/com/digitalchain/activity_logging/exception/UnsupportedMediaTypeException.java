package com.digitalchain.activity_logging.exception;

public class UnsupportedMediaTypeException extends RuntimeException {
    public UnsupportedMediaTypeException(String message){super(message);}
}