package com.digitalchain.activity_logging.service;

import com.digitalchain.activity_logging.dto.files.FileReportCriteria;
import com.digitalchain.activity_logging.enumerations.ReportStatus;
import com.digitalchain.activity_logging.enumerations.Services;
import com.digitalchain.activity_logging.model.FileActivityLog;
import com.digitalchain.activity_logging.model.LoginActivityLog;
import com.digitalchain.activity_logging.model.Reports;
import com.digitalchain.activity_logging.repository.FileActivityLogRepository;
import com.digitalchain.activity_logging.repository.ReportsRepository;
import com.digitalchain.activity_logging.utils.CriteriaParser;
import com.digitalchain.common.dto.files.FileLogDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class FileActivityService {

    @Autowired
    private FileActivityLogRepository fileActivityLogRepository;

    @Autowired
    private ReportsRepository reportsRepository;

    // Method to log file activity into the database using builder pattern
    public void logFileActivity(FileLogDTO logDTO) {
        FileActivityLog activityLog = FileActivityLog.builder()
                .fileId(logDTO.getFileId())
                .filePath(logDTO.getFilePath())
                .action(logDTO.getAction())
                .userId(logDTO.getUserId())
                .userName(logDTO.getUserName())
                .accessMethod("Web")
                .device(logDTO.getDevice())
                .ipAddress(logDTO.getIpAddress())
                .actionTime(logDTO.getActionTime())
                .actionInfo(logDTO.getActionInfo())
                .checksum(logDTO.getChecksum())
                .fileVersion(logDTO.getFileVersion())
                .build();

        // Save to the database
        fileActivityLogRepository.save(activityLog);
    }

    public Reports generateReport(FileReportCriteria criteria, String generatedBy) {
        Reports report = Reports.builder()
                .reportName(criteria.getReportName())
                .generatedBy(generatedBy)
                .criteria(CriteriaParser.stringify(criteria))
                .reportStatus(ReportStatus.PENDING)
                .createdAt(new Date())
                .reportFor(Services.DOCUMENT_MANAGEMENT)
                .build();

        reportsRepository.save(report);

        try {
            // Fetch logs based on the criteria
            Page<FileActivityLog> log = fileActivityLogRepository.findLogsForReportWithPaging(
                    criteria.getStartDate(),
                    criteria.getEndDate(),
                    criteria.getUserId(),
                    criteria.getAction() != null ? criteria.getAction().name() : null,
                    criteria.getFilePath(),
                    criteria.getFolderPath(),
                    PageRequest.of(0, 1)
            );

            System.out.println(log.getContent());

            report.setReportStatus(ReportStatus.COMPLETED);
            reportsRepository.save(report);  // Update report status to completed

            return report;
        } catch (Exception e) {
            report.setReportStatus(ReportStatus.FAILED);
            reportsRepository.save(report);

            throw new RuntimeException("Error generating file activity report", e);
        }
    }

    public List<FileActivityLog> getLogsForExport(UUID reportId) throws Exception {
        Reports report = reportsRepository.findById(reportId)
                .orElseThrow(() -> new RuntimeException("Report not found"));

        if (!report.getReportFor().equals(Services.DOCUMENT_MANAGEMENT)){
            throw new IllegalAccessException("Invalid report");
        }

        // Parse the stored criteria
        FileReportCriteria criteria = CriteriaParser.parse(report.getCriteria(), FileReportCriteria.class);

        // Fetch all data without paging for export, with sorting applied
        return fileActivityLogRepository.findLogsForReport(
                criteria.getStartDate(),
                criteria.getEndDate(),
                criteria.getUserId(),
                criteria.getAction() != null ? criteria.getAction().name() : null,
                criteria.getFilePath(),
                criteria.getFolderPath()
        );
    }

    public Page<FileActivityLog> getPaginatedLogs(UUID reportId, int page, int size, String sortField, String sortDirection) throws Exception {
        Reports report = reportsRepository.findById(reportId)
                .orElseThrow(() -> new RuntimeException("Report not found"));

        if (!report.getReportFor().equals(Services.DOCUMENT_MANAGEMENT)){
            throw new IllegalAccessException("Invalid report");
        }

        // Parse the stored criteria
        FileReportCriteria criteria = CriteriaParser.parse(report.getCriteria(), FileReportCriteria.class);

        // Determine sort order
        Sort sort = Sort.by(Sort.Direction.fromString(sortDirection), sortField);

        // Apply paging logic with sorting
        Pageable pageable = PageRequest.of(page, size, sort);

        return fileActivityLogRepository.findLogsForReportWithPaging(
                criteria.getStartDate(),
                criteria.getEndDate(),
                criteria.getUserId(),
                criteria.getAction() != null ? criteria.getAction().name() : null,
                criteria.getFilePath(),
                criteria.getFolderPath(),
                pageable
        );
    }
    public Page<FileActivityLog> getLatestLogsForUser(Pageable pageable, String userId){
        return fileActivityLogRepository.findLogsForReportWithPaging(null, null, List.of(userId), null, null, List.of(), pageable);
    }

}
