package com.digitalchain.activity_logging.routes.links;

import com.digitalchain.activity_logging.config.BaseRouteBuilder;
import com.digitalchain.activity_logging.service.LinkActivityLogService;
import com.digitalchain.common.dto.links.LinkLogDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LinkKafkaConsumerRoute extends BaseRouteBuilder {
@Autowired
    private LinkActivityLogService linkActivityLogService;
    @Override
    public void configure() throws Exception {
        // Kafka Consumer route for link activity logs
        from("kafka:{{link.activity.logging.topic}}?brokers={{camel.component.kafka.brokers}}")
                .routeId("kafkaLinkActivityLoggingRoute")
                .log("Received link log from Kafka: ${body}")
                .unmarshal().json(LinkLogDTO.class)  // Deserialize JSON to LinkLogDTO
                .process(exchange -> {
                    // Extract the LinkLogDTO object from the Kafka message
                    LinkLogDTO linkLogDTO = exchange.getIn().getBody(LinkLogDTO.class);
                    linkActivityLogService.logLinkActivity(linkLogDTO);  // Call your service to process the log
                });
    }
}
