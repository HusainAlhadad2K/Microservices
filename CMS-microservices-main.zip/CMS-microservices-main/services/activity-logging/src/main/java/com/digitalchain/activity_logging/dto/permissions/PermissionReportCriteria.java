package com.digitalchain.activity_logging.dto.permissions;


import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class PermissionReportCriteria {
    @NotNull
    private String reportName;
    private Date startDate;
    private Date endDate = new Date();
    private List<String> assigners = Collections.emptyList();
    private List<String> assignees = Collections.emptyList();
    private List<String> folderPath = Collections.emptyList();
    private boolean includeSubFolders;
}
