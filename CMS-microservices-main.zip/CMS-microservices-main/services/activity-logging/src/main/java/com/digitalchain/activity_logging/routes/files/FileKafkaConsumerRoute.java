package com.digitalchain.activity_logging.routes.files;

import com.digitalchain.activity_logging.service.FileActivityService;
import com.digitalchain.common.dto.files.FileLogDTO;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FileKafkaConsumerRoute extends RouteBuilder {

    @Autowired
    FileActivityService fileActivityService;

    @Override
    public void configure() throws Exception {
        // Kafka Consumer route for file activity logs
        from("kafka:{{file.activity.logging.topic}}?brokers={{camel.component.kafka.brokers}}")
                .routeId("kafkaFileActivityLoggingRoute")
                .log("Received file log from Kafka: ${body}")
                .unmarshal().json(FileLogDTO.class)  // Deserialize JSON to FileLogDTO
                .process(exchange -> {
                    // Extract the FileLogDTO object from the Kafka message
                    FileLogDTO fileLogDTO = exchange.getIn().getBody(FileLogDTO.class);
                    fileActivityService.logFileActivity(fileLogDTO);  // Call your service to process the log
                });
    }
}
