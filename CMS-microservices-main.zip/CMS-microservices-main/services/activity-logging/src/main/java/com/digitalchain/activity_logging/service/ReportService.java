    package com.digitalchain.activity_logging.service;

    import com.digitalchain.activity_logging.enumerations.Services;
    import com.digitalchain.activity_logging.model.Reports;
    import com.digitalchain.activity_logging.repository.ReportsRepository;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.data.domain.Page;
    import org.springframework.data.domain.PageRequest;
    import org.springframework.data.domain.Pageable;
    import org.springframework.stereotype.Service;

    import java.util.UUID;

    @Service
    public class ReportService {

        @Autowired
        private ReportsRepository reportsRepository;

        public Page<Reports> getReportsByReportFor(Services reportFor, Pageable pageable) {
            return reportsRepository.findAllByReportFor(reportFor, pageable);
        }

        public void deleteReport(UUID reportId, Services reportFor) {
            // Find the report by ID
            Reports report = reportsRepository.findById(reportId)
                    .orElseThrow(() -> new RuntimeException("Report not found with ID: " + reportId));

            // Validate if the reportFor matches
            if (!report.getReportFor().equals(reportFor)) {
                throw new RuntimeException("Invalid reportFor: " + report.getReportFor());
            }

            // Perform the delete operation if the validation passes
            reportsRepository.delete(report);
        }
    }
