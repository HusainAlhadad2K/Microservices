package com.digitalchain.activity_logging.model;


import com.digitalchain.activity_logging.enumerations.ReportStatus;
import com.digitalchain.activity_logging.enumerations.Services;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.UUID;

@Entity
@Getter
@Setter
@AllArgsConstructor
@Builder
@NoArgsConstructor
@Table(name = "reports")
public class Reports {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;  // Unique identifier for the report

    @Column(name = "report_name", nullable = false)
    private String reportName;  // The name or description of the report

    @Column(name = "generated_by", nullable = false)
    private String generatedBy;  // ID of the user who generated the report

    @Column(name = "created_at", nullable = false)
    private Date createdAt = new Date();  // The timestamp when the report was generated

    @Column(name = "criteria", columnDefinition = "TEXT")
    private String criteria;  // The criteria used to generate the report (stored as JSON or a string)

    @Column(name = "report_for", nullable = false)
    @Enumerated(EnumType.STRING)
    private Services reportFor;

    @Column(name = "file_location")
    private String fileLocation;  // Path to the report file if it's saved as a file (e.g., CSV, PDF)

    @Column(name = "report_status")
    @Enumerated(EnumType.STRING)
    private ReportStatus reportStatus;  // Status of the report (e.g., PENDING, COMPLETED, FAILED)
}
