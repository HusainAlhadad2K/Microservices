package com.digitalchain.activity_logging.service;

import com.digitalchain.activity_logging.model.LinkActivityLog;
import com.digitalchain.activity_logging.repository.LinkActivityLogRepository;
import com.digitalchain.common.dto.links.LinkLogDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.UUID;
@Service
public class LinkActivityLogService {
    @Autowired
    private LinkActivityLogRepository linkActivityLogRepository;

    public void logLinkActivity(LinkLogDTO log) {
        LinkActivityLog linkLog = LinkActivityLog.builder()
                .linkId(log.getLink_id())
                .target_id(log.getTarget_id())
                .target_type(log.getTarget_type())
                .target_name(log.getTarget_name())
                .userId(log.getUserId())
                .userName(log.getUserName())
                .accessMethod(log.getAccessMethod())
                .device(log.getDevice())
                .ipAddress(log.getIpAddress())
                .city(log.getCity())
                .country(log.getCountry())
                .actionTime(log.getActionTime())
                .build();
        linkActivityLogRepository.save(linkLog);
    }

    public Page<LinkActivityLog> getLinkLogs(UUID link_id, int page, int size, String sortBy, String sortDirection) {
        // Define sorting logic
        Sort sort = Sort.by(Sort.Direction.fromString(sortDirection), sortBy);

        // Create pageable object with sorting
        Pageable pageable = PageRequest.of(page, size, sort);

        // Fetch data from repository with pagination and sorting
        return linkActivityLogRepository.findAllByLinkId(link_id, pageable);
    }

}