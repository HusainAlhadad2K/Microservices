package com.digitalchain.activity_logging.repository;

import com.digitalchain.activity_logging.enumerations.Services;
import com.digitalchain.activity_logging.model.Reports;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface ReportsRepository extends JpaRepository<Reports, UUID> {
    Page<Reports> findAllByReportFor(Services reportFor, Pageable pageable);
}
