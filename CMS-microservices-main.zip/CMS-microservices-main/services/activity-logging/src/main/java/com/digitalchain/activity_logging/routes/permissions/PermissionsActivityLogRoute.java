package com.digitalchain.activity_logging.routes.permissions;

import com.digitalchain.activity_logging.config.BaseRouteBuilder;
import com.digitalchain.activity_logging.dto.permissions.PermissionReportCriteria;
import com.digitalchain.activity_logging.enumerations.Services;
import com.digitalchain.activity_logging.model.PermissionsActivityLog;
import com.digitalchain.activity_logging.model.Reports;
import com.digitalchain.activity_logging.service.CsvExportService;
import com.digitalchain.activity_logging.service.PermissionActivityLogService;
import com.digitalchain.activity_logging.service.ReportService;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

import static org.apache.camel.model.rest.RestParamType.path;
import static org.apache.camel.model.rest.RestParamType.query;

@Component
public class PermissionsActivityLogRoute extends BaseRouteBuilder {

    @Autowired
    private PermissionActivityLogService permissionActivityLogService;

    @Autowired
    private ReportService reportService;

    @Autowired
    private CsvExportService csvExportService;

    @Override
    public void configure() throws Exception {
        super.configure();

        rest("/reports/permissions").description("Permissions activity logging and report management APIs")

                // Get paginated reports
                .get().description("Get paginated list of permissions activity reports")
                .param().name("page").type(query).description("Page number for pagination").dataType("int").defaultValue("0").required(false).endParam()
                .param().name("size").type(query).description("Number of records per page").dataType("int").defaultValue("10").required(false).endParam()
                .responseMessage().code(200).message("Reports retrieved successfully").endResponseMessage()
                .responseMessage().code(500).message("Server error").endResponseMessage()
                .to("direct:getReportsForPermissions")

                // Export permissions logs to CSV
                .get("/{reportId}/export").description("Export permissions activity logs to CSV")
                .param().name("reportId").type(path).description("UUID of the report to export").dataType("uuid").required(true).endParam()
                .produces("text/csv")
                .responseMessage().code(200).message("CSV export successful").endResponseMessage()
                .responseMessage().code(404).message("Report not found").endResponseMessage()
                .to("direct:exportPermissionsLogsToCsv")

                // Get paginated permissions logs by report ID
                .get("/{reportId}").description("Get paginated permissions activity logs by report ID")
                .param().name("reportId").type(path).description("UUID of the report").dataType("uuid").required(true).endParam()
                .param().name("page").type(query).description("Page number for pagination").dataType("int").defaultValue("0").required(false).endParam()
                .param().name("size").type(query).description("Number of records per page").dataType("int").defaultValue("10").required(false).endParam()
                .param().name("sortField").type(query).description("Field to sort logs").dataType("string").defaultValue("created_at").required(false).endParam()
                .param().name("sortDirection").type(query).description("Sort direction (ASC/DESC)").dataType("string").defaultValue("DESC").required(false).endParam()
                .responseMessage().code(200).message("Logs retrieved successfully").endResponseMessage()
                .responseMessage().code(404).message("Report not found").endResponseMessage()
                .to("direct:getLogsForPermissionsReport")

                // Generate a new permissions report
                .post().description("Generate a new permissions activity report")
                .type(PermissionReportCriteria.class)
                .responseMessage().code(201).message("Report generated successfully").endResponseMessage()
                .responseMessage().code(400).message("Invalid report criteria").endResponseMessage()
                .to("direct:generatePermissionsReport")

                // Delete a permissions report
                .delete("/{reportId}").description("Delete a permissions activity report by report ID")
                .param().name("reportId").type(path).description("UUID of the report to delete").dataType("uuid").required(true).endParam()
                .responseMessage().code(200).message("Report deleted successfully").endResponseMessage()
                .responseMessage().code(404).message("Report not found").endResponseMessage()
                .to("direct:deletePermissionsReport");

        // Route for generating permissions report
        from("direct:generatePermissionsReport")
                .routeId("generatePermissionsReport")
                .process(this::generateReport);

        // Route for getting paginated reports
        from("direct:getReportsForPermissions")
                .routeId("getReportsForPermissions")
                .process(this::getReports);

        // Route for getting paginated logs
        from("direct:getLogsForPermissionsReport")
                .routeId("getLogsForPermissionsReport")
                .process(this::getReportLogs);

        // Route for exporting logs to CSV
        from("direct:exportPermissionsLogsToCsv")
                .routeId("exportPermissionsLogsToCsv")
                .process(this::exportLogsToCsv)
                .setHeader(Exchange.CONTENT_TYPE, constant("text/csv"))
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        // Route for deleting a permissions report
        from("direct:deletePermissionsReport")
                .routeId("deletePermissionsReport")
                .process(this::deletePermissionsReport);
    }

    // Method to generate the report based on criteria
    private void generateReport(Exchange exchange) {
        PermissionReportCriteria criteria = exchange.getIn().getBody(PermissionReportCriteria.class);

        String generatedBy = exchange.getProperty("user", String.class);

        Reports report = permissionActivityLogService.generateReport(criteria, generatedBy);

        exchange.getIn().setBody(report);
    }

    // Method to get paginated reports for permissions activity
    private void getReports(Exchange exchange) {
        int size = exchange.getIn().getHeader("size", 10, Integer.class);
        int page = exchange.getIn().getHeader("page", 0, Integer.class);

        Pageable pageable = PageRequest.of(page, size);

        Page<Reports> reports = reportService.getReportsByReportFor(Services.PERMISSIONS, pageable);

        exchange.getIn().setBody(reports);
    }

    // Method to get paginated logs for a report
    private void getReportLogs(Exchange exchange) throws Exception {
        UUID reportId = exchange.getIn().getHeader("reportId", UUID.class);

        int page = exchange.getIn().getHeader("page", 0, Integer.class);
        int size = exchange.getIn().getHeader("size", 10, Integer.class);
        String sortField = exchange.getIn().getHeader("sortField", "created_at", String.class);
        String sortDirection = exchange.getIn().getHeader("sortDirection", "DESC", String.class);

        Page<PermissionsActivityLog> logs = permissionActivityLogService.getPaginatedLogs(reportId, page, size, sortField, sortDirection);

        exchange.getIn().setBody(logs);
    }

    // Method to export permissions activity logs to CSV
    private void exportLogsToCsv(Exchange exchange) throws Exception {
        UUID reportId = exchange.getIn().getHeader("reportId", UUID.class);

        List<PermissionsActivityLog> logs = permissionActivityLogService.getLogsForExport(reportId);

        String csvData = csvExportService.exportToCsv(logs);

        exchange.getIn().setBody(csvData);
        String fileName = "permissions-report-" + reportId.toString() + ".csv";
        exchange.getIn().setHeader("Content-Disposition", "attachment; filename=" + fileName);
    }

    // Method to delete a permissions report
    private void deletePermissionsReport(Exchange exchange) {
        UUID reportId = exchange.getIn().getHeader("reportId", UUID.class);

        reportService.deleteReport(reportId, Services.PERMISSIONS);

        exchange.getIn().setBody("Report deleted successfully.");
    }
}
