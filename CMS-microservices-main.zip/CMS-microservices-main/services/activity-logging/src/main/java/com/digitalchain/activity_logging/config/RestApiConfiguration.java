package com.digitalchain.activity_logging.config;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.stereotype.Component;

@Component
public class RestApiConfiguration extends RouteBuilder {
    @Override
    public void configure() throws Exception {
        restConfiguration()
                .component("servlet")
                .bindingMode(RestBindingMode.json)
                .dataFormatProperty("prettyPrint", "true")
                .contextPath("/api")  // Base path for all your REST services
                .apiContextPath("/reports/doc")  // Swagger UI path
                .apiProperty("api.title", "Activity Logging")
                .apiProperty("api.version", "1.0")
                .apiProperty("api.description", "Operations related to activity logging in the CMS")
                .apiProperty("host", "")
                .apiProperty("schemes", "http,https")
                .apiProperty("base.path", "/api")
                .apiProperty("cors", "true");  // Enable CORS support
    }
}