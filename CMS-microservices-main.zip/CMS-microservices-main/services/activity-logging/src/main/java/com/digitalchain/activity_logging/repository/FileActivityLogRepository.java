package com.digitalchain.activity_logging.repository;

import com.digitalchain.activity_logging.model.FileActivityLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public interface FileActivityLogRepository extends JpaRepository<FileActivityLog, UUID> {
    @Query(value = "SELECT * FROM file_activity_logs log " +
            "WHERE log.action_time >= COALESCE(:startDate, CAST('1970-01-01 00:00:00' AS timestamp)) " +
            "AND log.action_time <= COALESCE(:endDate, CAST('9999-12-31 23:59:59' AS timestamp)) " +
            "AND (:userId IS NULL OR log.user_id IN (:userId)) " +
            "AND (:action IS NULL OR log.action = :action) " +
            "AND (:filePath IS NULL OR log.file_path = :filePath) " +
            "AND (:folderPath IS NULL OR log.file_path LIKE ANY (ARRAY(SELECT CONCAT(:folderPath, '%'))))",
            nativeQuery = true)
    List<FileActivityLog> findLogsForReport(@Param("startDate") Date startDate,
                                            @Param("endDate") Date endDate,
                                            @Param("userId") List<String> userId,
                                            @Param("action") String action,
                                            @Param("filePath") String filePath,
                                            @Param("folderPath") List<String> folderPath);

    @Query(value = "SELECT * FROM file_activity_logs log " +
            "WHERE log.action_time >= COALESCE(:startDate, CAST('1970-01-01 00:00:00' AS timestamp)) " +
            "AND log.action_time <= COALESCE(:endDate, CAST('9999-12-31 23:59:59' AS timestamp)) " +
            "AND (:userId IS NULL OR log.user_id IN (:userId)) " +
            "AND (:action IS NULL OR log.action = :action) " +
            "AND (:filePath IS NULL OR log.file_path = :filePath) " +
            "AND (:folderPath IS NULL OR log.file_path LIKE ANY (ARRAY(SELECT CONCAT(:folderPath, '%'))))",
            nativeQuery = true)
    Page<FileActivityLog> findLogsForReportWithPaging(@Param("startDate") Date startDate,
                                                      @Param("endDate") Date endDate,
                                                      @Param("userId") List<String> userId,
                                                      @Param("action") String action,
                                                      @Param("filePath") String filePath,
                                                      @Param("folderPath") List<String> folderPath,
                                                      Pageable pageable);

    @Query(value = "SELECT * FROM file_activity_logs log " +
            "WHERE log.action_time >= COALESCE(:startDate, CAST('1970-01-01 00:00:00' AS timestamp)) " +
            "AND log.action_time <= COALESCE(:endDate, CAST('9999-12-31 23:59:59' AS timestamp)) " +
            "AND (:action IS NULL OR log.action = :action) " +
            "AND (:filePath IS NULL OR log.file_path = :filePath)",
            nativeQuery = true)
    Page<FileActivityLog> findLogsForReportWithPagingWithoutLists(
            @Param("startDate") Date startDate,
            @Param("endDate") Date endDate,
            @Param("action") String action,
            @Param("filePath") String filePath,
            Pageable pageable);


}
