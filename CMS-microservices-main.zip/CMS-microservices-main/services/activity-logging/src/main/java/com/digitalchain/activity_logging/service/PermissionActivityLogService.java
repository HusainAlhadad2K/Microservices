package com.digitalchain.activity_logging.service;


import com.digitalchain.activity_logging.dto.login.LoginReportCriteria;
import com.digitalchain.activity_logging.dto.permissions.PermissionReportCriteria;
import com.digitalchain.activity_logging.enumerations.ReportStatus;
import com.digitalchain.activity_logging.enumerations.Services;
import com.digitalchain.activity_logging.model.LoginActivityLog;
import com.digitalchain.activity_logging.model.PermissionsActivityLog;
import com.digitalchain.activity_logging.model.Reports;
import com.digitalchain.activity_logging.repository.PermissionActivityLogRepository;
import com.digitalchain.activity_logging.repository.ReportsRepository;
import com.digitalchain.activity_logging.utils.CriteriaParser;
import com.digitalchain.common.dto.permissions.PermissionLogDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class PermissionActivityLogService {
    @Autowired
    private PermissionActivityLogRepository permissionActivityLogRepository;

    @Autowired
    private ReportsRepository reportsRepository;

    public void logPermissionActivity(PermissionLogDTO permissionLog){
        PermissionsActivityLog permissionsActivityLog = PermissionsActivityLog.builder()
                .changedFor(permissionLog.getChangedFor())
                .changeType(permissionLog.getChangeType())
                .folderId(permissionLog.getFolderId())
                .folderPath(permissionLog.getFolderPath())
                .previousRole(permissionLog.getPreviousRole())
                .newRole(permissionLog.getNewRole())
                .userId(permissionLog.getChangedById())
                .userName(permissionLog.getChangedByName())
                .ipAddress(permissionLog.getChangedByIp())
                .actionInfo(permissionLog.getActionInfo())
                .actionTime(permissionLog.getActionTime())
                .build();

        permissionActivityLogRepository.save(permissionsActivityLog);
    }
    public Reports generateReport(PermissionReportCriteria criteria, String generatedBy){
        Reports report = Reports.builder()
                .reportName(criteria.getReportName())
                .generatedBy(generatedBy)
                .criteria(CriteriaParser.stringify(criteria))
                .reportStatus(ReportStatus.PENDING)
                .createdAt(new Date())
                .reportFor(Services.PERMISSIONS)
                .build();

        reportsRepository.save(report);

        try {
            // Fetch logs based on the criteria
            permissionActivityLogRepository.findLogsForReportWithPaging(
                    criteria.getStartDate(),
                    criteria.getEndDate(),
                    criteria.getAssignees(),
                    criteria.getAssigners(),
                    criteria.getFolderPath(),
                    PageRequest.of(0, 1)
            );

            report.setReportStatus(ReportStatus.COMPLETED);
            reportsRepository.save(report);  // Update report status to completed

            return report;
        } catch (Exception e) {
            report.setReportStatus(ReportStatus.FAILED);
            reportsRepository.save(report);

            throw new RuntimeException("Error generating permissions activity report", e);
        }
    }
    public List<PermissionsActivityLog> getLogsForExport(UUID reportId) throws Exception {
        Reports report = reportsRepository.findById(reportId)
                .orElseThrow(() -> new RuntimeException("Report not found"));

        if (!report.getReportFor().equals(Services.PERMISSIONS)) {
            throw new IllegalAccessException("Invalid report");
        }

        // Parse the stored criteria
        PermissionReportCriteria criteria = CriteriaParser.parse(report.getCriteria(), PermissionReportCriteria.class);

        // Fetch all data without paging for export, with sorting applied
        return permissionActivityLogRepository.findLogsForReport(
                criteria.getStartDate(),
                criteria.getEndDate(),
                criteria.getAssignees(),
                criteria.getAssigners(),
                criteria.getFolderPath()
        );
    }
    public Page<PermissionsActivityLog> getPaginatedLogs(UUID reportId, int page, int size, String sortField, String sortDirection) throws Exception {
        Reports report = reportsRepository.findById(reportId)
                .orElseThrow(() -> new RuntimeException("Report not found"));

        if (!report.getReportFor().equals(Services.PERMISSIONS)) {
            throw new IllegalAccessException("Invalid report");
        }

        // Parse the stored criteria
        PermissionReportCriteria criteria = CriteriaParser.parse(report.getCriteria(), PermissionReportCriteria.class);

        // Determine sort order
        Sort sort = Sort.by(Sort.Direction.fromString(sortDirection), sortField);

        // Apply paging logic with sorting
        Pageable pageable = PageRequest.of(page, size, sort);

        // Fetch paginated data
        return permissionActivityLogRepository.findLogsForReportWithPaging(
                criteria.getStartDate(),
                criteria.getEndDate(),
                criteria.getAssignees(),
                criteria.getAssigners(),
                criteria.getFolderPath(),
                pageable
        );
    }
}
