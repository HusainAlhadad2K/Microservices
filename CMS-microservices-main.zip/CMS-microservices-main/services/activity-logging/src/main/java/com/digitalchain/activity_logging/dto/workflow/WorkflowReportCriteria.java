package com.digitalchain.activity_logging.dto.workflow;

import com.digitalchain.common.dto.workflow.WorkflowAction;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.Date;
import java.util.List;


@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class WorkflowReportCriteria {
    @NotNull
    private String reportName;
    private Date startDate;
    private Date endDate = new Date();
    private List<String> userId = Collections.emptyList();
    private WorkflowAction action;
    private String workflowType;
    private String filePath;
    private List<String> folderPath = Collections.emptyList();
}
