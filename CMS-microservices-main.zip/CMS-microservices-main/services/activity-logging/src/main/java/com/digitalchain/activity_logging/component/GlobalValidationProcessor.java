package com.digitalchain.activity_logging.component;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ValidationException;
import jakarta.validation.Validator;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class GlobalValidationProcessor implements Processor {

    @Autowired
    private Validator validator;

    @Override
    public void process(Exchange exchange) throws Exception {
        Object body = exchange.getIn().getBody();

        String httpMethod = exchange.getProperty("originalMethod", String.class);
        if ("GET".equalsIgnoreCase(httpMethod)) {
            return; // Skip validation
        }

        // Perform validation if the body is a DTO
        Set<ConstraintViolation<Object>> violations = validator.validate(body);

        // If there are validation errors, throw a validation exception
        if (!violations.isEmpty()) {
            StringBuilder validationErrors = new StringBuilder();
            for (ConstraintViolation<Object> violation : violations) {
                validationErrors.append(violation.getPropertyPath())
                        .append(": ")
                        .append(violation.getMessage())
                        .append("\n");
            }
            throw new ValidationException("Validation failed: \n" + validationErrors);
        }
    }
}
