package com.digitalchain.activity_logging.dto.login;

import com.digitalchain.common.dto.AccessMethod;
import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.common.dto.login.LoginLogAction;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LoginReportCriteria {
    @NotNull
    private String reportName;
    private Date startDate;
    private Date endDate = new Date();
    private List<String> userId = Collections.emptyList();
    private LoginLogAction action;
    private AccessMethod accessMethod;
}
