package com.digitalchain.settings_service.model.workflow;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import java.util.Date;
import java.util.UUID;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "GeneralSettings")
public class GeneralSettings {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "reminder_be4_due_date")
    private Boolean reminderB4Due;

    @Column(name = "reminder_after_due_date")
    private Boolean reminderAfterDue;

    @Column(name = "reminder_after_every_numb_days")
    private Integer reminderAfterEveryDays;

    @Column(name = "reminder_b4_every_numb_days")
    private Integer reminderBeforeEveryDays;

//    @Column(name = "reason")
//    private String reason;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date createdAt;

}
