package com.digitalchain.settings_service.exception;

public class UnsupportedMediaTypeException extends RuntimeException {
    public UnsupportedMediaTypeException(String message){super(message);}
}
