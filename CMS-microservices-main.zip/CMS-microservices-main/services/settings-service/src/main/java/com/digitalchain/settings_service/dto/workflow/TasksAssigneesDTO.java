package com.digitalchain.settings_service.dto.workflow;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TasksAssigneesDTO {
    private UUID id;
    private String createdBy;


    private UUID grId;  // Change to UUID instead of String

    private UUID specUserId;

    private Boolean anyone;
    private Boolean anyoneGr;
    private Integer minReq;
    private Integer minReqStep;
    private Integer days;

}
