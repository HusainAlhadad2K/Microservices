package com.digitalchain.settings_service.dto.workflow;

import com.digitalchain.settings_service.Enumerations.workflow.FileTypeEnum;
import com.digitalchain.settings_service.Enumerations.workflow.FolderTypeEnum;
import com.digitalchain.settings_service.Enumerations.workflow.WhoCanUseEnum;
import com.digitalchain.settings_service.Enumerations.workflow.WorkflowStatusEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkflowTemplateDTO {

    private UUID id;
    private String createdBy;
    private Date createdAt;
    private String version;
    private String workflowName;
    private String workflowDescription;

    private Boolean anyone;
    private WhoCanUseEnum who;  // Enum to match the model field
    private Boolean anyFileType;
    private String fileType;// Can be null if fileTypeEnum is 'any_file_type'
    private Boolean anyFolderType;
    private String folderType; // Can be null if folderTypeEnum is 'any_folder'

    private FolderTypeEnum folderTypeEnum;  // Use Enum type instead of String
    private FileTypeEnum fileTypeEnum;      // Use Enum type instead of String
    private WorkflowStatusEnum workflowStatusEnum;

    private Boolean customReminder;
    private Boolean noB4Reminder;  // Match the model field 'NoB4Reminder'
    private Boolean noAfterReminder;  // Match the model field 'NoAfterReminder'
    private Boolean allowOverride;

    private Integer reminderBeforeEveryDays;  // Can be null in specific cases
    private Integer reminderAfterEveryDays;   // Can be null in specific cases

    private UUID groupName;
    private List<StepsDTO> steps;
    private UUID generalSettingsId;
}
