package com.digitalchain.settings_service.Enumerations.branding;

public enum AuthMethodEnum {
    BASIC
}
