package com.digitalchain.settings_service.dto.workflow;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GeneralSettingsDTO {
    //private UUID id;
    private String createdBy;
    private Boolean reminderBeforeDueDate;
    private Boolean reminderAfterDueDate;
    private Integer reminderBeforeEveryDays;
    private Integer reminderAfterEveryDays;
    //private String reason;
    private Date createdAt;

}
