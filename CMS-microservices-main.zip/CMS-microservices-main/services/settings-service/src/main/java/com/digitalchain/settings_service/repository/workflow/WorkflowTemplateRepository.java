package com.digitalchain.settings_service.repository.workflow;

import com.digitalchain.settings_service.Enumerations.workflow.WorkflowStatusEnum;
import com.digitalchain.settings_service.model.workflow.WorkflowTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface WorkflowTemplateRepository extends JpaRepository<WorkflowTemplate, UUID> {
        List<WorkflowTemplate> findAllByWorkflowName(String workflowName);

        // Method to find workflow templates by their status
        List<WorkflowTemplate> findAllByWorkflowStatusEnum(WorkflowStatusEnum status);
}
