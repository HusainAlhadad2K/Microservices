package com.digitalchain.settings_service.routes.branding;

import com.digitalchain.settings_service.Enumerations.workflow.WorkflowStatusEnum;
import com.digitalchain.settings_service.config.BaseRouteBuilder;
import com.digitalchain.settings_service.dto.UserDTO;
import com.digitalchain.settings_service.dto.branding.BrandingDTO;
import com.digitalchain.settings_service.dto.workflow.WorkflowTemplateDTO;
import com.digitalchain.settings_service.exception.ResourceNotFoundException;
import com.digitalchain.settings_service.model.branding.Branding;
import com.digitalchain.settings_service.model.workflow.WorkflowTemplate;
import com.digitalchain.settings_service.service.branding.BrandingService;
import com.digitalchain.settings_service.service.workflow.WorkflowTemplateService;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class BrandingRoute extends BaseRouteBuilder {

    @Autowired
    private BrandingService brandingService;

    @Override
    public void configure() throws Exception {
        super.configure();

        rest("/settings")
                // POST request to create a new branding record
                .post("/branding")
                .type(BrandingDTO.class)
                .description("Creates a new branding record")
                .responseMessage().code(200).message("Branding created successfully").endResponseMessage()
                .to("direct:createBranding")

                // GET request to get a branding record by ID
                .get("/branding/{id}")
                .description("Gets branding record by ID")
                .param().name("id").type(RestParamType.path).dataType("UUID").required(true).description("Branding ID").endParam()
                .responseMessage().code(200).message("Branding retrieved successfully").endResponseMessage()
                .to("direct:getBranding");

        // Route for creating a branding record
        from("direct:createBranding")
                .routeId("createBranding")
                .process(exchange -> {
                    BrandingDTO brandingDTO = exchange.getIn().getBody(BrandingDTO.class);
                    UserDTO user = exchange.getProperty("user", UserDTO.class); // Assuming user info is stored in exchange properties
                    // Call the service to create the branding record
                    Branding createdBranding = brandingService.createBranding(brandingDTO, user.getUser_id());

                    // Return the created branding record as a response
                    exchange.getIn().setBody(createdBranding);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .log("Branding record created successfully with ID: ${body.id}")
                .onException(Exception.class)
                .handled(true)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(500))
                .setBody(simple("Error occurred while creating branding record: ${exception.message}"));

        // Route for getting a branding record by ID
        from("direct:getBranding")
                .routeId("getBranding")
                .process(exchange -> {
                    UUID id = exchange.getIn().getHeader("id", UUID.class);
                    BrandingDTO brandingDTO = brandingService.getBrandingById(id);
                    exchange.getIn().setBody(brandingDTO);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .log("Branding record retrieved successfully with ID: ${body.id}")
                .onException(ResourceNotFoundException.class)
                .handled(true)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(404))
                .setBody(simple("Branding record not found with ID: ${header.id}"));
    }
}
