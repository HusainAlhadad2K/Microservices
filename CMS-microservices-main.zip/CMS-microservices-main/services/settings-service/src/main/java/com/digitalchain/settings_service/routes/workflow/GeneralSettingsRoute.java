package com.digitalchain.settings_service.routes.workflow;

import com.digitalchain.settings_service.config.BaseRouteBuilder;
import com.digitalchain.settings_service.dto.UserDTO;
import com.digitalchain.settings_service.dto.workflow.GeneralSettingsDTO;
import com.digitalchain.settings_service.model.workflow.GeneralSettings;
import com.digitalchain.settings_service.service.workflow.GeneralSettingsService;
import org.apache.camel.Exchange;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.stereotype.Component;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

@Component
public class GeneralSettingsRoute extends BaseRouteBuilder {
    @Autowired
    private GeneralSettingsService generalSettingsService;

    @Override
    public void configure() throws Exception {

        // REST API to create and get General Settings
        rest("/settings")
                .post("/configuration/general")
                .type(GeneralSettingsDTO.class)
                .description("Create general settings")
                .responseMessage().code(200).message("General settings created").responseModel(GeneralSettingsDTO.class).endResponseMessage()
                .to("direct:createGeneralSettings")
                .get("/configuration/general/{id}")
                .description("Get general settings by ID")
                .responseMessage().code(200).message("General settings fetched").responseModel(GeneralSettingsDTO.class).endResponseMessage()
                .to("direct:getGeneralSettings");

        // Route to create General Settings
        from("direct:createGeneralSettings")
                .routeId("createGeneralSettingsRoute")
                .log("Creating general settings")
                .to("direct:validateJwt")  // Call the JWT validation route here
                .process(exchange -> {
                    GeneralSettingsDTO generalSettingsDTO = exchange.getIn().getBody(GeneralSettingsDTO.class);
                    UserDTO user = exchange.getProperty("user", UserDTO.class);  // Get user information

                    if (user == null) {
                        throw new JwtException("User not authenticated");
                    }
                    // Call the service to create a new general settings entry
                    GeneralSettings newSettings = generalSettingsService.createGeneralSettings(generalSettingsDTO, user.getUser_id());

                    // Set the response body as the ID of the newly created settings
                    exchange.getIn().setBody("General settings created with ID: " + newSettings.getId());
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                .log("General settings created: ${body}");

        // Route to get General Settings by ID
        from("direct:getGeneralSettings")
                .routeId("getGeneralSettingsRoute")
                .log("Getting general settings for ID: ${header.id}") // Log the ID from the header
                .process(exchange -> {
                    String idString = exchange.getIn().getHeader("id", String.class);
                    UUID id;

                    // Log the ID and attempt to parse it as a UUID
                    try {
                        id = UUID.fromString(idString);  // Convert the ID to UUID
                        log.info("Successfully parsed ID as UUID: {}", id);  // Log success
                    } catch (IllegalArgumentException e) {
                        log.error("Invalid UUID format for ID: {}", idString);  // Log failure
                        throw new IllegalArgumentException("Invalid UUID format");
                    }

                    // Call the service to get General Settings by ID
                    GeneralSettingsDTO generalSettingsDTO = generalSettingsService.getGeneralSettings(id);
                    log.info("Fetched GeneralSettings: {}", generalSettingsDTO);  // Log fetched result

                    exchange.getIn().setBody(generalSettingsDTO);  // Set response body
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                .log("General settings fetched successfully for ID: ${header.id}");
    }
}
