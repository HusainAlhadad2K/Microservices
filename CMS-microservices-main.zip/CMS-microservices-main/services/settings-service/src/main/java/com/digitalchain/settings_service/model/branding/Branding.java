package com.digitalchain.settings_service.model.branding;

import com.digitalchain.settings_service.Enumerations.branding.AuthMethodEnum;
import com.digitalchain.settings_service.Enumerations.branding.SecureConnectEnum;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;
import java.util.UUID;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "Branding")
public class Branding {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "created_by")
    private String createdBy;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date createdAt;

    @Column(name = "file_server_label")
    private String fileServerLabel;

    @Column(name = "logo")
    private String logo;

    @Column(name = "header_color")
    private String headerColor;

    @Column(name = "access_url")
    private String accessUrl;

    @Column(name = "help")
    private String help;

    @Column(name = "login_disclaimer")
    private Boolean loginDisclaimer;

    @Column(name = "disclaimer_text")
    private String disclaimerText;

    @Column(name = "upload_disclaimer")
    private String uploadDisclaimer;

    @Column(name = "terms_service")
    private Boolean termsService;

    @Column(name = "terms_service_text")
    private String termsServiceText;

    @Column(name = "email_templates")
    private Boolean emailTemplates;

    @Column(name = "power_subject")
    private String powerSubject;

    @Column(name = "power_msg")
    private String powerMsg;

    @Column(name = "standard_subject")
    private String standardSubject;

    @Column(name = "standard_msg")
    private String standardMsg;

    @Column(name = "mail_integration")
    private Boolean mailIntegration;

    @Enumerated(EnumType.STRING)
    @Column(name = "auth_method")
    private AuthMethodEnum authMethodEnum;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "pass")
    private String pass;

    @Column(name = "client_id")
    private String clientId;

    @Column(name = "client_secret")
    private String clientSecret;

    @Column(name = "tenant")
    private String tenant;

    @Column(name = "mail_address")
    private String mailAddress;

    @Column(name = "mail_port")
    private Integer mailPort;

    @Enumerated(EnumType.STRING)
    @Column(name = "conn_securely")
    private SecureConnectEnum connSecurely;

    @Column(name = "sender_name")
    private String senderName;

    @Column(name = "sender_email")
    private String senderEmail;

}
