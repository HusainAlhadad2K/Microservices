package com.digitalchain.settings_service.Enumerations.branding;

public enum SecureConnectEnum {
    NONE,
    SSL,
    TLS
}
