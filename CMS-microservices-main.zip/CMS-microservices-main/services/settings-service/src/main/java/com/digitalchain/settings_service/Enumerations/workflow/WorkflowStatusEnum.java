package com.digitalchain.settings_service.Enumerations.workflow;

public enum WorkflowStatusEnum {
    IN_PROGRESS,
    COMPLETED,
    PENDING
}
