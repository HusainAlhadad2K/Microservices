package com.digitalchain.settings_service.service.workflow;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.digitalchain.settings_service.Enumerations.workflow.*;
import com.digitalchain.settings_service.dto.workflow.StepsDTO;
import com.digitalchain.settings_service.dto.workflow.TasksAssigneesDTO;
import com.digitalchain.settings_service.dto.workflow.WorkflowTemplateDTO;
import com.digitalchain.settings_service.exception.ResourceNotFoundException;
import com.digitalchain.settings_service.model.workflow.GeneralSettings;
import com.digitalchain.settings_service.model.workflow.Steps;
import com.digitalchain.settings_service.model.workflow.TasksAssignees;
import com.digitalchain.settings_service.model.workflow.WorkflowTemplate;
import com.digitalchain.settings_service.repository.workflow.GeneralSettingsRepository;
import com.digitalchain.settings_service.repository.workflow.StepsRepository;
import com.digitalchain.settings_service.repository.workflow.TasksAssigneesRepository;
import com.digitalchain.settings_service.repository.workflow.WorkflowTemplateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class WorkflowTemplateService {
    private static final Logger logger = LoggerFactory.getLogger(WorkflowTemplateService.class);
    UUID defaultUUID = UUID.fromString("00000000-0000-0000-0000-000000000000");

    @Autowired
    private WorkflowTemplateRepository workflowTemplateRepository;

    @Autowired
    private StepsRepository stepsRepository;

    @Autowired
    private TasksAssigneesRepository tasksAssigneesRepository;

    @Autowired
    private GeneralSettingsRepository generalSettingsRepository;

    /**
     * Method to create a new Workflow Template, associated Steps, and TasksAssignees
     */
    @Transactional
    public WorkflowTemplate createWorkflowTemplate(WorkflowTemplateDTO workflowTemplateDTO, String userId) {
        // Creating a new workflow template
        WorkflowTemplate workflowTemplate = new WorkflowTemplate();
        workflowTemplate.setCreatedBy(userId);
        workflowTemplate.setWorkflowName(workflowTemplateDTO.getWorkflowName());
        workflowTemplate.setWorkflowDescription(workflowTemplateDTO.getWorkflowDescription());

        // Set the default version on creation
        workflowTemplate.setVersion("1.0");

        // Set the workflow status to IN_PROGRESS when creating a new workflow
        workflowTemplate.setWorkflowStatusEnum(WorkflowStatusEnum.IN_PROGRESS);

        // Handle conditional fields
        handleConditionalFields(workflowTemplate, workflowTemplateDTO);

        // Link GeneralSettings
        if (workflowTemplateDTO.getGeneralSettingsId() != null) {
            GeneralSettings generalSettings = generalSettingsRepository.findById(workflowTemplateDTO.getGeneralSettingsId())
                    .orElseThrow(() -> new ResourceNotFoundException("General Settings not found"));
            workflowTemplate.setGeneralSettings(generalSettings);
        }

        // Save workflow template
        WorkflowTemplate savedWorkflowTemplate = workflowTemplateRepository.save(workflowTemplate);

        // Save steps
        List<Steps> stepsList = workflowTemplateDTO.getSteps().stream()
                .map(stepsDTO -> createStepFromDTO(stepsDTO, savedWorkflowTemplate, userId))
                .collect(Collectors.toList());

// Ensure steps are properly saved and associated with the template
        stepsRepository.saveAll(stepsList);

        return savedWorkflowTemplate;
    }
    /**
     * Deletes the steps and tasks assignees associated with a workflow template
     */
    private void deleteStepsAndAssignees(WorkflowTemplate template) {
        // Fetch original steps and tasks assignees
        List<Steps> originalSteps = new ArrayList<>(template.getSteps());
        List<TasksAssignees> originalAssignees = originalSteps.stream()
                .flatMap(step -> step.getAssigneeId().stream())
                .collect(Collectors.toList());

        // Delete task assignees first
        tasksAssigneesRepository.deleteAll(originalAssignees);

        // Delete steps
        stepsRepository.deleteAll(originalSteps);
    }
    /**
     * Method to update a WorkflowTemplate, handling versioning logic.
     */
    @Transactional
    public String updateWorkflowTemplate(WorkflowTemplateDTO workflowTemplateDTO, UUID id) {

        try {
        // Fetch the current workflow template
        WorkflowTemplate currentTemplate = workflowTemplateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Workflow template not found"));

// Fetch all versions of the workflow template by name
            List<WorkflowTemplate> allVersions = workflowTemplateRepository.findAllByWorkflowName(currentTemplate.getWorkflowName());

            // Sort the versions by version number to get the highest version
            allVersions.sort(Comparator.comparing(WorkflowTemplate::getVersion));

            // Get the highest version template
            WorkflowTemplate latestTemplate = allVersions.get(allVersions.size() - 1);  // Last element is the latest version

            // Increment the version based on the highest version, not the current template being updated
            String newVersion = incrementVersion(latestTemplate.getVersion());

        // Disallow changes to the workflowName
        String originalName = currentTemplate.getWorkflowName();

//        // Fetch all versions of the workflow template by name
//        List<WorkflowTemplate> allVersions = workflowTemplateRepository.findAllByWorkflowName(originalName);
//
//        // If there are already 3 versions, delete the oldest version
//        if (allVersions.size() >= 3) {
//            // Sort the versions to find the oldest one
//            allVersions.sort(Comparator.comparing(WorkflowTemplate::getVersion));
//            WorkflowTemplate oldestTemplate = allVersions.get(0);
//
//            // Delete the oldest template's steps and task assignees
//            deleteStepsAndAssignees(oldestTemplate);
//
//            // Delete the oldest template itself
//            workflowTemplateRepository.delete(oldestTemplate);
//        }

        // Increment the version for the new template
        // String newVersion = incrementVersion(currentTemplate.getVersion());

        // Create a new workflow template version (incremented version)
        WorkflowTemplate newTemplate = new WorkflowTemplate();
        newTemplate.setWorkflowName(originalName); // Keep the original workflow name
        newTemplate.setWorkflowDescription(workflowTemplateDTO.getWorkflowDescription());
        newTemplate.setCreatedBy(currentTemplate.getCreatedBy()); // Maintain the original creator
        newTemplate.setVersion(newVersion); // Increment the version
        newTemplate.setWorkflowStatusEnum(workflowTemplateDTO.getWorkflowStatusEnum() != null
                ? workflowTemplateDTO.getWorkflowStatusEnum()
                : WorkflowStatusEnum.IN_PROGRESS); // Default status if not provided
        // Ensure GeneralSettings is properly set
        if (workflowTemplateDTO.getGeneralSettingsId() != null) {
            GeneralSettings generalSettings = generalSettingsRepository.findById(workflowTemplateDTO.getGeneralSettingsId())
                    .orElseThrow(() -> new ResourceNotFoundException("General Settings not found"));
            newTemplate.setGeneralSettings(generalSettings); // Save GeneralSettings in the workflow template
        }
        // Handle conditional fields for the new workflow template
        handleConditionalFields(newTemplate, workflowTemplateDTO);

        // **Save the new workflow template before assigning it to steps**
        WorkflowTemplate savedTemplate = workflowTemplateRepository.save(newTemplate);

        // Re-create steps and task assignees for the new version
        List<Steps> updatedStepsList = workflowTemplateDTO.getSteps().stream()
                .map(stepsDTO -> createStepFromDTO(stepsDTO, savedTemplate, currentTemplate.getCreatedBy())) // Use savedTemplate here
                .collect(Collectors.toList());

        // Save the new steps
        savedTemplate.getSteps().addAll(updatedStepsList);
        stepsRepository.saveAll(updatedStepsList);

        // Handle version cleanup, ensuring only the last 3 versions remain
            handleVersionCleanup(savedTemplate);

        // Return the newly saved workflow template version
        return "Workflow template updated successfully";
        } catch (Exception e) {
            logger.error("Error updating workflow template", e);
            throw e;
        }
    }

    /**
     * Helper method to handle conditional field logic
     */

        private void handleConditionalFields(WorkflowTemplate template, WorkflowTemplateDTO dto) {
            // Handling 'who' logic
            if (dto.getWho() != null && dto.getWho().equals(WhoCanUseEnum.anyone)) {
                template.setAnyone(true);
                template.setGroupName(defaultUUID); // Set default UUID for 'anyone'
                template.setWho(WhoCanUseEnum.anyone); // Set 'who' field properly
            } else if (dto.getWho() != null && dto.getWho().equals(WhoCanUseEnum.specific_group)) {
                template.setAnyone(false);
                template.setGroupName(dto.getGroupName()); // Use the provided groupName
                template.setWho(WhoCanUseEnum.specific_group); // Set 'who' field properly
            }

            // Handling 'fileTypeEnum' logic
            if (dto.getFileTypeEnum() != null && dto.getFileTypeEnum().equals(FileTypeEnum.any_file_type)) {
                template.setAnyFileType(true);
                template.setFileType(null); // No file type needed for 'any_file_type'
                template.setFileTypeEnum(FileTypeEnum.any_file_type); // Set fileTypeEnum properly
            } else if (dto.getFileTypeEnum() != null && dto.getFileTypeEnum().equals(FileTypeEnum.specific_file_types)) {
                template.setAnyFileType(false);
                template.setFileType(dto.getFileType()); // Use the provided fileType
                template.setFileTypeEnum(FileTypeEnum.specific_file_types); // Set fileTypeEnum properly
            }

            // Handling 'folderTypeEnum' logic
            if (dto.getFolderTypeEnum() != null && dto.getFolderTypeEnum().equals(FolderTypeEnum.any_folder)) {
                template.setAnyFolderType(true);
                template.setFolderType(null); // No folder type needed for 'any_folder'
                template.setFolderTypeEnum(FolderTypeEnum.any_folder); // Set folderTypeEnum properly
            } else if (dto.getFolderTypeEnum() != null && dto.getFolderTypeEnum().equals(FolderTypeEnum.specific_folder)) {
                template.setAnyFolderType(false);
                template.setFolderType(dto.getFolderType()); // Use the provided folderType
                template.setFolderTypeEnum(FolderTypeEnum.specific_folder); // Set folderTypeEnum properly
            }

        // Handling 'customReminder' and associated fields logic
            if (dto.getCustomReminder()) {
                template.setCustomReminder(true);
                template.setAllowOverride(dto.getAllowOverride() != null ? dto.getAllowOverride() : false);

                // Handle NoB4Reminder and reminderBeforeEveryDays
                if (dto.getNoB4Reminder()) {
                    template.setNoB4Reminder(true);
                    template.setReminderBeforeEveryDays(null);
                } else {
                    template.setNoB4Reminder(false);
                    template.setReminderBeforeEveryDays(dto.getReminderBeforeEveryDays());
                }

                // Handle NoAfterReminder and reminderAfterEveryDays
                if (dto.getNoAfterReminder()) {
                    template.setNoAfterReminder(true);
                    template.setReminderAfterEveryDays(null);
                } else {
                    template.setNoAfterReminder(false);
                    template.setReminderAfterEveryDays(dto.getReminderAfterEveryDays());
                }
            } else {
                template.setCustomReminder(false);
                template.setAllowOverride(false);
                template.setNoB4Reminder(true);
                template.setNoAfterReminder(true);
                template.setReminderBeforeEveryDays(null);
                template.setReminderAfterEveryDays(null);
            }
    }

    /**
     * Helper method to handle version increment.
     */
    private String incrementVersion(String currentVersion) {
        String[] versionParts = currentVersion.split("\\.");
        int majorVersion = Integer.parseInt(versionParts[0]);
        int minorVersion = Integer.parseInt(versionParts[1]);

        // Increment minor version, and if it exceeds 9, roll over to next major version
        minorVersion += 1;
        if (minorVersion >= 10) {
            minorVersion = 0;
            majorVersion += 1;
        }

        return majorVersion + "." + minorVersion;
    }

    /**
     * Method to handle deletion of old versions after new updates.
     */
    private void handleVersionCleanup(WorkflowTemplate updatedTemplate) {
        // Fetch all templates with the same workflow name
        List<WorkflowTemplate> allTemplates = workflowTemplateRepository.findAllByWorkflowName(updatedTemplate.getWorkflowName());

        if (allTemplates.size() > 3) {
            // Sort the templates by version to find the oldest ones
            allTemplates.sort(Comparator.comparing(WorkflowTemplate::getVersion));

            // Identify the oldest template and delete it if there are more than 3 versions
            while (allTemplates.size() > 3) {
                WorkflowTemplate oldestTemplate = allTemplates.remove(0);  // Remove the first (oldest) element
                deleteStepsAndAssignees(oldestTemplate); // Clean up associated steps and assignees
                workflowTemplateRepository.delete(oldestTemplate);
            }
        }
    }
    public WorkflowTemplateDTO getWorkflowTemplate(UUID id) {
        // Fetch the workflow template by ID from the repository
        WorkflowTemplate template = workflowTemplateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Workflow template not found with ID: " + id));

        // Convert the WorkflowTemplate entity to WorkflowTemplateDTO using mapToDTO helper method
        return mapToDTO(template);
    }
    /**
     * Helper method to map WorkflowTemplate to DTO
     */
    private WorkflowTemplateDTO mapToDTO(WorkflowTemplate template) {
        return new WorkflowTemplateDTO(
                template.getId(),
                template.getCreatedBy() != null ? template.getCreatedBy() : "Unknown", // Default value if null
                template.getCreatedAt(),  // Map the createdAt
                template.getVersion(),  // Map the version
                template.getWorkflowName() != null ? template.getWorkflowName() : "Default Name",  // Default value if null
                template.getWorkflowDescription() != null ? template.getWorkflowDescription() : "Default Description",
                template.getAnyone() != null ? template.getAnyone() : false,  // Ensure non-null value for 'anyone'
                template.getWho() != null ? template.getWho() : WhoCanUseEnum.specific_group,  // Default value if null
                template.getAnyFileType() != null ? template.getAnyFileType() : false,
                template.getFileType() != null ? template.getFileType() : null,  // Allow null
                template.getAnyFolderType() != null ? template.getAnyFolderType() : false,
                template.getFolderType() != null ? template.getFolderType() : null,  // Allow null
                template.getFolderTypeEnum() != null ? template.getFolderTypeEnum() : FolderTypeEnum.specific_folder,  // Default if null
                template.getFileTypeEnum() != null ? template.getFileTypeEnum() : FileTypeEnum.specific_file_types,  // Default if null
                template.getWorkflowStatusEnum() != null ? template.getWorkflowStatusEnum() : WorkflowStatusEnum.IN_PROGRESS, // Add workflowStatusEnum with a default value if null
                template.getCustomReminder() != null ? template.getCustomReminder() : false,
                template.getNoB4Reminder() != null ? template.getNoB4Reminder() : false,
                template.getNoAfterReminder() != null ? template.getNoAfterReminder() : false,
                template.getAllowOverride() != null ? template.getAllowOverride() : false,
                template.getReminderBeforeEveryDays() != null ? template.getReminderBeforeEveryDays() : 0,  // Default to 0 if null
                template.getReminderAfterEveryDays() != null ? template.getReminderAfterEveryDays() : 0,  // Default to 0 if null
                template.getGroupName() != null ? template.getGroupName() : UUID.randomUUID(),  // Generate UUID if null
                template.getSteps() != null ? template.getSteps().stream().map(this::mapStepToDTO).collect(Collectors.toList()) : Collections.emptyList(), // Handle null steps
                template.getGeneralSettings() != null ? template.getGeneralSettings().getId() : null // Allow null GeneralSettings

        );
    }


    /**
     * Helper method to map Steps to DTO
     */
    private StepsDTO mapStepToDTO(Steps step) {
        return new StepsDTO(
                step.getId(),
                step.getCreatedBy() != null ? step.getCreatedBy() : "Unknown",  // Handle null for 'createdBy'
                step.getStepType() != null ? step.getStepType().name() : "UNKNOWN",  // Default if null
                step.getStepName() != null ? step.getStepName() : "Default Step Name",  // Default step name
                step.getStepDescription() != null ? step.getStepDescription() : "Default Step Description",  // Default step description
                step.getAllowEditStep() != null ? step.getAllowEditStep() : false,  // Ensure non-null value
                step.getAllowEditDesc() != null ? step.getAllowEditDesc() : false,  // Ensure non-null value
                step.getGeneralSettings() != null ? step.getGeneralSettings().getId() : null,  // Allow null GeneralSettings
                step.getAssigneeId() != null ? step.getAssigneeId().stream().map(this::mapAssigneeToDTO).collect(Collectors.toList()) : Collections.emptyList()  // Handle null assignees
        );
    }

    /**
     * Helper method to map TasksAssignees to DTO
     */
    private TasksAssigneesDTO mapAssigneeToDTO(TasksAssignees assignee) {
        return new TasksAssigneesDTO(
                assignee.getId(),
                assignee.getCreatedBy() != null ? assignee.getCreatedBy() : "Unknown",  // Handle null for 'createdBy'
                assignee.getGrId() != null ? assignee.getGrId() : defaultUUID,  // Ensure non-null UUID
                assignee.getSpecUserId() != null ? assignee.getSpecUserId() : defaultUUID,  // Ensure non-null UUID
                assignee.getAnyone() != null ? assignee.getAnyone() : false,  // Ensure non-null value
                assignee.getAnyoneGr() != null ? assignee.getAnyoneGr() : false,  // Ensure non-null value
                assignee.getMinReq() != null ? assignee.getMinReq() : 1,  // Default to 1 if null
                assignee.getMinReqStep() != null ? assignee.getMinReqStep() : 1,  // Default to 1 if null
                assignee.getDays() != null ? assignee.getDays() : 0  // Default to 0 if null
        );
    }

    /**
     * Helper method to create Steps from DTO and associate it with Workflow Template
     */
    private Steps createStepFromDTO(StepsDTO stepsDTO, WorkflowTemplate workflowTemplate, String userId) {
        // Create a new Step
        Steps step = new Steps();
        step.setCreatedBy(userId);
        step.setStepType(StepTypeEnum.valueOf(stepsDTO.getStepType()));
        step.setStepName(stepsDTO.getStepName());
        step.setStepDescription(stepsDTO.getStepDescription());
        step.setAllowEditStep(stepsDTO.getAllowEditStep() != null ? stepsDTO.getAllowEditStep() : false);  // Handle null
        step.setAllowEditDesc(stepsDTO.getAllowEditDesc() != null ? stepsDTO.getAllowEditDesc() : false);  // Handle null
        step.setWorkflowTemplate(workflowTemplate);

        // Set GeneralSettings
        if (stepsDTO.getSettingsId() != null) {
            GeneralSettings generalSettings = generalSettingsRepository.findById(stepsDTO.getSettingsId())
                    .orElseThrow(() -> new ResourceNotFoundException("General Settings not found"));
            step.setGeneralSettings(generalSettings);
        } else if (workflowTemplate.getGeneralSettings() != null) {
            step.setGeneralSettings(workflowTemplate.getGeneralSettings());  // Use template settings if DTO settings are null
        }

        // Save the Step entity
        Steps savedStep = stepsRepository.save(step);

        // Now save the TasksAssignees associated with this step
        List<TasksAssignees> assigneesList = stepsDTO.getAssignees().stream()
                .map(assigneeDTO -> createAssigneeFromDTO(assigneeDTO, savedStep, userId))  // Pass the saved step
                .collect(Collectors.toList());

        // Save all TasksAssignees
        tasksAssigneesRepository.saveAll(assigneesList);  // Ensure assignees are saved in the repository

        return savedStep; // Return the saved step
    }

    /**
     * Helper method to create TasksAssignees from DTO and associate it with Step
     */
    private TasksAssignees createAssigneeFromDTO(TasksAssigneesDTO assigneeDTO, Steps step, String userId) {
        TasksAssignees assignee = new TasksAssignees();
        assignee.setCreatedBy(userId);
        assignee.setGrId(assigneeDTO.getGrId());
        assignee.setSpecUserId(assigneeDTO.getSpecUserId());
        assignee.setAnyone(assigneeDTO.getAnyone() != null ? assigneeDTO.getAnyone() : false);
        assignee.setAnyoneGr(assigneeDTO.getAnyoneGr() != null ? assigneeDTO.getAnyoneGr() : false);
        assignee.setMinReq(assigneeDTO.getMinReq());
        assignee.setMinReqStep(assigneeDTO.getMinReqStep());
        assignee.setDays(assigneeDTO.getDays());
        assignee.setStepId(step);  // Associate the saved step with the assignee

        return assignee;  // Return the created assignee object
    }

/**
 * Method to retrieve all workflow templates.
 */
public List<WorkflowTemplateDTO> getAllWorkflowTemplates() {
    List<WorkflowTemplate> templates = workflowTemplateRepository.findAll();
    return templates.stream()
            .map(this::mapToDTO)
            .collect(Collectors.toList());
}
    /**
     * Method to retrieve all workflow templates filtered by status.
     */
public List<WorkflowTemplateDTO> getAllWorkflowTemplatesByStatus(WorkflowStatusEnum status) {
        List<WorkflowTemplate> templates = workflowTemplateRepository.findAllByWorkflowStatusEnum(status);
        return templates.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}