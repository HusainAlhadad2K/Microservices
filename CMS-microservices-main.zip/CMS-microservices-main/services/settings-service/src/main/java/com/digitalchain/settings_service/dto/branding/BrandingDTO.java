package com.digitalchain.settings_service.dto.branding;

import com.digitalchain.settings_service.Enumerations.branding.AuthMethodEnum;
import com.digitalchain.settings_service.Enumerations.branding.SecureConnectEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BrandingDTO {

    private UUID id;
    private String createdBy;
    private Date createdAt;
    private String fileServerLabel;
    private String logo;
    private String headerColor;
    private String accessUrl;
    private String help;
    private Boolean loginDisclaimer;//if true,disclaimerText !=null else disclaimerText = null
    private String disclaimerText; //not null only if loginDisclaimer=true
    private String uploadDisclaimer;
    private Boolean termsService;//if true termsServiceText!= null else termsServiceText= null
    private String termsServiceText;//not null only if termsService=true
    private Boolean emailTemplates;//if true, {powerSubject and powerMsg} nut null or {standardSubject and standardMsg} not null ; else {powerSubject and powerMsg} and {standardSubject and standardMsg} are null
    private String powerSubject;
    private String powerMsg;
    private String standardSubject;
    private String standardMsg;
    private Boolean mailIntegration;//if false, authMethodEnum,userName,pass,clientId,clientSecret,tenant,mailAddress,mailPort,connSecurely,senderName,and senderEmail are all null; else they can be null and they might be not null
    private AuthMethodEnum authMethodEnum;//if authMethodEnum=basic, then userName and pass!=0 ; else,userName and pass=null and clientId,clientSecret and tenant !=null
    private String userName;
    private String pass;
    private String clientId;
    private String clientSecret;
    private String tenant;
    private String mailAddress;
    private Integer mailPort;
    private SecureConnectEnum connSecurely;
    private String senderName;
    private String senderEmail;

}
