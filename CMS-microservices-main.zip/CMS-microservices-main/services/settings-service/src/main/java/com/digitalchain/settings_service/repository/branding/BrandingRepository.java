package com.digitalchain.settings_service.repository.branding;

import com.digitalchain.settings_service.model.branding.Branding;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;

@Repository
public interface BrandingRepository extends JpaRepository<Branding, UUID> {

}
