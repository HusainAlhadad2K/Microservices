package com.digitalchain.settings_service.repository.workflow;


import com.digitalchain.settings_service.model.workflow.TasksAssignees;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface TasksAssigneesRepository extends JpaRepository<TasksAssignees, UUID> {
}
