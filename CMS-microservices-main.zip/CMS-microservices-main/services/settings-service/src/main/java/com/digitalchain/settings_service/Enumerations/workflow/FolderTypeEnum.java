package com.digitalchain.settings_service.Enumerations.workflow;

public enum FolderTypeEnum {
    any_folder,
    specific_folder
}
