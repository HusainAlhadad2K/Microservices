package com.digitalchain.settings_service.Enumerations.workflow;

public enum WhoCanUseEnum {
    anyone,
    specific_group
}
