package com.digitalchain.settings_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.digitalchain.settings_service.repository")

public class SettingsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SettingsServiceApplication.class, args);
	}

}
