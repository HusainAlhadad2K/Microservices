package com.digitalchain.settings_service.model.workflow;
import com.digitalchain.settings_service.Enumerations.workflow.FileTypeEnum;
import com.digitalchain.settings_service.Enumerations.workflow.FolderTypeEnum;
import com.digitalchain.settings_service.Enumerations.workflow.WhoCanUseEnum;
import com.digitalchain.settings_service.Enumerations.workflow.WorkflowStatusEnum;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.util.*;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "WorkflowTemplate")
public class WorkflowTemplate {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "created_by")
    private String createdBy;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date createdAt;

    @Column(name = "workflow_name")
    private String workflowName;

    @Column(name = "workflow_description")
    private String workflowDescription;

    @Column(name = "anyone_can_use")
    private Boolean anyone;

    @Column(name = "group_name")
    private UUID groupName;

    @Enumerated(EnumType.STRING)
    @Column(name = "who_can_use")
    private WhoCanUseEnum who;

    @Enumerated(EnumType.STRING)
    @Column(name = "file_type_enum")
    private FileTypeEnum fileTypeEnum;

    @Enumerated(EnumType.STRING)
    @Column(name = "workflow_status")
    private WorkflowStatusEnum workflowStatusEnum;

    @Enumerated(EnumType.STRING)
    @Column(name = "folder_type_enum")
    private FolderTypeEnum folderTypeEnum;

    @Column(name = "any_file_type")
    private Boolean anyFileType;

    @Column(name = "file_type")
    private String fileType;

    @Column(name = "any_folder_type")
    private Boolean anyFolderType;

    @Column(name = "folder_type")
    private String folderType;

    @Column(name = "template_version")
    private String version;

    @Column(name = "set_custom_reminder")
    private Boolean customReminder;

    @Column(name = "Nob4reminder")
    private Boolean NoB4Reminder;

    @Column(name = "NoAfterReminder")
    private Boolean NoAfterReminder;

    @Column(name = "allow_override")
    private Boolean allowOverride;

    private Integer reminderBeforeEveryDays;
    private Integer reminderAfterEveryDays;

    // Relationship with Steps (One WorkflowTemplate can have multiple steps)
    //@OneToMany(mappedBy = "workflowTemplate", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    @OneToMany(mappedBy = "workflowTemplate", fetch = FetchType.EAGER)
    private List<Steps> steps = new ArrayList<>();

    // Relationship with GeneralSettings (One WorkflowTemplate can have one GeneralSettings)
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "general_settings_id", referencedColumnName = "id")
    private GeneralSettings generalSettings;

}
