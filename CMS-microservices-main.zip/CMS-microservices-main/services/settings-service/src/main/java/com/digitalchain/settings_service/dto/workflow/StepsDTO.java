package com.digitalchain.settings_service.dto.workflow;



import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StepsDTO {

    private UUID id;
    private String createdBy;
    private String stepType;  // Enum representing the step type and each type is a string
    private String stepName;
    private String stepDescription;
    private Boolean allowEditStep;
    private Boolean allowEditDesc;

    @NotNull(message = "SettingsId cannot be null")
    private UUID settingsId;  // GeneralSettings ID as UUID
    private List<TasksAssigneesDTO> assignees;  // List of assignees for the step
}
