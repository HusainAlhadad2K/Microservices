package com.digitalchain.settings_service.repository.workflow;

import com.digitalchain.settings_service.model.workflow.Steps;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface StepsRepository extends JpaRepository<Steps, UUID> {
    List<Steps> findByWorkflowTemplate_Id(UUID workflowId);
}
