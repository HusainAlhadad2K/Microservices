package com.digitalchain.settings_service.routes.workflow;

import com.digitalchain.settings_service.Enumerations.workflow.WorkflowStatusEnum;
import com.digitalchain.settings_service.config.BaseRouteBuilder;
import com.digitalchain.settings_service.dto.UserDTO;

import com.digitalchain.settings_service.dto.workflow.WorkflowTemplateDTO;
import com.digitalchain.settings_service.exception.ResourceNotFoundException;
import com.digitalchain.settings_service.model.workflow.WorkflowTemplate;
import com.digitalchain.settings_service.service.workflow.WorkflowTemplateService;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestParamType;
import org.apache.xmlbeans.impl.xb.xsdschema.ListDocument;
import org.springframework.stereotype.Component;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.UUID;

@Component
public class WorkflowTemplateRoute extends BaseRouteBuilder {

    @Autowired
    private WorkflowTemplateService workflowTemplateService;

    @Override
    public void configure() throws Exception {
        super.configure();

        rest("/settings")
                // POST request to create a new workflow template
                .post("/workflow-templates")
                .type(WorkflowTemplateDTO.class)
                .description("Creates a new workflow template")
                .responseMessage().code(200).message("Workflow Template created successfully").endResponseMessage()
                .to("direct:createWorkflowTemplate")

                // GET request to get a workflow template by ID
                .get("/workflow-templates/{id}")
                .description("Gets workflow template by ID")
                .param().name("id").type(RestParamType.path).dataType("UUID").required(true).description("Workflow Template ID").endParam()
                .responseMessage().code(200).message("Workflow Template retrieved successfully").endResponseMessage()
                .to("direct:getWorkflowTemplate")

                // GET request to get all workflow templates
                .get("/workflow-templates")
                .description("Gets all workflow templates")
                .responseMessage().code(200).message("Workflow Templates retrieved successfully").endResponseMessage()
                .to("direct:getAllWorkflowTemplates")

                // PUT request to update an existing workflow template by ID
                .put("/workflow-templates/{id}")
                .type(WorkflowTemplateDTO.class)
                .description("Updates an existing workflow template")
                .param().name("id").type(RestParamType.path).dataType("UUID").required(true).description("Workflow Template ID").endParam()
                .responseMessage().code(200).message("Workflow Template updated successfully").endResponseMessage()
                .to("direct:updateWorkflowTemplate")

                // GET request to get workflow templates filtered by status
                .get("/workflow-templates/status/{status}")
                .description("Gets workflow templates filtered by status")
                .param().name("status").type(RestParamType.path).dataType("string").required(true).description("Workflow Template Status").endParam()
                .responseMessage().code(200).message("Workflow Templates retrieved successfully").endResponseMessage()
                .to("direct:getWorkflowTemplatesByStatus");

        // Route for creating a workflow template
        from("direct:createWorkflowTemplate")
                .routeId("createWorkflowTemplate")
                .process(exchange -> {
                    WorkflowTemplateDTO workflowTemplateDTO = exchange.getIn().getBody(WorkflowTemplateDTO.class);
                    UserDTO user = exchange.getProperty("user", UserDTO.class); // Assuming user information is stored in exchange properties

                    // Call the service to create the workflow template
                    WorkflowTemplate createdWorkflowTemplate = workflowTemplateService.createWorkflowTemplate(workflowTemplateDTO, user.getUser_id());

                    // Return the created workflow template as a response
                    exchange.getIn().setBody(createdWorkflowTemplate);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .log("Workflow template created successfully with ID: ${body.id}")
                .onException(Exception.class)
                .handled(true)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(500))
                .setBody(simple("Error occurred while creating workflow template: ${exception.message}"));

        // Route for getting a workflow template by ID
        from("direct:getWorkflowTemplate")
                .routeId("getWorkflowTemplate")
                .process(exchange -> {
                    UUID id = exchange.getIn().getHeader("id", UUID.class);
                    WorkflowTemplateDTO workflowTemplateDTO = workflowTemplateService.getWorkflowTemplate(id);
                    exchange.getIn().setBody(workflowTemplateDTO);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .log("Workflow template retrieved successfully with ID: ${body.id}")
                .onException(ResourceNotFoundException.class)
                .handled(true)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(404))
                .setBody(simple("Workflow template not found with ID: ${header.id}"));

        // Route for getting all workflow templates
        from("direct:getAllWorkflowTemplates")
                .routeId("getAllWorkflowTemplates")
                .process(exchange -> {
                    // Call the service to retrieve all workflow templates
                    List<WorkflowTemplateDTO> templates = workflowTemplateService.getAllWorkflowTemplates();
                    exchange.getIn().setBody(templates);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .log("All workflow templates retrieved successfully.")
                .onException(Exception.class)
                .handled(true)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(500))
                .setBody(simple("Error occurred while retrieving workflow templates: ${exception.message}"));

        // Route for updating a workflow template
        from("direct:updateWorkflowTemplate")
                .routeId("updateWorkflowTemplate")
                .process(exchange -> {
                    UUID id = exchange.getIn().getHeader("id", UUID.class);
                    WorkflowTemplateDTO workflowTemplateDTO = exchange.getIn().getBody(WorkflowTemplateDTO.class);
                    String updateMessage = workflowTemplateService.updateWorkflowTemplate(workflowTemplateDTO, id);
                    exchange.getIn().setBody(updateMessage);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .log("Workflow template updated successfully with ID: ${body}")
                .onException(Exception.class)
                .handled(true)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(500))
                .setBody(simple("Error occurred while updating workflow template: ${exception.message}"));

        // Route for getting workflow templates by status
        from("direct:getWorkflowTemplatesByStatus")
                .routeId("getWorkflowTemplatesByStatus")
                .process(exchange -> {
                    String statusParam = exchange.getIn().getHeader("status", String.class);
                    WorkflowStatusEnum status = WorkflowStatusEnum.valueOf(statusParam.toUpperCase());

                    // Call the service to retrieve workflow templates by status
                    List<WorkflowTemplateDTO> templates = workflowTemplateService.getAllWorkflowTemplatesByStatus(status);
                    exchange.getIn().setBody(templates);
                })
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .log("Workflow templates filtered by status retrieved successfully.")
                .onException(Exception.class)
                .handled(true)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(500))
                .setBody(simple("Error occurred while retrieving workflow templates by status: ${exception.message}"));
    }

}
