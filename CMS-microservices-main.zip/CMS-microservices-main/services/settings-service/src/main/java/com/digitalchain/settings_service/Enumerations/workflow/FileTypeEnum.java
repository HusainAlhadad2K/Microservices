package com.digitalchain.settings_service.Enumerations.workflow;

public enum FileTypeEnum {
    any_file_type,
    specific_file_types
}
