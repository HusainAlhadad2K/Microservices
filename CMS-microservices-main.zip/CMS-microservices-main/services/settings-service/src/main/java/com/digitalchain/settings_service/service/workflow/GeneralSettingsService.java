package com.digitalchain.settings_service.service.workflow;

import com.digitalchain.settings_service.dto.workflow.GeneralSettingsDTO;
import com.digitalchain.settings_service.exception.ResourceNotFoundException;
import com.digitalchain.settings_service.model.workflow.GeneralSettings;
import com.digitalchain.settings_service.repository.workflow.GeneralSettingsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class GeneralSettingsService {
    @Autowired
    private GeneralSettingsRepository generalSettingsRepository;

    // Method to create a new GeneralSettings entry
    public GeneralSettings createGeneralSettings(GeneralSettingsDTO settingsDTO, String userId) {
        GeneralSettings settings = new GeneralSettings();
        settings.setCreatedBy(userId);
        settings.setReminderB4Due(settingsDTO.getReminderBeforeDueDate());
        settings.setReminderAfterDue(settingsDTO.getReminderAfterDueDate());
        //settings.setReminderBeforeEveryDays(settingsDTO.getReminderBeforeEveryDays());
       // settings.setReminderAfterEveryDays(settingsDTO.getReminderAfterEveryDays());

        // Validation and setting logic for reminderBeforeEveryDays
        if (Boolean.FALSE.equals(settingsDTO.getReminderBeforeDueDate())) {
            settings.setReminderBeforeEveryDays(0); // Set to 0 if reminderB4Due is false
        } else if (Boolean.TRUE.equals(settingsDTO.getReminderBeforeDueDate())) {
            if (settingsDTO.getReminderBeforeEveryDays() == null || settingsDTO.getReminderBeforeEveryDays() == 0) {
                throw new IllegalArgumentException("Please Enter Number of days greater than 0");
            }
            settings.setReminderBeforeEveryDays(settingsDTO.getReminderBeforeEveryDays());
        }

        // Validation and setting logic for reminderAfterEveryDays
        if (Boolean.FALSE.equals(settingsDTO.getReminderAfterDueDate())) {
            settings.setReminderAfterEveryDays(0); // Set to 0 if reminderAfterDue is false
        } else if (Boolean.TRUE.equals(settingsDTO.getReminderAfterDueDate())) {
            if (settingsDTO.getReminderAfterEveryDays() == null || settingsDTO.getReminderAfterEveryDays() == 0) {
                throw new IllegalArgumentException("Please Enter Number of days greater than 0");
            }
            settings.setReminderAfterEveryDays(settingsDTO.getReminderAfterEveryDays());
        }


        // Save to repository
        return generalSettingsRepository.save(settings);
    }

    // Method to fetch a GeneralSettings entry by ID
    public GeneralSettingsDTO getGeneralSettings(UUID id) {


        GeneralSettings settings = generalSettingsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Settings not found"));


        // Map GeneralSettings to DTO
        return mapToDTO(settings);
    }

    // Helper method to convert GeneralSettings to DTO
    private GeneralSettingsDTO mapToDTO(GeneralSettings settings) {
        return new GeneralSettingsDTO(
                settings.getCreatedBy(),
                settings.getReminderB4Due(),
                settings.getReminderAfterDue(),
                settings.getReminderBeforeEveryDays(),
                settings.getReminderAfterEveryDays(),
                settings.getCreatedAt()
        );
    }
}
