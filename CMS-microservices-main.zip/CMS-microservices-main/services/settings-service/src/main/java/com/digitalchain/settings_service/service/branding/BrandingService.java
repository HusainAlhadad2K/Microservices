package com.digitalchain.settings_service.service.branding;

import com.digitalchain.settings_service.Enumerations.branding.AuthMethodEnum;
import com.digitalchain.settings_service.dto.branding.BrandingDTO;
import com.digitalchain.settings_service.exception.ResourceNotFoundException;
import com.digitalchain.settings_service.model.branding.Branding;
import com.digitalchain.settings_service.repository.branding.BrandingRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class BrandingService {
    @Autowired
    private BrandingRepository brandingRepository;

    /**
     * Method to create a new Branding record
     */
    @Transactional
    public Branding createBranding(BrandingDTO brandingDTO, String userId) {
        Branding branding = new Branding();
        branding.setCreatedBy(userId);
        branding.setFileServerLabel(brandingDTO.getFileServerLabel());
        branding.setLogo(brandingDTO.getLogo());
        branding.setHeaderColor(brandingDTO.getHeaderColor());
        branding.setAccessUrl(brandingDTO.getAccessUrl());
        branding.setHelp(brandingDTO.getHelp());

        // Handling login disclaimer logic
        if (brandingDTO.getLoginDisclaimer() != null && brandingDTO.getLoginDisclaimer()) {
            branding.setLoginDisclaimer(true);
            branding.setDisclaimerText(brandingDTO.getDisclaimerText());
        } else {
            branding.setLoginDisclaimer(false);
            branding.setDisclaimerText(null);
        }

        // Handling terms of service logic
        if (brandingDTO.getTermsService() != null && brandingDTO.getTermsService()) {
            branding.setTermsService(true);
            branding.setTermsServiceText(brandingDTO.getTermsServiceText());
        } else {
            branding.setTermsService(false);
            branding.setTermsServiceText(null);
        }

        // Handling email template logic
        if (brandingDTO.getEmailTemplates() != null && brandingDTO.getEmailTemplates()) {
            branding.setEmailTemplates(true);
            if (brandingDTO.getPowerSubject() != null && brandingDTO.getPowerMsg() != null) {
                branding.setPowerSubject(brandingDTO.getPowerSubject());
                branding.setPowerMsg(brandingDTO.getPowerMsg());
            } else if (brandingDTO.getStandardSubject() != null && brandingDTO.getStandardMsg() != null) {
                branding.setStandardSubject(brandingDTO.getStandardSubject());
                branding.setStandardMsg(brandingDTO.getStandardMsg());
            }
        } else {
            branding.setEmailTemplates(false);
            branding.setPowerSubject(null);
            branding.setPowerMsg(null);
            branding.setStandardSubject(null);
            branding.setStandardMsg(null);
        }

        // Handle mail integration-related fields
        if (Boolean.TRUE.equals(brandingDTO.getMailIntegration())) {
            branding.setAuthMethodEnum(brandingDTO.getAuthMethodEnum());
            if (brandingDTO.getAuthMethodEnum() == AuthMethodEnum.BASIC) {
                branding.setUserName(brandingDTO.getUserName());
                branding.setPass(brandingDTO.getPass());
                branding.setClientId(null);
                branding.setClientSecret(null);
                branding.setTenant(null);
            } else {
                branding.setUserName(null);
                branding.setPass(null);
                branding.setClientId(brandingDTO.getClientId());
                branding.setClientSecret(brandingDTO.getClientSecret());
                branding.setTenant(brandingDTO.getTenant());
            }
            branding.setMailAddress(brandingDTO.getMailAddress());
            branding.setMailPort(brandingDTO.getMailPort());
            branding.setConnSecurely(brandingDTO.getConnSecurely());
            branding.setSenderName(brandingDTO.getSenderName());
            branding.setSenderEmail(brandingDTO.getSenderEmail());
        } else {
            branding.setAuthMethodEnum(null);
            branding.setUserName(null);
            branding.setPass(null);
            branding.setClientId(null);
            branding.setClientSecret(null);
            branding.setTenant(null);
            branding.setMailAddress(null);
            branding.setMailPort(null);
            branding.setConnSecurely(null);
            branding.setSenderName(null);
            branding.setSenderEmail(null);
        }

        // Save Branding record
        return brandingRepository.save(branding);
    }

    /**
     * Method to retrieve a Branding record by ID
     */
    public BrandingDTO getBrandingById(UUID id) {
        Branding branding = brandingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Branding not found with ID: " + id));
        return mapToDTO(branding);
    }

    /**
     * Helper method to map Branding entity to DTO.
     */
    private BrandingDTO mapToDTO(Branding branding) {
        BrandingDTO brandingDTO = new BrandingDTO();
        brandingDTO.setCreatedBy(branding.getCreatedBy());
        brandingDTO.setCreatedAt(branding.getCreatedAt());
        brandingDTO.setFileServerLabel(branding.getFileServerLabel());
        brandingDTO.setLogo(branding.getLogo());
        brandingDTO.setHeaderColor(branding.getHeaderColor());
        brandingDTO.setAccessUrl(branding.getAccessUrl());
        brandingDTO.setHelp(branding.getHelp());
        brandingDTO.setLoginDisclaimer(branding.getLoginDisclaimer());
        brandingDTO.setDisclaimerText(branding.getDisclaimerText());
        brandingDTO.setUploadDisclaimer(branding.getUploadDisclaimer());
        brandingDTO.setTermsService(branding.getTermsService());
        brandingDTO.setTermsServiceText(branding.getTermsServiceText());
        brandingDTO.setEmailTemplates(branding.getEmailTemplates());
        brandingDTO.setPowerSubject(branding.getPowerSubject());
        brandingDTO.setPowerMsg(branding.getPowerMsg());
        brandingDTO.setStandardSubject(branding.getStandardSubject());
        brandingDTO.setStandardMsg(branding.getStandardMsg());
        brandingDTO.setMailIntegration(branding.getMailIntegration());
        brandingDTO.setAuthMethodEnum(branding.getAuthMethodEnum());
        brandingDTO.setUserName(branding.getUserName());
        brandingDTO.setPass(branding.getPass());
        brandingDTO.setClientId(branding.getClientId());
        brandingDTO.setClientSecret(branding.getClientSecret());
        brandingDTO.setTenant(branding.getTenant());
        brandingDTO.setMailAddress(branding.getMailAddress());
        brandingDTO.setMailPort(branding.getMailPort());
        brandingDTO.setConnSecurely(branding.getConnSecurely());
        brandingDTO.setSenderName(branding.getSenderName());
        brandingDTO.setSenderEmail(branding.getSenderEmail());

        return brandingDTO;
    }
    }
