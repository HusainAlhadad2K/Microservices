package com.digitalchain.settings_service.model.workflow;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import java.util.Date;
import java.util.UUID;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "TasksAssignees")
public class TasksAssignees {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "created_by")
    private String createdBy;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date createdAt;

    @Column(name = "gr_id")
    private UUID grId;

    @Column(name = "spec_user_gr_id")
    private UUID specUserId;

    @Column(name = "any_one")
    private Boolean anyone;

    @Column(name = "any_one_ingroup")
    private Boolean anyoneGr;

    @Column(name = "min_required")
    private Integer minReq;

    @Column(name = "min_required_step")
    private Integer minReqStep;

    @Column(name = "deadline_days")
    private Integer days;

    // Relationship with Steps (Many assignees can belong to one step)
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "step_id", referencedColumnName = "id")
    private Steps stepId;
}
