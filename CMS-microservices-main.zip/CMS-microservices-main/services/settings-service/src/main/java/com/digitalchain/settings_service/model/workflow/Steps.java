package com.digitalchain.settings_service.model.workflow;
import com.digitalchain.settings_service.Enumerations.workflow.StepTypeEnum;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "Steps")
public class Steps {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "created_by")
    private String createdBy;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date createdAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "step_type")
    private StepTypeEnum stepType;

    @Column(name = "step_name")
    private String stepName;

    @Column(name = "step_description")
    private String stepDescription;

    @Column(name = "allow_edit_step")
    private Boolean allowEditStep;

    @Column(name = "allow_edit_description")
    private Boolean allowEditDesc;

    // Relationship with WorkflowTemplate (Many steps can belong to one workflow)
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "workflow_template_id", nullable = false)
    private WorkflowTemplate workflowTemplate;

    // Relationship with GeneralSettings for step-specific settings
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "general_settings_id", referencedColumnName = "id",nullable = true)
    private GeneralSettings generalSettings;

    // Relationship with TaskAssignees (One Step can have multiple assignees)
    @OneToMany(mappedBy = "stepId", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private List<TasksAssignees> assigneeId = new ArrayList<>();
}
