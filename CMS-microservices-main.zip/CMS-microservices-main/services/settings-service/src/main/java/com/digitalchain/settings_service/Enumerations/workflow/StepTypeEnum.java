package com.digitalchain.settings_service.Enumerations.workflow;

public enum StepTypeEnum {
    TO_DO,
    REVIEW,
    APPROVAL;
}
