package com.digitalchain.issues_service.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnalysisRuleDetailsDTO {

    private String ruleName; // Name of the rule, same as the enum name
    private String description;
    private int openIssues;
    private int dismissedIssues;
    private int totalIssues;
    private Date lastIssueUpdate;
}
