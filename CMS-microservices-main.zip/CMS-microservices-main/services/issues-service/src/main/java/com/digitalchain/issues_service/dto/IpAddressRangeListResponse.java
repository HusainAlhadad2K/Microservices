package com.digitalchain.issues_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IpAddressRangeListResponse {
    private List<IpAddressRangeResponse> ranges; // List of all IP ranges
}

