package com.digitalchain.issues_service.Entity;

import com.digitalchain.issues_service.repository.IssueRepository;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import com.digitalchain.common.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;


@Data
@NoArgsConstructor
@Entity
@Table(name = "issues")
public class Issue {

    @Id
    @GeneratedValue
    @Column(name = "issue_id", updatable = false, nullable = false)
    private UUID issueId;

//    @Column(name = "issue_number")
//    private Integer issueNumber;

//    @Column(name = "title")
//    private String title;

//    @Column(name = "description")
//    private String description;

    @Column(name = "status")
    private String status;

    @Column(name = "assigned_to")
    private UUID assignedTo; // UUID for the user who is assigned to the issue

//    @Column(name = "severity", nullable = false)
//    private Integer severity;

    @Column(name = "source_name")
    private String sourceName;

    @Column(name = "affected_user")
    private UUID affectedUser; // UUID for the user affected by the issue

    @Column(name = "detected_by_rule")
    private String detectedByRule;

    @Column(name = "affected_folder")
    private UUID affectedFolder;

    @Column(name = "affected_file")
    private UUID affectedFile;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Date updatedAt;

//    @OneToMany(mappedBy = "issue", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<ActivityLog> activityLogs;

    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes;

    @Column(name = "comments", columnDefinition = "TEXT")
    private String comments;

}
