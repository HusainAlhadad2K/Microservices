package com.digitalchain.issues_service.Entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.util.Date;
import java.util.UUID;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@Entity
@Table(name = "ip_whitelist")
public class IpWhitelistEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "whitelist_id", nullable = false)
    private UUID whitelistId;

    @Column(name = "ip_from")
    private String ipFrom;

    @Column(name = "ip_to")
    private String ipTo;

    @Column(name = "cidr")
    private String cidr;

    @Column(name = "comment")
    private String comment;

    @Column(name = "reason")
    private String reason;

}

