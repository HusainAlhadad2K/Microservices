package com.digitalchain.issues_service.service;

import com.digitalchain.issues_service.Entity.UserException;
import com.digitalchain.issues_service.dto.UserExceptionDTO;
import com.digitalchain.issues_service.dto.UserExceptionResponseDTO;
import com.digitalchain.issues_service.dto.UserUpdatedEvent;
import com.digitalchain.issues_service.repository.UserExceptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import jakarta.persistence.EntityNotFoundException;

@Service
public class UserExceptionService {

    @Autowired
    private UserExceptionRepository userExceptionRepository;

    public void addUserException(UserExceptionDTO userExceptionDTO) {
        // Create a new UserException entity
        UserException entity = new UserException();
        entity.setUserId(userExceptionDTO.getUserId());
        entity.setName(userExceptionDTO.getName());
        entity.setEmail(userExceptionDTO.getEmail());
        entity.setComments(userExceptionDTO.getComments());

        // Save the new entity to the repository
        userExceptionRepository.save(entity);
    }

    public void deleteUserException(UUID userId) {
        if (userExceptionRepository.existsById(userId)) {
            userExceptionRepository.deleteById(userId);
        } else {
            throw new EntityNotFoundException("User exception not found for the given ID.");
        }
    }
    public UserExceptionResponseDTO getUserExceptions() {
        List<UserExceptionDTO> exceptions = userExceptionRepository.findAllUserExceptions();
        return new UserExceptionResponseDTO(exceptions);
    }


    public void updateUser(UserUpdatedEvent event) {
        Optional<UserException> optionalUserException = userExceptionRepository.findById(event.getUserId());

        if (optionalUserException.isPresent()) {
            UserException userException = optionalUserException.get();
            userException.setName(event.getName());
            userException.setEmail(event.getEmail());
            userExceptionRepository.save(userException); // Save the updated entity
        }
    }

}
