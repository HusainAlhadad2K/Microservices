package com.digitalchain.issues_service.repository;

import com.digitalchain.issues_service.Entity.Issue;
import com.digitalchain.issues_service.dto.FilterOptionDTO;
import com.digitalchain.issues_service.dto.GetIssueDTO;
import com.digitalchain.issues_service.dto.IssueSummaryDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface IssueRepository extends JpaRepository<Issue, UUID> {

    @Query("SELECT new com.digitalchain.issues_service.dto.GetIssueDTO(" +
            "i.issueId, " +
            "i.status, " +
            "i.assignedTo, " +
            "i.affectedUser, " +
            "i.detectedByRule, " +
            "i.affectedFolder, " +
            "i.affectedFile, " +
            "i.createdAt, " +
            "i.updatedAt, " +
            "i.sourceName, " +
            "i.notes, " +
            "i.comments) " +
            "FROM Issue i")
    List<GetIssueDTO> findAllIssues();

    // Fetch summary information for all issues with pagination, filtering, and sorting
    @Query("SELECT new com.digitalchain.issues_service.dto.IssueSummaryDTO(" +
            "i.issueId, i.detectedByRule, i.updatedAt, i.sourceName) " +
            "FROM Issue i " +
            "WHERE (:status IS NULL OR i.status = :status) " +
            "AND (:rule IS NULL OR i.detectedByRule = :rule) " +
            "AND (:source IS NULL OR i.sourceName = :source)")
    Page<IssueSummaryDTO> findAllIssueSummaries(
            @Param("status") String status,
            @Param("rule") String rule,
            @Param("source") String source,
            Pageable pageable);

    @Query("SELECT new com.digitalchain.issues_service.dto.GetIssueDTO(" +
            "i.issueId, " +
            "i.status, " +
            "i.assignedTo, " +
            "i.affectedUser, " +
            "i.detectedByRule, " +
            "i.affectedFolder, " +
            "i.affectedFile, " +
            "i.createdAt, " +
            "i.updatedAt, " +
            "i.sourceName, " +
            "i.notes, " +
            "i.comments) " +
            "FROM Issue i WHERE i.issueId = ?1")
    Optional<GetIssueDTO> findIssueById(UUID issueId);

    // Query to count occurrences of each rule
    @Query("SELECT new com.digitalchain.issues_service.dto.FilterOptionDTO(i.detectedByRule, COUNT(i)) " +
            "FROM Issue i GROUP BY i.detectedByRule")
    List<FilterOptionDTO> countIssuesByRule();
}