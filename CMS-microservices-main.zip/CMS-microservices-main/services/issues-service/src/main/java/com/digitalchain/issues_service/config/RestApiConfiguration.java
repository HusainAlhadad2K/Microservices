package com.digitalchain.issues_service.config;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.stereotype.Component;

@Component
public class RestApiConfiguration extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        restConfiguration()
                .component("servlet")
                .bindingMode(RestBindingMode.json)
                .dataFormatProperty("prettyPrint", "true")
                .contextPath("/api")  // Base path for all your REST services
                .apiContextPath("/issues/doc")  // Swagger UI path
                .apiProperty("api.title", "Issues")
                .apiProperty("api.version", "1.0")
                .apiProperty("api.description", "Operations related to issues in the CMS")
                .apiProperty("host", "localhost:8222")
                .apiProperty("schemes", "http,https")
                .apiProperty("base.path", "localhost:8222/api/")
                .apiProperty("cors", "true");  // Enable CORS support
        restConfiguration()
                .enableCORS(true)  // Globally enable CORS
                .corsHeaderProperty("Access-Control-Allow-Origin", "*")  // Allow all origins
                .corsHeaderProperty("Access-Control-Allow-Methods", "*")
                .corsHeaderProperty("Access-Control-Allow-Headers", "*")
                .corsHeaderProperty("Access-Control-Allow-Credentials", "true");
    }
}