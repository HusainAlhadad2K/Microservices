package com.digitalchain.issues_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IssueSummaryDTO {
    private UUID issueId;
    private String detectedByRule;
    private Date updatedAt;
    private String sourceName;
}
