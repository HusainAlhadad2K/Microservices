package com.digitalchain.issues_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IssuesService {
	public static void main(String[] args) {
		SpringApplication.run(IssuesService.class, args);
	}
}
