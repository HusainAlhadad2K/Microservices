package com.digitalchain.issues_service.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@Entity
@Table(name = "activity_logs")
public class ActivityLog {

    @Id
    @GeneratedValue
    @Column(name = "log_id")
    private UUID logId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "issue_id")
    private Issue issue;

    @Column(name = "log_message")
    private String logMessage;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Date createdAt;
}
