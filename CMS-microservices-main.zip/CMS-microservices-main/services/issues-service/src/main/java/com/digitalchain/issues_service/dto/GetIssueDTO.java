package com.digitalchain.issues_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.UUID;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class GetIssueDTO {

    private UUID issueId;
//    private Integer issueNumber;
//    private String title;
//    private String description;
//    private Integer severity;
    private String status;
    private UUID assignedTo;
    private UUID affectedUser;
    private String detectedByRule;
    private UUID affectedFolder;
    private UUID affectedFile;
    private Date createdAt;
    private Date updatedAt;
    private String sourceName;
    private String notes;
    private String comments;
}
