package com.digitalchain.issues_service.Entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;

import java.util.Date;

@Data
@NoArgsConstructor
@Entity
@Table(name = "analysis_rule_details")
public class AnalysisRuleDetails {

    @Id
    @Column(name = "rule_name", nullable = false)
    private String ruleName; // Use the name of the enum as the primary key

    @Column(name = "description", nullable = false)
    private String description;

    @Column(name = "open_issues", nullable = false)
    private int openIssues;

    @Column(name = "dismissed_issues", nullable = false)
    private int dismissedIssues;

    @Column(name = "total_issues", nullable = false)
    private int totalIssues;

    @Column(name = "last_issue_update")
    private Date lastIssueUpdate;


}
