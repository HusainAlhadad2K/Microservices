package com.digitalchain.issues_service.service;

import com.digitalchain.issues_service.Entity.AnalysisRule;
import com.digitalchain.issues_service.Entity.AnalysisRuleDetails;
import com.digitalchain.issues_service.Entity.Issue;
import com.digitalchain.issues_service.dto.*;
import com.digitalchain.issues_service.exception.ResourceNotFoundException;
import com.digitalchain.issues_service.repository.AnalysisRuleDetailsRepository;
import com.digitalchain.issues_service.repository.IssueRepository;
import com.digitalchain.issues_service.utils.IssueRemediation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class IssueService {

    @Autowired
    private IssueRepository issueRepository;

    @Autowired
    private IssueRemediation issueRemediation;

    @Autowired
    private AnalysisRuleDetailsRepository analysisRuleDetailsRepository;
    // New saveIssue method

    public List<GetIssueDTO> getAllIssues() {
        return issueRepository.findAllIssues();
    }
    // Method to get a paginated, filtered, and sorted list of issue summaries
    public Page<IssueSummaryDTO> getAllIssueSummaries(String status, String rule, String source, int page, int size, String sortBy, String sortOrder) {
        Sort sort = Sort.by(Sort.Direction.fromString(sortOrder), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);
        return issueRepository.findAllIssueSummaries(status, rule, source, pageable);
    }
    public GetIssueDTO getIssueById(UUID issueId) {
        // Fetch the Issue entity from the repository
        return issueRepository.findIssueById(issueId)
                .orElseThrow(() -> new ResourceNotFoundException("Issue with ID " + issueId + " not found"));

        // Convert the Issue entity to IssueDTO before returning it

    }

    public void saveIssue(PostIssueDTO issueDTO) {
        issueDTO.setStatus("Open");
        Issue issue = convertToEntity(issueDTO);
        issueRepository.save(issue);

        // Validate and find matching AnalysisRule for the detectedByRule field
        if (issueDTO.getDetectedByRule() != null) {
            String ruleName = issueDTO.getDetectedByRule();
            AnalysisRule rule = null;

            // Find the matching rule in the AnalysisRule enum
            for (AnalysisRule r : AnalysisRule.values()) {
                if (r.getName().equalsIgnoreCase(ruleName)) {
                    rule = r;
                    break;
                }
            }

            // Throw exception if the rule name does not match any AnalysisRule
            if (rule == null) {
                throw new IllegalArgumentException("Invalid rule name: " + ruleName);
            }
            // Retrieve or create AnalysisRuleDetails for the matched rule
            Optional<AnalysisRuleDetails> analysisRuleDetailsOptional = analysisRuleDetailsRepository.findById(rule.getName());
            AnalysisRuleDetails analysisRuleDetails = analysisRuleDetailsOptional.get();

            // Update the issue counts based on the status of the issue
            analysisRuleDetails.setTotalIssues(analysisRuleDetails.getTotalIssues() + 1);
            analysisRuleDetails.setOpenIssues(analysisRuleDetails.getOpenIssues() + 1);

            // Update lastIssueUpdate to the current time
            analysisRuleDetails.setLastIssueUpdate(new Date());

            // Save the updated AnalysisRuleDetails entity
            analysisRuleDetailsRepository.save(analysisRuleDetails);
        }
    }
    public IssueFilterResponseDTO getFilterOptions() {
        // Static values for statuses, sources, and severities
        List<String> statuses = Arrays.asList("Open", "Dismissed", "Resolved");

        // Default rules with zero count based on the enum
        Map<String, FilterOptionDTO> defaultRules = Arrays.stream(AnalysisRule.values())
                .collect(Collectors.toMap(
                        AnalysisRule::getName,
                        rule -> new FilterOptionDTO(rule.getName(), 0)
                ));

        // Query the database to get counts for existing rules
        List<FilterOptionDTO> ruleCountsFromDb = issueRepository.countIssuesByRule();

        // Update default rule counts with actual counts from the database
        for (FilterOptionDTO rule : ruleCountsFromDb) {
            defaultRules.put(rule.getName(), rule);
        }

        // Convert map values to a list
        List<FilterOptionDTO> rules = defaultRules.values().stream().collect(Collectors.toList());

        // Populate the response DTO
        IssueFilterResponseDTO response = new IssueFilterResponseDTO();
        response.setStatuses(statuses);
        response.setRules(rules);

        return response;
    }
    public void remediateIssue(UUID issueId, IssueRemediation.RemediationAction action) {
        Issue issue = issueRepository.findById(issueId)
                .orElseThrow(() -> new ResourceNotFoundException("Issue with ID " + issueId + " not found"));

        issueRemediation.remediate(issue, action);

        // Save the updated issue status
        issueRepository.save(issue);
    }

    public void assignIssue(UUID issueId, AssignIssueDTO assignIssueDTO) {
        Issue issue = issueRepository.findById(issueId)
                .orElseThrow(() -> new ResourceNotFoundException("Issue with ID " + issueId + " not found"));

        // Assign the issue to the user and update the notes
        issue.setAssignedTo(UUID.fromString(assignIssueDTO.getUserId()));
        issue.setNotes(assignIssueDTO.getNotes());
        issueRepository.save(issue);
    }


    private Issue convertToEntity(PostIssueDTO issueDTO) {
        Issue issue = new Issue();
//        issue.setIssueNumber(issueDTO.getIssueNumber());
//        issue.setTitle(issueDTO.getTitle());
//        issue.setDescription(issueDTO.getDescription());
        issue.setStatus(issueDTO.getStatus());
        if (issueDTO.getAssignedTo() != null) {
            issue.setAssignedTo(issueDTO.getAssignedTo());
        }
//        issue.setSeverity(issueDTO.getSeverity());
        issue.setSourceName(issueDTO.getSourceName());
        if (issueDTO.getAffectedUser() != null) {
            issue.setAffectedUser(issueDTO.getAffectedUser());
        }
        issue.setDetectedByRule(issueDTO.getDetectedByRule());
        issue.setAffectedFolder(issueDTO.getAffectedFolder());
        issue.setAffectedFile(issueDTO.getAffectedFile());
        issue.setNotes(issueDTO.getNotes());
        issue.setComments(issueDTO.getComments());
        return issue;
    }

}
