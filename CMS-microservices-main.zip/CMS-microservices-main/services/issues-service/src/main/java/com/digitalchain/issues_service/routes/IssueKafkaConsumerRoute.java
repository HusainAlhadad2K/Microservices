package com.digitalchain.issues_service.routes;

import com.digitalchain.issues_service.dto.GetIssueDTO;
import com.digitalchain.issues_service.dto.PostIssueDTO;
import com.digitalchain.issues_service.service.IssueService;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class IssueKafkaConsumerRoute extends RouteBuilder {

    @Autowired
    IssueService issueService;

    @Override
    public void configure() throws Exception {
        // Kafka Consumer route for issues
        from("kafka:{{issue.topic}}?brokers={{camel.component.kafka.brokers}}")
                .routeId("kafkaIssueActivityLoggingRoute")
                .log("Received issue from Kafka: ${body}")
                .unmarshal().json(GetIssueDTO.class)  // Deserialize JSON to Issue
                .process(exchange -> {
                    // Extract the Issue object from the Kafka message
                    PostIssueDTO issue = exchange.getIn().getBody(PostIssueDTO.class);
                    issueService.saveIssue(issue);  // Call your service to process the issue
                });
    }
}
