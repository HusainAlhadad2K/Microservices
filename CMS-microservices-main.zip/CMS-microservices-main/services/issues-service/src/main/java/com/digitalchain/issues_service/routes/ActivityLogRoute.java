//package com.digitalchain.issues_service.routes;
//
//import com.digitalchain.issues_service.Entity.ActivityLog;
//import com.digitalchain.issues_service.config.BaseRouteBuilder;
//import com.digitalchain.issues_service.dto.ActivityLogDTO;
//import com.digitalchain.issues_service.service.ActivityLogService;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.camel.Exchange;
//import org.apache.camel.model.rest.RestParamType;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import java.util.List;
//import java.util.UUID;
//
//@Component
//@Slf4j
//public class ActivityLogRoute extends BaseRouteBuilder {
//
//    @Autowired
//    private ActivityLogService activityLogService;
//
//    @Override
//    public void configure() throws Exception {
//        super.configure();
//
//        rest("/issues/{issueId}/activity")
//                .get()
//                .description("Retrieve the activity log related to the issue.")
//                .param().name("issueId").type(RestParamType.path).description("The ID of the issue").dataType("UUID").endParam()
//                .to("direct:getActivityLogs");
//
//        from("direct:getActivityLogs")
//                .routeId("getActivityLogs")
//                .process(this::fetchActivityLogs)
//                .log("Fetched activity logs: ${body}")
//                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));
//    }
//
//    private void fetchActivityLogs(Exchange exchange) throws Exception {
//        UUID issueId = exchange.getIn().getHeader("issueId", UUID.class);
//
//        // Fetch list of ActivityLog entities
//        List<ActivityLog> activityLogs = activityLogService.getActivityLogsByIssue(issueId);
//
//        // Convert List<ActivityLog> to List<ActivityLogDTO>
//        List<ActivityLogDTO> activityLogDTOs = activityLogs.stream()
//                .map(this::convertToDTO)  // Convert each ActivityLog to ActivityLogDTO
//                .toList();
//
//        // Set the body to the list of ActivityLogDTOs
//        exchange.getIn().setBody(activityLogDTOs);
//    }
//
//    private ActivityLogDTO convertToDTO(ActivityLog activityLog) {
//        return new ActivityLogDTO(
//                activityLog.getLogId(),
//                activityLog.getLogMessage(),
//                activityLog.getCreatedAt()
//        );
//    }
//
//}
