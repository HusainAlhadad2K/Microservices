package com.digitalchain.issues_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserExceptionDTO {

    private UUID userId;           // The ID of the user
    private String name;           // The name of the user
    private String email;          // The email address of the user
    private String comments;       // Optional comments about the exception (e.g., why the user is added to the exception list)
}
