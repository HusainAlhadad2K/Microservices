package com.digitalchain.issues_service.dto;

import lombok.Data;
import java.util.List;

@Data
public class IssueFilterResponseDTO {
    private List<String> statuses;
    private List<FilterOptionDTO> rules;
}
