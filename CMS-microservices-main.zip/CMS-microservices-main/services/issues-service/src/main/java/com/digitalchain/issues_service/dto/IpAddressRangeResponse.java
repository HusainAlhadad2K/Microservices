package com.digitalchain.issues_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IpAddressRangeResponse {
    private UUID id;
    private String ipFrom;   // Starting IP for range
    private String ipTo;     // Ending IP for range (same as ipFrom if single IP)
    private String cidr;     // CIDR notation if applicable
    private String comment;  // Optional comment
    private String reason;   // Optional reason for whitelisting
}

