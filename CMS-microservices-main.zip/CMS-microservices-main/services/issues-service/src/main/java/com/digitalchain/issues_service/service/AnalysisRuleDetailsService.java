package com.digitalchain.issues_service.service;

import com.digitalchain.issues_service.Entity.AnalysisRule;
import com.digitalchain.issues_service.Entity.AnalysisRuleDetails;
import com.digitalchain.issues_service.dto.AnalysisRuleDetailsDTO;
import com.digitalchain.issues_service.dto.AnalysisRuleSummaryDTO;
import com.digitalchain.issues_service.exception.ResourceNotFoundException;
import com.digitalchain.issues_service.repository.AnalysisRuleDetailsRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AnalysisRuleDetailsService {

    @Autowired
    private AnalysisRuleDetailsRepository analysisRuleDetailsRepository;

    @PostConstruct
    public void initializeAnalysisRuleDetails() {
        for (AnalysisRule rule : AnalysisRule.values()) {
            Optional<AnalysisRuleDetails> existingRule = analysisRuleDetailsRepository.findById(rule.getName());
            if (existingRule.isPresent()) {
              break;
            } else {
                AnalysisRuleDetails newDetails = new AnalysisRuleDetails();
                newDetails.setRuleName(rule.getName());
                newDetails.setDescription(rule.getDescription());
                newDetails.setOpenIssues(0);         // Initialize to zero if not existing
                newDetails.setDismissedIssues(0);    // Initialize to zero if not existing
                newDetails.setTotalIssues(0);        // Initialize to zero if not existing
                newDetails.setLastIssueUpdate(null); // Initialize to null if not existing
                analysisRuleDetailsRepository.save(newDetails);
            }
        }
    }

    public List<AnalysisRuleSummaryDTO> getAllAnalysisRules() {
        return analysisRuleDetailsRepository.findAllSummary();
    }



    public AnalysisRuleDetailsDTO getAnalysisRuleByName(String ruleName) {
        return analysisRuleDetailsRepository.findByRuleNameIgnoreCase(ruleName)
                .orElseThrow(() -> new ResourceNotFoundException("Analysis rule not found: " + ruleName));
    }

    public AnalysisRuleDetailsDTO createOrUpdateAnalysisRule(AnalysisRuleDetailsDTO analysisRuleDetailsDTO) {
//        validateSeverity(analysisRuleDetailsDTO);
        AnalysisRuleDetails analysisRuleDetails = convertToEntity(analysisRuleDetailsDTO);
        AnalysisRuleDetails savedEntity = analysisRuleDetailsRepository.save(analysisRuleDetails);
        return convertToDTO(savedEntity);
    }

    public void deleteAnalysisRule(String ruleName) {
        AnalysisRuleDetails existingRule = analysisRuleDetailsRepository.findById(ruleName)
                .orElseThrow(() -> new ResourceNotFoundException("Analysis rule not found: " + ruleName));
        analysisRuleDetailsRepository.delete(existingRule);
    }

    // Validation method for severity
//    private void validateSeverity(AnalysisRuleDetailsDTO dto) {
//        if ((dto.getSeverityValue() != null && (dto.getSeverityValue() < 1 || dto.getSeverityValue() > 9)))  {
//        throw new IllegalArgumentException("Severity values must be between 1 and 9, inclusive.");
//        }
//
//    }

    // Conversion methods

    private AnalysisRuleDetailsDTO convertToDTO(AnalysisRuleDetails ruleDetails) {
        return new AnalysisRuleDetailsDTO(
                ruleDetails.getRuleName(),
                ruleDetails.getDescription(),
                ruleDetails.getOpenIssues(),
                ruleDetails.getDismissedIssues(),
                ruleDetails.getTotalIssues(),
                ruleDetails.getLastIssueUpdate()
        );
    }
    private AnalysisRuleDetails convertToEntity(AnalysisRuleDetailsDTO ruleDetailsDTO) {
        AnalysisRuleDetails ruleDetails = new AnalysisRuleDetails();
        ruleDetails.setRuleName(ruleDetailsDTO.getRuleName());
        ruleDetails.setOpenIssues(ruleDetailsDTO.getOpenIssues());
        ruleDetails.setDismissedIssues(ruleDetailsDTO.getDismissedIssues());
        ruleDetails.setTotalIssues(ruleDetailsDTO.getTotalIssues());
        ruleDetails.setLastIssueUpdate(ruleDetailsDTO.getLastIssueUpdate());
        return ruleDetails;
    }

}
