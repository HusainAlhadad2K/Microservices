package com.digitalchain.issues_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnalysisRuleSummaryDTO {
    private String ruleName; // Name of the rule
    private String description; // Description of the rule
    private int openIssues; // Count of open issues
}
