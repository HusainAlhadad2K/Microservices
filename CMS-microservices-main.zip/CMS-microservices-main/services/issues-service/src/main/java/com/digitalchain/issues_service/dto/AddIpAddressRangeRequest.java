package com.digitalchain.issues_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddIpAddressRangeRequest {
    private String ipFrom;
    private String ipTo;
    private String cidr;
    private String comment;
    private String reason;
}

