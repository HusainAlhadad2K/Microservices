//package com.digitalchain.issues_service.repository;
//
//import com.digitalchain.issues_service.Entity.AnalysisRule;
//import com.digitalchain.issues_service.dto.AnalysisRuleDTO;
//import com.digitalchain.issues_service.dto.IssueDTO;
//import com.digitalchain.issues_service.exception.ResourceNotFoundException;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import java.util.Date;
//import java.util.List;
//import java.util.UUID;
//
//@Repository
//public interface RuleRepository extends JpaRepository<AnalysisRule, UUID> {
//
//    @Query("SELECT new com.digitalchain.issues_service.dto.AnalysisRuleDTO(r.ruleId, r.name, r.description, r.severity, r.status, r.createdAt, r.updatedAt) FROM AnalysisRule r")
//    List<AnalysisRuleDTO> findAllRules();
//
//    @Query("SELECT new com.digitalchain.issues_service.dto.AnalysisRuleDTO(r.ruleId, r.name, r.description, r.severity, r.status, r.createdAt, r.updatedAt) FROM AnalysisRule r WHERE r.ruleId = ?1")
//    AnalysisRuleDTO findRuleById(UUID ruleId);
//
//    @Query("SELECT new com.digitalchain.issues_service.dto.IssueDTO(i.issueId, i.title, i.description, i.severity, i.status, i.createdAt) FROM Issue i WHERE i.ruleId = ?1")
//    List<IssueDTO> findIssuesByRuleId(UUID ruleId);
//
//    @Query("SELECT new com.digitalchain.issues_service.dto.CriteriaOptionDTO(c.optionId, c.name, c.description) FROM CriteriaOption c")
//    List<CriteriaOptionDTO> findCriteriaOptions();
//
//    // Methods for saving and updating rules
//    default void saveRule(AnalysisRuleDTO ruleDTO) {
//        AnalysisRule entity = new AnalysisRule();
//        entity.setName(ruleDTO.getName());
//        entity.setDescription(ruleDTO.getDescription());
//        entity.setSeverity(ruleDTO.getSeverity());
//        entity.setStatus(ruleDTO.getStatus());
//        // Set other necessary fields here
//        save(entity);
//    }
//
//    default void updateRule(UUID ruleId, AnalysisRuleDTO updatedRule) {
//        AnalysisRule entity = findById(ruleId).orElseThrow(() -> new ResourceNotFoundException("Rule not found"));
//        entity.setName(updatedRule.getName());
//        entity.setDescription(updatedRule.getDescription());
//        entity.setSeverity(updatedRule.getSeverity());
//        entity.setStatus(updatedRule.getStatus());
//        entity.setUpdatedAt(new Date());
//        // Update other necessary fields
//        save(entity);
//    }
//
//    default void updateRuleSeverity(UUID ruleId, Integer severity) {
//        AnalysisRule entity = findById(ruleId).orElseThrow(() -> new ResourceNotFoundException("Rule not found"));
//        entity.setSeverity(severity);
//        entity.setUpdatedAt(new Date());
//        save(entity);
//    }
//}
