package com.digitalchain.issues_service.repository;

import com.digitalchain.issues_service.Entity.UserException;
import com.digitalchain.issues_service.dto.UserExceptionDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface UserExceptionRepository extends JpaRepository<UserException, UUID> {
    @Query("SELECT new com.digitalchain.issues_service.dto.UserExceptionDTO(u.userId, u.name, u.email, u.comments) " +
            "FROM UserException u")
    List<UserExceptionDTO> findAllUserExceptions();
}
