package com.digitalchain.issues_service.routes;

import com.digitalchain.issues_service.dto.UserUpdatedEvent;
import com.digitalchain.issues_service.service.UserExceptionService;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserExceptionRoute extends RouteBuilder {

    @Autowired
    private UserExceptionService userExceptionService;

    @Override
    public void configure() throws Exception {
        // Define a route to consume messages from the "UserUpdated" Kafka topic
        from("kafka:UserUpdated?brokers=localhost:9092&groupId=user-exception-group")
                .routeId("user-updated-event-route")
                .unmarshal().json(UserUpdatedEvent.class) // Convert JSON message to UserUpdatedEvent
                .process(exchange -> {
                    UserUpdatedEvent event = exchange.getIn().getBody(UserUpdatedEvent.class);
                    userExceptionService.updateUser(event); // Call the service to handle the event
                });
    }
}
