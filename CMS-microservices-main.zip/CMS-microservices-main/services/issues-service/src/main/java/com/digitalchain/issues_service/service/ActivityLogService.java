package com.digitalchain.issues_service.service;

import com.digitalchain.issues_service.Entity.ActivityLog;
import com.digitalchain.issues_service.repository.ActivityLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ActivityLogService {

    @Autowired
    private ActivityLogRepository activityLogRepository;

    public List<ActivityLog> getActivityLogsByIssue(UUID issueId) {
        return activityLogRepository.findByIssueIssueId(issueId);
    }

    public void logActivity(ActivityLog log) {
        activityLogRepository.save(log);
    }
}
