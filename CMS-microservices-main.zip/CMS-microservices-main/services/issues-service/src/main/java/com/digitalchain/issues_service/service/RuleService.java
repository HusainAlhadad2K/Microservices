//package com.digitalchain.issues_service.service;
//
//import com.digitalchain.issues_service.dto.*;
//import com.digitalchain.issues_service.Entity.*;
//import com.digitalchain.issues_service.exception.ResourceNotFoundException;
//import com.digitalchain.issues_service.repository.*;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.Date;
//import java.util.List;
//import java.util.UUID;
//
//@Service
//public class RuleService {
//
//    @Autowired
//    private RuleRepository ruleRepository;
//
//    @Autowired
//    private IssueRepository issueRepository;
//
//    public List<AnalysisRuleDTO> getAllAnalysisRules() {
//        return ruleRepository.findAllRules();
//    }
//
//    public AnalysisRuleDTO getRuleById(UUID ruleId) {
//        return ruleRepository.findRuleById(ruleId);
//    }
//
//    public void createAnalysisRule(AnalysisRuleDTO rule) {
//        ruleRepository.saveRule(rule);
//    }
//
//    public void updateRule(UUID ruleId, AnalysisRuleDTO updatedRule) {
//        ruleRepository.updateRule(ruleId, updatedRule);
//    }
//
//    public void updateRuleSeverity(UUID ruleId, Integer severity) {
//        ruleRepository.updateRuleSeverity(ruleId, severity);
//    }
//
//    public List<IssueDTO> getIssuesByRuleId(UUID ruleId) {
//        return ruleRepository.findIssuesByRuleId(ruleId);
//    }
//
//    public boolean validateRule(RuleValidationDTO validation) {
//        // Simple validation logic example
//        return validation != null && validation.getCriteria() != null && !validation.getCriteria().isEmpty();
//    }
//
//    public List<CriteriaOptionDTO> getCriteriaOptions() {
//        return ruleRepository.findCriteriaOptions();
//    }
//
//    public void reviewRule(RuleReviewDTO review) {
//        // Assume review logic involves updating the rule's status based on the review outcome
//        AnalysisRule rule = ruleRepository.findById(review.getRuleId())
//                .orElseThrow(() -> new ResourceNotFoundException("Rule not found"));
//        rule.setStatus(review.getStatus());
//        rule.setUpdatedAt(new Date());
//        ruleRepository.save(rule);
//    }
//
//    public void resolveIssue(UUID issueId) {
//        // Find the issue and mark it as resolved
//        Issue issue = issueRepository.findById(issueId)
//                .orElseThrow(() -> new ResourceNotFoundException("Issue not found"));
//        issue.setStatus("Resolved");
//        issue.setResolvedAt(new Date());
//        issueRepository.save(issue);
//    }
//
//    public void updateIssueStatus(UUID issueId, String status) {
//        // Update the status of the issue
//        // Update the status of the issue
//        Issue issue = issueRepository.findById(issueId)
//                .orElseThrow(() -> new ResourceNotFoundException("Issue not found"));
//        issue.setStatus(status);
//        issue.setUpdatedAt(new Date());
//        issueRepository.save(issue);
//
//        // Update the "Last Issue Update" for the related rule
//        AnalysisRule rule = ruleRepository.findById(issue.getRuleId())
//                .orElseThrow(() -> new ResourceNotFoundException("Rule not found"));
//        rule.setUpdatedAt(issue.getUpdatedAt()); // Set the rule's updatedAt to the issue's updatedAt
//        ruleRepository.save(rule);
//    }
//}
