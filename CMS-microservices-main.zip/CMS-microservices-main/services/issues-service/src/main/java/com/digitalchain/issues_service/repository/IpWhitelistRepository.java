package com.digitalchain.issues_service.repository;

import com.digitalchain.issues_service.Entity.IpWhitelistEntry;
import com.digitalchain.issues_service.dto.IpAddressRangeResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.Query;

    @Repository
    public interface IpWhitelistRepository extends JpaRepository<IpWhitelistEntry, UUID> {
        @Query("SELECT new com.digitalchain.issues_service.dto.IpAddressRangeResponse(i.id, i.ipFrom, i.ipTo, i.cidr, i.comment, i.reason) " +
                "FROM IpWhitelistEntry i")
        List<IpAddressRangeResponse> findAllIpWhitelistEntries();
    }

