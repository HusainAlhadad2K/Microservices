package com.digitalchain.issues_service.utils;

import com.digitalchain.issues_service.Entity.AnalysisRuleDetails;
import com.digitalchain.issues_service.Entity.Issue;
import com.digitalchain.issues_service.repository.AnalysisRuleDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class IssueRemediation {

    public enum RemediationAction {
        RESOLVE,
        DISMISS
    }

    @Autowired
    private AnalysisRuleDetailsRepository analysisRuleDetailsRepository;

    public void remediate(Issue issue, RemediationAction action) {
        // Find the AnalysisRuleDetails based on the detectedByRule field of the issue
        String ruleName = issue.getDetectedByRule();
        if (ruleName == null || ruleName.isEmpty()) {
            throw new IllegalArgumentException("Issue does not have a detected rule.");
        }

        AnalysisRuleDetails analysisRuleDetails = analysisRuleDetailsRepository.findById(ruleName)
                .orElseThrow(() -> new IllegalArgumentException("No AnalysisRuleDetails found for rule: " + ruleName));

        switch (action) {
            case RESOLVE:
                resolveIssue(issue);
                if (analysisRuleDetails.getOpenIssues() > 0) {
                    analysisRuleDetails.setOpenIssues(analysisRuleDetails.getOpenIssues() - 1);
                }
                break;

            case DISMISS:
                dismissIssue(issue);

                // Decrement open issues count
                if (analysisRuleDetails.getOpenIssues() > 0) {
                    analysisRuleDetails.setOpenIssues(analysisRuleDetails.getOpenIssues() - 1);
                }

                // Increment dismissed issues count
                analysisRuleDetails.setDismissedIssues(analysisRuleDetails.getDismissedIssues() + 1);
                break;

            default:
                throw new IllegalArgumentException("Invalid remediation action: " + action);
        }

        // Update the last issue update timestamp
        analysisRuleDetails.setLastIssueUpdate(new Date());

        // Save the updated AnalysisRuleDetails entity
        analysisRuleDetailsRepository.save(analysisRuleDetails);
    }

    private void resolveIssue(Issue issue) {
        // Implement logic for resolving the issue
        issue.setStatus("Resolved");
    }

    private void dismissIssue(Issue issue) {
        // Implement logic for dismissing the issue
        issue.setStatus("Dismissed");
    }
}
