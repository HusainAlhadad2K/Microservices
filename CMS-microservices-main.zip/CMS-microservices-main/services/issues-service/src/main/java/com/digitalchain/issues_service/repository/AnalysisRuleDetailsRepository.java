package com.digitalchain.issues_service.repository;

import com.digitalchain.issues_service.Entity.AnalysisRuleDetails;
import com.digitalchain.issues_service.dto.AnalysisRuleSummaryDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.digitalchain.issues_service.dto.AnalysisRuleDetailsDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AnalysisRuleDetailsRepository extends JpaRepository<AnalysisRuleDetails, String> {

    // Fetch details specifically structured for viewing all analysis rules
    @Query("SELECT new com.digitalchain.issues_service.dto.AnalysisRuleDetailsDTO( " +
            "ar.ruleName, " +
            "ar.description, " +
            "ar.openIssues, " +
            "ar.dismissedIssues, " +
            "ar.totalIssues, " +
            "ar.lastIssueUpdate) " +
            "FROM AnalysisRuleDetails ar")
    List<AnalysisRuleDetailsDTO> findAllDetailsForOverview();

    // Fetch details structured for viewing a single analysis rule by name
    @Query("SELECT new com.digitalchain.issues_service.dto.AnalysisRuleDetailsDTO( " +
            "ar.ruleName, " +
            "ar.description, " +
            "ar.openIssues, " +
            "ar.dismissedIssues, " +
            "ar.totalIssues, " +
            "ar.lastIssueUpdate) " +
            "FROM AnalysisRuleDetails ar WHERE ar.ruleName = ?1")
    Optional<AnalysisRuleDetailsDTO> fetchByRuleNameForOverview(String ruleName);


    @Query("SELECT new com.digitalchain.issues_service.dto.AnalysisRuleDetailsDTO( " +
            "ar.ruleName, " +
            "ar.description, " +
            "ar.openIssues, " +
            "ar.dismissedIssues, " +
            "ar.totalIssues, " +
            "ar.lastIssueUpdate) " +
            "FROM AnalysisRuleDetails ar WHERE LOWER(ar.ruleName) = LOWER(:ruleName)")
    Optional<AnalysisRuleDetailsDTO> findByRuleNameIgnoreCase(@Param("ruleName") String ruleName);


    // Fetch details for summary view (list view)
    @Query("SELECT new com.digitalchain.issues_service.dto.AnalysisRuleSummaryDTO( " +
            "ar.ruleName, ar.description, ar.openIssues)" +
            "FROM AnalysisRuleDetails ar")
    List<AnalysisRuleSummaryDTO> findAllSummary();
}
