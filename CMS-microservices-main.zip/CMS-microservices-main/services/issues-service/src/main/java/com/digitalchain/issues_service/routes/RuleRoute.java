package com.digitalchain.issues_service.routes;

import com.digitalchain.issues_service.Entity.AnalysisRuleDetails;
import com.digitalchain.issues_service.config.BaseRouteBuilder;
import com.digitalchain.issues_service.dto.*;
import com.digitalchain.issues_service.repository.UserExceptionRepository;
import com.digitalchain.issues_service.service.AnalysisRuleDetailsService;
import com.digitalchain.issues_service.service.IpWhitelistService;
import com.digitalchain.issues_service.service.UserExceptionService;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class RuleRoute extends BaseRouteBuilder {

//    @Autowired
//    private RuleService ruleService;

    @Autowired
    private IpWhitelistService ipWhitelistService;

    @Autowired
    private AnalysisRuleDetailsService analysisRuleDetailsService;

    @Autowired
    private UserExceptionService userExceptionService;

    @Override
    public void configure() throws Exception {
        super.configure();

        // Analysis Rule Management
        rest("/issues/analysis-rules")
                .get()
                .description("Retrieve all analysis rules")
                .to("direct:getAllAnalysisRules")

                .get("/{ruleName}")
                .description("Get analysis rule by name")
                .param().name("ruleName").type(RestParamType.path).description("The name of the analysis rule").dataType("string").endParam()
                .to("direct:getAnalysisRuleByName");

//                .post()
//                .description("Create or update an analysis rule")
//                .type(AnalysisRuleDetailsDTO.class)
//                .to("direct:createOrUpdateAnalysisRule");

//                .delete("/{ruleName}")
//                .description("Delete an analysis rule by name")
//                .param().name("ruleName").type(RestParamType.path).description("The name of the analysis rule").dataType("String").required(true).endParam()
//                .to("direct:deleteAnalysisRule");



//                .get("/{ruleId}/issues").to("direct:getRuleIssues")
//                .post("/{ruleId}/validate").to("direct:validateRule")
//                .get("/criteria-options").to("direct:getCriteriaOptions")
//                .post("/review").to("direct:reviewRule");

//         User Exceptions Management
        rest("/issues/user-exceptions")
                .post()
                .description("Add user exception")
                .type(UserExceptionDTO.class)
                .to("direct:addUserException")
                .delete("/{userId}")
                .description("Get user exception by user Id")
                .param().name("userId").type(RestParamType.path).description("The if of the user").dataType("string").dataFormat("uuid").endParam()
                .to("direct:deleteUserException")
                .get()
                .description("Retrieve all user exception")
                .to("direct:getUserExceptions");
//        // IP Whitelist Management
        rest("/issues/ip-whitelist")
                .post()
                .description("Add IP whitelist entry")
                .type(AddIpAddressRangeRequest.class)
                .to("direct:addIPWhitelist")
                .delete("/{whitelistId}")
                .description("Delete IP whitelist entry by ID")
                .param().name("whitelistId").type(RestParamType.path).description("The ID of the IP whitelist entry").dataType("string").dataFormat("uuid").endParam()
                .to("direct:deleteIPWhitelist")
                .get()
                .description("Retrieve all IP whitelist entries")
                .to("direct:getIPWhitelists");

//        // Issue Management
//        rest("/api/issues")
//                .post("/{issueId}/resolve").to("direct:resolveIssue")
//                .post("/{issueId}/update-status").to("direct:updateIssueStatus");

        // Routes Implementation
//        from("direct:getRuleIssues").process(this::getRuleIssues);
//        from("direct:validateRule").process(this::validateRule);
//        from("direct:getCriteriaOptions").process(this::getCriteriaOptions);
//        from("direct:reviewRule").process(this::reviewRule);

        from("direct:addUserException").process(this::addUserException);
        from("direct:deleteUserException").process(this::deleteUserException);
        from("direct:getUserExceptions").process(this::getUserExceptions);

        from("direct:addIPWhitelist").process(this::addIPWhitelist);
        from("direct:deleteIPWhitelist").process(this::deleteIPWhitelist);
        from("direct:getIPWhitelists").process(this::getIPWhitelists);

//        from("direct:resolveIssue").process(this::resolveIssue);
//        from("direct:updateIssueStatus").process(this::updateIssueStatus);

        from("direct:getAllAnalysisRules")
                .routeId("getAllAnalysisRules")
                .process(this::getAllAnalysisRules)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        from("direct:getAnalysisRuleByName")
                .routeId("getAnalysisRuleByName")
                .process(this::getAnalysisRuleByName)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        from("direct:createOrUpdateAnalysisRule")
                .routeId("createOrUpdateAnalysisRule")
                .process(this::createOrUpdateAnalysisRule)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(201));

        from("direct:deleteAnalysisRule")
                .routeId("deleteAnalysisRule")
                .process(this::deleteAnalysisRule)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(204));
    }
    private void getAllAnalysisRules(Exchange exchange) {
        exchange.getIn().setBody(analysisRuleDetailsService.getAllAnalysisRules());
    }

    private void getAnalysisRuleByName(Exchange exchange) {
        String ruleName = exchange.getIn().getHeader("ruleName", String.class);
        log.info("LOOK HERE: Received ruleName: {}", ruleName);

        AnalysisRuleDetailsDTO ruleDetails = analysisRuleDetailsService.getAnalysisRuleByName(ruleName);
        exchange.getIn().setBody(ruleDetails);
    }


    private void createOrUpdateAnalysisRule(Exchange exchange) {
        AnalysisRuleDetailsDTO ruleDetailsDTO = exchange.getIn().getBody(AnalysisRuleDetailsDTO.class);
        AnalysisRuleDetailsDTO savedRuleDetails = analysisRuleDetailsService.createOrUpdateAnalysisRule(ruleDetailsDTO);
        exchange.getIn().setBody(savedRuleDetails);
    }

    private void deleteAnalysisRule(Exchange exchange) {
        String ruleName = exchange.getIn().getHeader("ruleName", String.class);
        analysisRuleDetailsService.deleteAnalysisRule(ruleName);
    }









//    private void getRuleIssues(Exchange exchange) {
//        UUID ruleId = exchange.getIn().getHeader("ruleId", UUID.class);
//        List<IssueDTO> issues = ruleService.getIssuesByRuleId(ruleId);
//        exchange.getIn().setBody(issues);
//    }

//    private void validateRule(Exchange exchange) {
//        RuleValidationDTO validation = exchange.getIn().getBody(RuleValidationDTO.class);
//        boolean isValid = ruleService.validateRule(validation);
//        exchange.getIn().setBody(isValid);
//    }
//
//    private void getCriteriaOptions(Exchange exchange) {
//        List<CriteriaOptionDTO> options = ruleService.getCriteriaOptions();
//        exchange.getIn().setBody(options);
//    }
//
//    private void reviewRule(Exchange exchange) {
//        RuleReviewDTO review = exchange.getIn().getBody(RuleReviewDTO.class);
//        ruleService.reviewRule(review);
//        exchange.getIn().setBody("Rule review completed");
//    }

    private void addUserException(Exchange exchange) {
        // Retrieve the UserExceptionDTO from the request body
        UserExceptionDTO userExceptionDTO = exchange.getIn().getBody(UserExceptionDTO.class);
        if (userExceptionDTO == null) {
            throw new IllegalArgumentException("User exception data is required");
        }

        // Call the service to add the user exception entry
        userExceptionService.addUserException(userExceptionDTO);

        // Set the response body
        exchange.getIn().setBody("User exception added successfully");
    }

    private void deleteUserException(Exchange exchange) {
        // Retrieve the userId from the request header
        UUID userId = exchange.getIn().getHeader("userId", UUID.class);
        if (userId == null) {
            throw new IllegalArgumentException("userId is required");
        }

        // Call the service to remove the user exception entry
        userExceptionService.deleteUserException(userId);

        // Set the response body
        exchange.getIn().setBody("User exception deleted successfully");
    }

    private void addIPWhitelist(Exchange exchange) {
        AddIpAddressRangeRequest ipWhitelistDTO = exchange.getIn().getBody(AddIpAddressRangeRequest.class);
        if (ipWhitelistDTO == null) {
            throw new IllegalArgumentException("IP whitelist data is required");
        }
        ipWhitelistService.addIPWhitelist(ipWhitelistDTO);
        exchange.getIn().setBody("IP whitelist entry added successfully");
    }

    private void deleteIPWhitelist(Exchange exchange) {
        UUID whitelistId = exchange.getIn().getHeader("whitelistId", UUID.class);
        if (whitelistId == null) {
            throw new IllegalArgumentException("whitelistId is required");
        }
        ipWhitelistService.deleteIPWhitelist(whitelistId);
        exchange.getIn().setBody("IP whitelist entry deleted successfully");
    }
    private void getIPWhitelists(Exchange exchange) {
        exchange.getIn().setBody(ipWhitelistService.getIPWhitelists());
    }
    private void getUserExceptions(Exchange exchange) {
        exchange.getIn().setBody(userExceptionService.getUserExceptions());
    }
}
