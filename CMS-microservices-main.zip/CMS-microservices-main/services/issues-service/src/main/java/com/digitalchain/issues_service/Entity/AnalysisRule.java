package com.digitalchain.issues_service.Entity;

import lombok.Getter;

@Getter
public enum AnalysisRule {
    EMPTY_GROUP("Empty Group", "Detects groups that contain no users."),
    EXTERNAL_SHARING("External Sharing", "Detects files and folders accessible by people outside your organization."),
    INDIVIDUAL_PERMISSION("Individual Permission", "Detects files and folders that are directly permitted to individual users, rather than to groups."),
    MALFORMED_PERMISSIONS("Malformed Permissions", "Detects folders where NTFS permissions are not working correctly, due to ACL ordering issues or orphaned inheritance bits."),
    OPEN_ACCESS("Open Access", "Detects folders accessible by Open Groups (groups with many users)."),
    PROBABLE_RANSOMWARE("Probable Ransomware", "Detects user accounts that are potentially compromised by ransomware."),
    PUBLIC_LINK("Public Link", "Detects files and folders accessible via public links."),
    SUSPICIOUS_LOGIN("Suspicious Login", "Detects anomalous user login activity that may indicate a compromised account."),
    UNUSED_GROUP("Unused Group", "Detects groups not used to grant any folder permissions."),
    UNUSUAL_ACCESS("Unusual Access", "Detects users who access or delete an unusually large number of files, which may indicate malicious activity.");

    private final String name;
    private final String description;

    AnalysisRule(String name, String description) {
        this.name = name;
        this.description = description;

    }
    // Static method to get description by rule name
    public static String getDescriptionByName(String ruleName) {
        for (AnalysisRule rule : AnalysisRule.values()) {
            if (rule.name.equalsIgnoreCase(ruleName)) {
                return rule.getDescription();
            }
        }
        return "No description available."; // Default if rule name not found
    }


}
