package com.digitalchain.issues_service.service;

import com.digitalchain.issues_service.Entity.IpWhitelistEntry;
import com.digitalchain.issues_service.dto.AddIpAddressRangeRequest;
import com.digitalchain.issues_service.dto.IpAddressRangeListResponse;
import com.digitalchain.issues_service.dto.IpAddressRangeResponse;
import com.digitalchain.issues_service.repository.IpWhitelistRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class IpWhitelistService {

    @Autowired
    private IpWhitelistRepository ipWhitelistRepository;

    public void addIPWhitelist(AddIpAddressRangeRequest ipWhitelistDTO) {
        IpWhitelistEntry entry = new IpWhitelistEntry();
        entry.setIpFrom(ipWhitelistDTO.getIpFrom());
        entry.setIpTo(ipWhitelistDTO.getIpTo());
        entry.setCidr(ipWhitelistDTO.getCidr());
        entry.setComment(ipWhitelistDTO.getComment());
        entry.setReason(ipWhitelistDTO.getReason());

        ipWhitelistRepository.save(entry);
    }

    public void deleteIPWhitelist(UUID whitelistId) {
        if (ipWhitelistRepository.existsById(whitelistId)) {
            ipWhitelistRepository.deleteById(whitelistId);
        } else {
            throw new EntityNotFoundException("IP whitelist entry not found for the given ID.");
        }
    }

    public IpAddressRangeListResponse getIPWhitelists() {
        List<IpAddressRangeResponse> whitelists = ipWhitelistRepository.findAllIpWhitelistEntries();
        return new IpAddressRangeListResponse(whitelists);
    }
}
