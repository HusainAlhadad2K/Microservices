//package com.digitalchain.issues_service.config;
//
//
//import lombok.Data;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//@Data
//public class OCIConfig {
//    @Value("${oci.apiKeyFile}")
//    private String apiKeyFile;
//
//    @Value("${oci.tenancyId}")
//    private String tenancyId;
//
//    @Value("${oci.userId}")
//    private String userId;
//
//    @Value("${oci.fingerprint}")
//    private String fingerprint;
//
//    @Value("${oci.region}")
//    private String region;
//
//    @Value("${oci.compartmentId}")
//    private String compartmentId;
//
//    @Value("${oci.namespaceName}")
//    private String namespaceName;
//
//    @Value("${oci.objectstorage.bucket}")
//    private String objectStorageBucket;
//}
