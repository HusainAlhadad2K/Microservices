package com.digitalchain.issues_service.routes;

import com.digitalchain.issues_service.config.BaseRouteBuilder;
import com.digitalchain.issues_service.dto.*;
import com.digitalchain.issues_service.service.IssueService;
import com.digitalchain.issues_service.utils.IssueRemediation;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
@Slf4j
public class IssueRoute extends BaseRouteBuilder {

    @Autowired
    private IssueService issueService;

    @Override
    public void configure() throws Exception {
        super.configure();

        // Routes for issue management
        rest("/issues")
                .get()
                .description("Retrieve a paginated, sortable, and filterable list of issue summaries.")
                .param().name("page").type(RestParamType.query).description("Page number").dataType("int").defaultValue("0").required(false).endParam()
                .param().name("size").type(RestParamType.query).description("Page size").dataType("int").defaultValue("10").required(false).endParam()
                .param().name("sortBy").type(RestParamType.query).description("Sort by field").dataType("string").defaultValue("createdAt").required(false).endParam()
                .param().name("sortOrder").type(RestParamType.query).description("Sort order (asc/desc)").dataType("string").defaultValue("desc").required(false).endParam()
                .param().name("status").type(RestParamType.query).description("Issue status filter").dataType("string").required(false).endParam()
                .param().name("rule").type(RestParamType.query).description("Detected rule filter").dataType("string").required(false).endParam()
                .param().name("source").type(RestParamType.query).description("Source filter").dataType("string").required(false).endParam()
                .to("direct:getIssueSummaries")

                .post()
                .description("Create a new issue.")
                .type(PostIssueDTO.class)
                .to("direct:createIssue")


                .get("/filters")
                .description("Retrieves available filter options for issues.")
                .to("direct:getIssueFilters")
//                .get()
//                .description("Retrieve a list of all issues.")
//                .to("direct:getIssues")

                .get("/{issueId}")
                .description("Fetch detailed information about a specific issue.")
                .param().name("issueId").type(RestParamType.path).description("The ID of the issue").dataType("string")       // Use "string" as the data type for Swagger compatibility
                .dataFormat("uuid").endParam()
                .to("direct:getIssueDetails")

                .post("/{issueId}/remediate")
                .description("Send a command to remediate the issue, such as resolving or closing it.")
                .param().name("issueId").type(RestParamType.path).description("The ID of the issue").dataType("string").dataFormat("uuid").endParam()
                .param().name("action").type(RestParamType.query).description("Action to perform: RESOLVE or DISMISS").dataType("string").endParam()
                .to("direct:remediateIssue")

                .post("/{issueId}/assign")
                .description("Assign the issue to a different user or delegate it.")
                .type(AssignIssueDTO.class)
                .param().name("issueId").type(RestParamType.path).description("The ID of the issue").dataType("string").dataFormat("uuid").required(true).endParam()
                .to("direct:assignIssue");

        from("direct:getIssueSummaries")
                .routeId("getIssueSummaries")
                .process(this::fetchIssueSummaries)
                .log("Fetched issue summaries: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        from("direct:createIssue")
                .routeId("createIssue")
                .process(this::createIssue)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(201));

        from("direct:getIssueFilters")
                .routeId("getIssueFilters")
                .process(this::fetchIssueFilters)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        from("direct:getIssues")
                .routeId("getIssues")
                .process(this::fetchIssues)
                .log("Fetched issues: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        from("direct:getIssueDetails")
                .routeId("getIssueDetails")
                .process(this::fetchIssueDetails)
                .log("Fetched issue details: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        from("direct:remediateIssue")
                .routeId("remediateIssue")
                .process(this::remediateIssue)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

        from("direct:assignIssue")
                .routeId("assignIssue")
                .process(this::assignIssue)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200));

    }

    private void createIssue(Exchange exchange) {
        PostIssueDTO issueDTO = exchange.getIn().getBody(PostIssueDTO.class);
        issueService.saveIssue(issueDTO);
        exchange.getIn().setBody("Issue created successfully");
    }
    private void fetchIssues(Exchange exchange) throws Exception {
        List<GetIssueDTO> issues = issueService.getAllIssues();
        exchange.getIn().setBody(issues);
    }

    private void fetchIssueDetails(Exchange exchange) throws Exception {
        UUID issueId = exchange.getIn().getHeader("issueId", UUID.class);
        GetIssueDTO issue = issueService.getIssueById(issueId);
        exchange.getIn().setBody(issue);
    }

    private void fetchIssueSummaries(Exchange exchange) {
        String status = exchange.getIn().getHeader("status", String.class);
        String rule = exchange.getIn().getHeader("rule", String.class);
        String source = exchange.getIn().getHeader("source", String.class);

        int page = exchange.getIn().getHeader("page", 0,Integer.class);
        int size = exchange.getIn().getHeader("size", 10,Integer.class);
        String sortBy = exchange.getIn().getHeader("sortBy", "updatedAt", String.class);
        String sortOrder = exchange.getIn().getHeader("sortOrder","desc", String.class);

        Page<IssueSummaryDTO> issues = issueService.getAllIssueSummaries(status, rule, source, page, size, sortBy, sortOrder);
        exchange.getIn().setBody(issues);
    }

    private void remediateIssue(Exchange exchange) throws Exception {
        UUID issueId = exchange.getIn().getHeader("issueId", UUID.class);
        String actionString = exchange.getIn().getHeader("action", String.class);

        // Convert actionString to the RemediationAction enum
        IssueRemediation.RemediationAction action = IssueRemediation.RemediationAction.valueOf(actionString.toUpperCase());

        // Call the service method with the provided action
        issueService.remediateIssue(issueId, action);
        exchange.getIn().setBody("Issue " + actionString.toLowerCase() + " successfully");
    }
    private void fetchIssueFilters(Exchange exchange) {
        IssueFilterResponseDTO filterOptions = issueService.getFilterOptions();
        exchange.getIn().setBody(filterOptions);
    }
    private void assignIssue(Exchange exchange) throws Exception {
        UUID issueId = exchange.getIn().getHeader("issueId", UUID.class);
        AssignIssueDTO assignIssueDTO = exchange.getIn().getBody(AssignIssueDTO.class);


        issueService.assignIssue(issueId, assignIssueDTO);
        exchange.getIn().setBody("Issue assigned successfully");
    }

}
