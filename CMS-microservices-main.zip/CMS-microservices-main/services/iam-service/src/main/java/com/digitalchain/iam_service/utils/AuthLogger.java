package com.digitalchain.iam_service.utils;


import com.digitalchain.common.dto.AccessMethod;
import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.login.LoginLogAction;
import com.digitalchain.common.dto.login.LoginLogDTO;
import com.digitalchain.common.dto.workflow.WorkflowAction;
import com.digitalchain.common.dto.workflow.WorkflowLogDTO;
import com.digitalchain.common.dto.workflow.StepType;
import com.digitalchain.iam_service.service.AuthLogProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class AuthLogger {

    @Autowired
    private AuthLogProducerService authLogProducerService;

    public void log(LoginLogAction action, UserDTO user) {
        LoginLogDTO logDTO = LoginLogDTO.builder()
                .accessMethod(AccessMethod.WEB)
                .action(action)
                .actionInfo(action.getDescription())
                .actionTime(new Date())
                .ipAddress(user.getIpAddress())
                .userId(user.getUser_id())
                .userName(user.getUser_displayname())
                .build();

        authLogProducerService.sendLoginLog(logDTO);
    }
}
