package com.digitalchain.iam_service.service;

import com.digitalchain.common.dto.login.LoginLogDTO;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class AuthLogProducerService {
    @Autowired
    private ProducerTemplate producerTemplate;

    // Method to send log messages to Kafka
    public void sendLoginLog(LoginLogDTO logDTO) {
        // Send the log message to the Kafka topic through the Camel route
        producerTemplate.sendBody("direct:sendAuthLog", logDTO);
    }
}
