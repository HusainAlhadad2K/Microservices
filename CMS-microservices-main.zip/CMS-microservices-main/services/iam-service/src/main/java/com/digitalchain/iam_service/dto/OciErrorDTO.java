package com.digitalchain.iam_service.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OciErrorDTO {
    private String error;
    private String error_description;
    private String ecid;
}
