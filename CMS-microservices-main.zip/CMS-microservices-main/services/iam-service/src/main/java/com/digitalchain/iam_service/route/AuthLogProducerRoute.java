package com.digitalchain.iam_service.route;

import com.digitalchain.iam_service.config.BaseRouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class AuthLogProducerRoute extends BaseRouteBuilder {

    @Override
    public void configure() throws Exception {
        // Kafka Producer route for sending log messages to Kafka topic
        from("direct:sendAuthLog")
                .routeId("sendAuthLogRoute")
                .marshal().json()  // Convert the object to JSON
                .to("kafka:{{login.activity.logging.topic}}?brokers={{camel.component.kafka.brokers}}")
                .log("Sent message to Kafka: ${body}");
    }
}
