package com.digitalchain.iam_service.exception;

public class UnsupportedMediaTypeException extends RuntimeException {
    public UnsupportedMediaTypeException(String message){super(message);}
}