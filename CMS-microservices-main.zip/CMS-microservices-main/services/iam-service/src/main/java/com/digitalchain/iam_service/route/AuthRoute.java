package com.digitalchain.iam_service.route;


import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.login.LoginLogAction;
import com.digitalchain.iam_service.config.BaseRouteBuilder;
import com.digitalchain.iam_service.dto.LoginRequestDTO;
import com.digitalchain.iam_service.service.DecodeService;
import com.digitalchain.iam_service.service.JwtService;
import com.digitalchain.iam_service.utils.AuthLogger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class AuthRoute extends BaseRouteBuilder {

    @Autowired
    private JwtService jwtService;

    @Autowired
    private DecodeService decodeService;

    @Autowired
    private AuthLogger authLogger;

    @Value("${idcs.token.url}")
    private String tokenUrl;

    @Value("${idcs.client.id}")
    private String clientId;

    @Value("${idcs.client.secret}")
    private String clientSecret;

    @Value("${idcs.scope:AdminUsersAdminUsersRead}")  // default scope
    private String scope;

    private final ObjectMapper objectMapper = new ObjectMapper();  // For parsing error responses

    @Override
    public void configure() throws Exception {
        super.configure();

        // Define REST endpoints for authentication routes
        rest("/auth")
                .post("/token")
                .type(LoginRequestDTO.class)
                .to("direct:getToken")

                .get("/validate")
                .to("direct:validateToken")

                .get("/decode")
                .to("direct:decodeToken");

        // Route for generating token
        from("direct:getToken")
                .routeId("getTokenRoute")
                .process(this::prepareTokenRequest)
                .toD("{{idcs.token.url}}?bridgeEndpoint=true")
                .choice()
                .when(header(Exchange.HTTP_RESPONSE_CODE).isGreaterThanOrEqualTo(400))
                .process(exchange -> {
                    throw new Exception("Invalid username or password");
                })
                .otherwise()
                .unmarshal().json()  // Only unmarshal if the response is successful (status code < 400)
                .process(this::logSuccessfulLogin)
                .end();


        // Route for validating token
        from("direct:validateToken")
                .routeId("validateTokenRoute")
                .process(this::validateToken);

        // Route for decoding token
        from("direct:decodeToken")
                .routeId("decodeTokenRoute")
                .process(this::decodeToken);
    }

    // Method to prepare the token request
    private void prepareTokenRequest(Exchange exchange) throws Exception {
        LoginRequestDTO loginRequestDTO = exchange.getIn().getBody(LoginRequestDTO.class);

        // Prepare form parameters
        Map<String, String> params = new LinkedHashMap<>();
        params.put("grant_type", "password");
        params.put("username", loginRequestDTO.getUsername());
        params.put("password", loginRequestDTO.getPassword());
        params.put("scope", scope);
        params.put("client_id", clientId);
        params.put("client_secret", clientSecret);

        // URL encode the parameters
        String body = params.entrySet().stream()
                .map(entry -> URLEncoder.encode(entry.getKey(), StandardCharsets.UTF_8) + "=" + URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8))
                .collect(Collectors.joining("&"));

        // Set headers and body for HTTP request
        exchange.getIn().setHeader(Exchange.HTTP_METHOD, "POST");
        exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/x-www-form-urlencoded");
        exchange.getIn().setBody(body);
    }

    // Method to validate token
    private void validateToken(Exchange exchange) {
        String authHeader = exchange.getIn().getHeader("Authorization", String.class);
        String token = authHeader != null ? authHeader.replace("Bearer ", "") : null;

        // Call JwtService to validate the token
        String validationResponse = jwtService.validateTokenWithOracle(token);
        exchange.getIn().setBody(validationResponse);
    }

    // Method to decode token
    private void decodeToken(Exchange exchange) {
        String authHeader = exchange.getIn().getHeader("Authorization", String.class);
        String token = authHeader != null ? authHeader.replace("Bearer ", "") : null;

        // Call DecodeService to decode the token
        Map<String, Object> claims = decodeService.decodeToken(token);
        exchange.getIn().setBody(claims);
    }

    private void logSuccessfulLogin(Exchange exchange) throws JsonProcessingException {
        Map authHeader = exchange.getIn().getBody(Map.class);

        // Call DecodeService to decode the token
        Map<String, Object> claims = decodeService.decodeToken((String) authHeader.get("access_token"));

        String jsonClaims = objectMapper.writeValueAsString(claims);

        UserDTO user = objectMapper.readValue(jsonClaims, UserDTO.class);

        // Extract the IP address from the HTTP headers
        String ipAddress = exchange.getIn().getHeader("X-Forwarded-For", String.class);  // Check for IP in X-Forwarded-For

        user.setIpAddress(ipAddress);

        authLogger.log(LoginLogAction.LOGIN, user);
    }
}
