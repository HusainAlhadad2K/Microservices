package com.digitalchain.iam_service.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

@Service
public class JwtService {

    private static final String JWK_URL = "https://idcs-68d47bf053694691aba4a97e8792a86a.identity.oraclecloud.com:443/admin/v1/SigningCert/jwk";
    private final ObjectMapper objectMapper = new ObjectMapper();

    public String validateTokenWithOracle(String token) {
        try {
            RestTemplate restTemplate = new RestTemplate();

            // Set up the headers with the Bearer token
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(token);

            // Prepare the request entity
            HttpEntity<String> entity = new HttpEntity<>(headers);

            // Make the call to Oracle IDCS service
            ResponseEntity<String> response = restTemplate.exchange(JWK_URL, HttpMethod.GET, entity, String.class);

            // Print the response from Oracle IDCS service
            System.out.println("Oracle IDCS Response: " + response.getBody());

            // Return the response from the Oracle IDCS service as is
            return response.getBody();
        } catch (Exception e) {
            throw new JwtException("Invalid token");
        }
    }

    public String decodeJwt(String token) throws Exception {
        PublicKey publicKey = getPublicKeyFromJwk();

        // Parse the token with the public key
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(publicKey)
                .build()
                .parseClaimsJws(token)
                .getBody();

        // Convert the Claims to a JSON string
        return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(claims);
    }

    private PublicKey getPublicKeyFromJwk() throws Exception {
        RestTemplate restTemplate = new RestTemplate();
        String jwkResponse = restTemplate.getForObject(JWK_URL, String.class);

        // Extract the public key from the JWK (Assuming JWK contains the key in PEM format)
        String certBegin = "-----BEGIN CERTIFICATE-----\n";
        String certEnd = "\n-----END CERTIFICATE-----";
        String pem = jwkResponse.replace(certBegin, "").replace(certEnd, "").replaceAll("\\s", "");
        byte[] encoded = Base64.getDecoder().decode(pem);

        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
        return keyFactory.generatePublic(keySpec);
    }
}
