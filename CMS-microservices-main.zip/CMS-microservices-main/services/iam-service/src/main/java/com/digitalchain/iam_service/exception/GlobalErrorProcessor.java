package com.digitalchain.iam_service.exception;

import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import com.digitalchain.common.dto.ErrorDTO;

import java.util.Date;

@Slf4j
public class GlobalErrorProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);

        // Get the exception type based on the exception class name
        ExceptionType exceptionType = ExceptionType.fromExceptionClass(exception.getClass());

        ExceptionDetails details = exceptionType.getDetails();

        log.error("An error occurred", exception);

        // Set headers
        exchange.getMessage().setHeader(Exchange.HTTP_RESPONSE_CODE, details.getErrorCode());
        exchange.getMessage().setHeader(Exchange.CONTENT_TYPE, "application/json");


        // Create the ErrorDTO response body
        ErrorDTO errorDTO = new ErrorDTO(
                details.getErrorName(),
                exception.getMessage(),
                new Date(),
                "Error Name: " + details.getErrorName() + ", Path: " + exchange.getIn().getHeader(Exchange.HTTP_URI)
        );

        // Set the ErrorDTO object as the body
        exchange.getMessage().setBody(errorDTO);
    }
}