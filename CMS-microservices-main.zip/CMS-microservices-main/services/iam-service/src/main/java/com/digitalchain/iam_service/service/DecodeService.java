package com.digitalchain.iam_service.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.Map;

@Service
public class DecodeService {

    public Map<String, Object> decodeToken(String token) {
        try {
            // Split the JWT into its parts
            String[] parts = token.split("\\.");
            if (parts.length != 3) {
                throw new IllegalArgumentException("Invalid JWT token");
            }

            // Decode the payload (which is the second part)
            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));

            // Convert the payload into a Map
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(payload, Map.class);
        } catch (Exception e) {
            System.err.println("Token decoding failed: " + e.getMessage());
            throw new RuntimeException("Invalid Token", e);
        }
    }
}
