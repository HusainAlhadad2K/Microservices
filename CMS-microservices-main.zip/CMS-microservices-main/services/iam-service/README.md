# IAM Service API

## Overview
This project provides an Identity and Access Management (IAM) service for handling authentication and authorization in the CMS microservices architecture.

## Prerequisites
- **Java 17** or higher
- **Maven** 3.6+
- **Spring Boot** 3.x
- **Postman** (for API testing)
- **Docker** (optional, for containerization)

## Getting Started

### Clone the Repository
```bash
git clone https://github.com/yourusername/iam-service.git
cd iam-service
```

### Build the Project
```bash
mvn clean install
```

### Running the Application
```bash
mvn spring-boot:run
```

## Usage

### Obtain a Token

To obtain a token, make a `POST` request to the `/api/auth/token` endpoint:

**Endpoint**: `/api/auth/token`

**Method**: `POST`

**Content-Type**: `application/x-www-form-urlencoded`

**Parameters**:
- `username`: The username of the user.
- `password`: The password of the user.

**Example Request**:
```
POST http://localhost:8085/api/auth/token
Content-Type: application/x-www-form-urlencoded

username=your_username&password=your_password
```

**Example Response**:
```
{
  "access_token": "your_jwt_token_here",
  "token_type": "Bearer",
  "expires_in": 3600
}
```

### Validate a Token

To validate a token, make a `GET` request to the `/api/auth/validate` endpoint:

**Endpoint**: `/api/auth/validate`

**Method**: `GET`

**Authorization**: Bearer Token

**Example Request**:
```
GET http://localhost:8085/api/auth/validate
Authorization: Bearer your_jwt_token_here
```

**Example Response (Valid Token)**:
```
{
  "keys": [
    {
      "kty": "RSA",
      "x5t#S256": "WJCUZnQmEfaKmfgNW96FWqMeCqSeQuQUbkA-1TTGXts",
      "e": "AQAB",
      "x5t": "vBxdhn3i1po_dhNbjEe2Wyc38vQ",
      "kid": "SIGNING_KEY",
      "x5c": ["..."],
      "key_ops": ["encrypt", "verify", "wrapKey"],
      "alg": "RS256",
      "n": "..."
    }
  ]
}
```

**Example Response (Invalid Token)**:
```
Token Invalid
```

