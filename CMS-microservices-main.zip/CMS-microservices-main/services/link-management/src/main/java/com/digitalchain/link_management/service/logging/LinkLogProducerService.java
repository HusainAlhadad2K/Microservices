package com.digitalchain.link_management.service.logging;

import com.digitalchain.common.dto.links.LinkLogDTO;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LinkLogProducerService {
    @Autowired
    private ProducerTemplate producerTemplate;
    public void sendLinkLog(LinkLogDTO logDTO) {
        // Send the log message to the Kafka topic through the Camel route
        producerTemplate.sendBody("direct:sendLinkLog", logDTO);
    }
}
