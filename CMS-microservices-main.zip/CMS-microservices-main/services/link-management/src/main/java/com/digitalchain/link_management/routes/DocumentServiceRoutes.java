package com.digitalchain.link_management.routes;

import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.link_management.config.BaseRouteBuilder;
import org.apache.camel.Exchange;
import org.apache.hc.client5.http.entity.mime.MultipartEntityBuilder;
import org.apache.hc.core5.http.ContentType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;


import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Component
public class DocumentServiceRoutes extends BaseRouteBuilder {

    @Value("${application.config.document-url}")
    private String documentServiceUrl;
    @Value("${application.config.folder-url}")
    private String folderServiceUrl;

    @Override
    public void configure() throws Exception {
        // Inherit the exception handling from BaseRouteBuilder
        super.configure();


        from("direct:getFileDetails")
                .routeId("getFileDetailsRoute")
                .log("Fetching from document management service")
                .process(this::setAuthorizationHeader)
                .toD(documentServiceUrl + "?fileId=${header.targetId}")
                .unmarshal().json()
                .log("Fetched file details for ID: ${header.targetId}");


        from("direct:getFolderDetails")
                .routeId("getFolderDetailsRoute")
                .log("Fetching from document management service")
                .process(this::setAuthorizationHeader)
                .toD(folderServiceUrl + "/${header.targetId}")
                .unmarshal().json()
                .log("Fetched folder details for ID: ${header.targetId}");

        from("direct:getSubfolders")
                .routeId("getSubfoldersRoute")
                .log("Fetching subfolders for parent folder ID: ${header.parentFolderId}")
                .process(this::setAuthorizationHeader)
                .toD(folderServiceUrl)  // Dynamic URL with parent folder ID
                .unmarshal().json(List.class)  // Assuming response is a list of FolderDTO
                .log("Fetched subfolders for parent folder ID: ${header.parentFolderId}")
                .log("Subfolders: ${body}");

        from("direct:getFiles")
                .routeId("getFilesRoute")
                .log("Fetching files for folder ID: ${header.folderId}")  // Use folderId here
                .process(this::setAuthorizationHeader)
                .toD(documentServiceUrl)  // Dynamic URL with folder ID
                .unmarshal().json(List.class)  // Assuming response is a list of FileDTO
                .log("Fetched files for folder ID: ${header.folderId}")
                .log("Files: ${body}");
        from("direct:downloadFileURL")
                .routeId("downloadFileURLRoute")
                .log("Attempting to download file with file ID: ${header.fileId} and forceDownload: ${header.forceDownload}")
                .process(this::setAuthorizationHeader) // Sets the authorization header if jwtToken is provided
                .toD(documentServiceUrl + "/${header.fileId}?forceDownload=${header.forceDownload}")
                .log("File downloaded successfully for file ID: ${header.fileId}");


        from("direct:downloadFolderURL")
                .routeId("downloadFolderURLRoute")
                .log("downloading folder from document management")
                .process(this::setAuthorizationHeader)
                .toD(folderServiceUrl + "/${header.folderId}/download")
                .convertBodyTo(InputStream.class)
                .log("Folder downloaded for ID: ${header.folderId}");
        from("direct:createFolder")
                .routeId("createFolderRoute")
                .log("Creating folder in document management service")
                .process(this::prepareCreateFolderRequest)  // Call the function for folder creation
                .marshal().json() // Convert the request to JSON
                .toD(folderServiceUrl + "/create") // Send POST request to folder service
                .unmarshal().json() // Convert response to JSON
                .process(this::handleCreateFolderResponse)  // Call the function to handle the response
                .log("Folder created successfully with ID: ${body}");

        from("direct:uploadFile")
                .routeId("uploadFile")
                .log("Uploading file to document management service")
                .process(this::prepareUploadFileRequest)  // Move the process logic to a separate function
                .setHeader(Exchange.HTTP_METHOD, constant("POST"))
                .setHeader(Exchange.CONTENT_TYPE, constant("multipart/form-data"))
                .toD(documentServiceUrl)  // Replace with your document management service URL
                .log("File uploaded successfully to folder ID: ${header.folderId}");

        from("direct:getFolderInfo")
                .routeId("getFolderInfoRoute")
                .log("Fetching folder information from document management service")
                .process(this::setAuthorizationHeader)
                .toD(folderServiceUrl)
                .unmarshal().json()
                .log("Headers: parentFolderId=${header.parentFolderId}, folderName=${header.folderName}, jwtToken=${header.jwtToken}")
                .log("Fetched folder information for folderName: ${header.folderName}")
                .log("Response from document management service: ${body}");

    }

    // Function to set the Authorization header
    private void setAuthorizationHeader(Exchange exchange) {
        // Assuming the token is stored in a header called "jwtToken"
        String jwtToken = exchange.getIn().getHeader("jwtToken", String.class);
        if (jwtToken != null && !jwtToken.isEmpty()) {
            // Set the Authorization header with the JWT token
            exchange.getIn().setHeader("Authorization", "Bearer " + jwtToken);
        }
    }

    private void setFileDownloadHeaders(Exchange exchange) {
        // Set JWT token in Authorization header if provided
        String jwtToken = exchange.getIn().getHeader("jwtToken", String.class);
        if (jwtToken != null && !jwtToken.isEmpty()) {
            exchange.getIn().setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + jwtToken);
        }

        // Ensure fileId and forceDownload headers are set
        UUID fileId = exchange.getIn().getHeader("fileId", UUID.class);
        Boolean forceDownload = exchange.getIn().getHeader("forceDownload", Boolean.class);

        if (fileId == null) {
            throw new IllegalArgumentException("fileId header is required but was not provided.");
        }
        if (forceDownload == null) {
            forceDownload = Boolean.FALSE; // Default to false if forceDownload is not provided
        }

        // Set the headers explicitly
        exchange.getIn().setHeader("fileId", fileId);
        exchange.getIn().setHeader("forceDownload", forceDownload);

        // Log headers for easier tracking during debugging
        log.info("Headers set - fileId: {}, forceDownload: {}, Authorization: {}", fileId, forceDownload, jwtToken != null);
    }


    private void prepareCreateFolderRequest(Exchange exchange) {
        // Retrieve folder name and parent folder ID from the request body
        Map<String, Object> body = exchange.getIn().getBody(Map.class);
        String folderName = (String) body.get("folderName");
        UUID parentFolderId = (UUID) body.get("parentFolderId");

        // Prepare request body for the folder creation
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("folderName", folderName);
        requestBody.put("parentFolderId", parentFolderId);

        // Set the body with folder creation details
        exchange.getIn().setBody(requestBody);

        // Set Authorization header using the shared method
        setAuthorizationHeader(exchange);

        // Set HTTP method as POST
        exchange.getIn().setHeader(Exchange.HTTP_METHOD, "POST");
    }

    private void handleCreateFolderResponse(Exchange exchange) {
        // Extract folder ID from the response (response contains a field "folderId")
        Map<String, Object> responseBody = exchange.getIn().getBody(Map.class);
        String folderIdString = (String) responseBody.get("folderId");

        // Convert the folder ID from String to UUID
        UUID folderId = UUID.fromString(folderIdString);

        // Log the folder creation details
        log.info("Folder created with ID: {} and name: {}", folderId, responseBody.get("folderName"));

        // Set the folderId back into the exchange for further processing
        exchange.getIn().setBody(folderId); // Return folderId as the response body
    }

    private void prepareUploadFileRequest(Exchange exchange) {
        // Call the setAuthorizationHeader to set the JWT token if provided
        setAuthorizationHeader(exchange);

        // Retrieve the InputStream (file data) and headers
        Map<String, Object> formData = exchange.getIn().getBody(Map.class);
        InputStream fileInputStream = (InputStream) formData.get("file");

        // Get the folderId, fileName, and contentType from headers
        String folderId = exchange.getIn().getHeader("folderId", String.class);
        String fileName = exchange.getIn().getHeader("fileName", String.class);
        String contentType = exchange.getIn().getHeader("Content-Type", String.class);

        // Prepare the multipart form data (folderId before file)
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.addTextBody("folderId", folderId, ContentType.TEXT_PLAIN);  // Add folderId first
        builder.addBinaryBody("file", fileInputStream, ContentType.create(contentType), fileName);  // Add file

        // Set the form data in the message body for multipart handling
        exchange.getIn().setBody(builder.build());
    }

}