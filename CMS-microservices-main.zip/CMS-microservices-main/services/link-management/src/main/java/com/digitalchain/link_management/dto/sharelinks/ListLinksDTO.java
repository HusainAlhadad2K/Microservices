package com.digitalchain.link_management.dto.sharelinks;

import com.digitalchain.link_management.enums.AccessType;
import lombok.Data;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Data
public class ListLinksDTO {
    private UUID linkId;
    private UUID targetId;
    private String targetType;
    private String targetName;
    private String sharedBy;
    private AccessType accessType;
    private List<String> specificUsers;
    private Boolean isDownloadAllowed;
    private Boolean isUploadLink;
    private String link;
    private Date createdAt;
    private Date lastAccessedAt;
    private int accessCount;
    private int numberOfUsersAccessed;
}
