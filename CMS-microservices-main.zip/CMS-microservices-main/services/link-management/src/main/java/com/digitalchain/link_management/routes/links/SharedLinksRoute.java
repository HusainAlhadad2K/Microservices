package com.digitalchain.link_management.routes.links;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.link_management.config.BaseRouteBuilder;
import com.digitalchain.link_management.dto.content.FileDownloadDTO;
import com.digitalchain.link_management.dto.content.FolderDownloadDTO;
import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.link_management.dto.sharelinks.LinkDetailsDTO;
import com.digitalchain.link_management.dto.sharelinks.LinksDTO;
import com.digitalchain.link_management.dto.sharelinks.ListLinksDTO;
import com.digitalchain.link_management.dto.sharelinks.UpdateLinkDTO;
import com.digitalchain.link_management.enums.AccessType;
import com.digitalchain.link_management.model.SharedLinks;
import com.digitalchain.link_management.service.links.SharedLinksService;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import java.io.ByteArrayOutputStream;
import java.util.*;

import static jakarta.xml.bind.DatatypeConverter.parseDateTime;

@Component
public class SharedLinksRoute extends BaseRouteBuilder {
    //
    @Autowired
    private SharedLinksService sharedLinksService;

    @Override
    public void configure() throws Exception {
        super.configure();
//
//        // Define REST endpoint for shared links
        rest("/sharing")
                // Define Generate endpoint for generating a shared link with optional password
                .post("/generate")
                .type(LinksDTO.class)
                .description("Generate a new shared link")
                .responseMessage().code(200).message("Shared link generated successfully").responseModel(SharedLinks.class).endResponseMessage()
                .to("direct:generateSharedLink")

                .get("/count")
                .description("Get count of expired and active links, optionally filtered by shared_by")
                .param().name("sharedBy").type(RestParamType.query).dataType("string").description("Filter by user who shared the link").required(false).endParam()
                .responseMessage().code(200).message("Link counts retrieved successfully").endResponseMessage()
                .to("direct:getLinkExpirationCounts")
                .put("/{linkId}")
                .type(UpdateLinkDTO.class)
                .description("Update an existing shared link")
                .responseMessage().code(200).message("Shared link updated successfully").responseModel(SharedLinks.class).endResponseMessage()
                .to("direct:updateSharedLink")

                .get("/{linkId}")
                .description("Get the details of a link")
                .responseMessage().code(200).message("Links details retrieved successfully").responseModel(LinkDetailsDTO.class).endResponseMessage()
                .to("direct:getLinkById")

                .delete("/{linkId}")
                .description("Delete a shared link by ID")
                .responseMessage().code(200).message("Link deleted successfully").responseModel(String.class).endResponseMessage() // We return a success message here
                .responseMessage().code(404).message("Link not found").endResponseMessage()
                .to("direct:deleteSharedLink")

                .get("/all")
                .description("Retrieve all shared links with filters and pagination")
                .param().name("page").type(RestParamType.query).dataType("int").defaultValue("0").description("Page number").required(false).endParam()
                .param().name("size").type(RestParamType.query).dataType("int").defaultValue("10").description("Page size").required(false).endParam()
                .param().name("sortBy").type(RestParamType.query).dataType("string").description("Sort by field").required(false).endParam()
                .param().name("sortDirection").type(RestParamType.query).dataType("string").description("Sort direction (asc/desc)").required(false).endParam()
                .param().name("sharedBy").type(RestParamType.query).dataType("string").description("Filter by the user who shared the link").required(false).endParam()
                .param().name("specificUsers").type(RestParamType.query).dataType("string").description("Filter by specific users (comma-separated)").required(false).endParam()
                .param().name("accessType").type(RestParamType.query).dataType("string").description("Filter by access type (e.g., ANYONE, ALL_USERS)").required(false).endParam()
                .param().name("targetType").type(RestParamType.query).dataType("string").description("Filter by target type (e.g., file, folder)").required(false).endParam()
                .param().name("targetName").type(RestParamType.query).dataType("string").description("Filter by target name (partial match)").required(false).endParam()
                .param().name("isDownloadAllowed").type(RestParamType.query).dataType("boolean").description("Filter by whether download is allowed").required(false).endParam()
                .param().name("isUploadLink").type(RestParamType.query).dataType("boolean").description("Filter by whether it is an upload link or a shared link").required(false).endParam()
                .param().name("isExpired").type(RestParamType.query).dataType("boolean").description("Filter by whether it is an expired link or not").required(false).endParam()
                .param().name("createdAfter").type(RestParamType.query).dataType("string").description("Filter by creation date after (ISO 8601)").required(false).endParam()
                .param().name("createdBefore").type(RestParamType.query).dataType("string").description("Filter by creation date before (ISO 8601)").required(false).endParam()
                .param().name("lastAccessedAfter").type(RestParamType.query).dataType("string").description("Filter by last accessed date after (ISO 8601)").required(false).endParam()
                .param().name("lastAccessedBefore").type(RestParamType.query).dataType("string").description("Filter by last accessed date before (ISO 8601)").required(false).endParam()
                .responseMessage().code(200).message("Shared links retrieved successfully").endResponseMessage()
                .responseMessage().code(400).message("Bad request").endResponseMessage()
                .responseMessage().code(500).message("Unexpected Error").endResponseMessage()
                .to("direct:getAllSharedLinks");

        from("direct:generateSharedLink")
                .routeId("generateSharedLink")
                .process(this::handleGenerateSharedLink)  // Call the separate method to handle the process
                .log("Returning response: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
        from("direct:getLinkExpirationCounts")
                .routeId("getLinkExpirationCounts")
                .process(this::getLinkExpirationCounts)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        // Route to process the request in the direct:getLinkById route
        from("direct:getLinkById")
                .routeId("getLinkById")
                .process(this::getLinkById)
                .log("Returning response: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
        // Route to handle updating a shared link
        from("direct:updateSharedLink")
                .routeId("updateSharedLink")
                .process(this::updateSharedLink)
                .log("Returning response: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
        from("direct:deleteSharedLink")
                .routeId("deleteSharedLink")
                .process(this::deleteSharedLink)
                .setBody(simple("Link with ID ${header.linkId} deleted successfully"))
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .end();

        from("direct:getAllSharedLinks")
                .routeId("getAllSharedLinks")
                .process(this::handleGetAllSharedLinks)  // Call the separate method to handle the process
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
    }
    private Date parseDate(String dateStr) {
        try {
            return dateStr != null ? parseDateTime(dateStr).getTime() : null;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }


    private void handleGenerateSharedLink(Exchange exchange) throws Exception {

            // Retrieve LinksDTO from the message body
            LinksDTO linksDTO = exchange.getIn().getBody(LinksDTO.class);

            // Retrieve UserDTO from the exchange properties
            UserDTO user = exchange.getProperty("user", UserDTO.class);

            // Set shared_by using the user_id from UserDTO
            linksDTO.setShared_by(user.getUser_id());

            // Call service to generate the shared link
            SharedLinks sharedLink = sharedLinksService.generateSharedLink(linksDTO);

            // Set the shared link as the response body
            exchange.getIn().setBody(sharedLink);


        }
    private void getLinkExpirationCounts(Exchange exchange) {
        String sharedBy = exchange.getIn().getHeader("sharedBy", String.class);
        Map<String, Long> linkCounts = sharedLinksService.getLinkExpirationCounts(sharedBy);
        exchange.getIn().setBody(linkCounts);
    }


    private void getLinkById(Exchange exchange) {
        String linkIdStr = exchange.getIn().getHeader("linkId", String.class);
        UUID linkId = UUID.fromString(linkIdStr);

        // Get the shared link details using the service
        var sharedLinkDetails = sharedLinksService.getLinkById(linkId);

        // Set the response body
        exchange.getIn().setBody(sharedLinkDetails);
    }
    private void updateSharedLink(Exchange exchange) {
        UUID linkId = UUID.fromString(exchange.getIn().getHeader("linkId", String.class)); // Corrected to "linkId"
        UpdateLinkDTO updateLinkDTO = exchange.getIn().getBody(UpdateLinkDTO.class);
        SharedLinks updatedLink = sharedLinksService.updateSharedLink(linkId, updateLinkDTO);
        exchange.getIn().setBody(updatedLink);
    }
    private String deleteSharedLink(Exchange exchange) {
        String linkIdStr = exchange.getIn().getHeader("linkId", String.class);

        UUID linkId = UUID.fromString(linkIdStr);
        String result = sharedLinksService.deleteSharedLinkById(linkId);

        if (result == null) {
            throw new IllegalArgumentException("Invalid password or link not found");
        } else {
            return result; // Return the successful deletion message including the linkId
        }
    }


    private void handleGetAllSharedLinks(Exchange exchange) {
        int page = exchange.getIn().getHeader("page", 0, Integer.class);
        int size = exchange.getIn().getHeader("size", 10, Integer.class);
        String sortBy = exchange.getIn().getHeader("sortBy", "created_at", String.class);
        String sortDirection = exchange.getIn().getHeader("sortDirection", "desc", String.class);
        AccessType accessType = exchange.getIn().getHeader("accessType", AccessType.class);
        String sharedBy = exchange.getIn().getHeader("sharedBy", String.class);
        String targetType = exchange.getIn().getHeader("targetType", String.class);
        String targetName = exchange.getIn().getHeader("targetName", String.class);
        Boolean isDownloadAllowed = exchange.getIn().getHeader("isDownloadAllowed", Boolean.class);
        Boolean isUploadLink = exchange.getIn().getHeader("isUploadLink", Boolean.class);
        Boolean isExpired = exchange.getIn().getHeader("isExpired", Boolean.class);
        Date createdAfter = parseDate(exchange.getIn().getHeader("createdAfter", String.class));
        Date createdBefore = parseDate(exchange.getIn().getHeader("createdBefore", String.class));
        Date lastAccessedAfter = parseDate(exchange.getIn().getHeader("lastAccessedAfter", String.class));
        Date lastAccessedBefore = parseDate(exchange.getIn().getHeader("lastAccessedBefore", String.class));
        String specificUsersStr = exchange.getIn().getHeader("specificUsers", String.class);
        List<String> specificUsers = specificUsersStr != null ? Arrays.asList(specificUsersStr.split(",")) : null;

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.fromString(sortDirection), sortBy));

        // Call the service method
        Page<ListLinksDTO> sharedLinksPage = sharedLinksService.getFilteredLinks(
                accessType, targetType, targetName, isDownloadAllowed, isUploadLink, isExpired, sharedBy, specificUsers,
                createdAfter, createdBefore, lastAccessedAfter, lastAccessedBefore, pageable
        );

        // Set the response body
        exchange.getIn().setBody(sharedLinksPage);
    }


}