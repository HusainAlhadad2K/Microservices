package com.digitalchain.link_management.dto.sharelinks;

import com.digitalchain.link_management.enums.AccessType;
import com.digitalchain.link_management.enums.ExpirationType;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Data
public class LinkDetailsDTO {
    private UUID linkId;
    private UUID targetId;
    private String targetType;
    private String targetName;
    private String sharedBy;
    private AccessType accessType;
    private List<String> specificUsers;
    private String link;
    private Boolean isDownloadAllowed;
    private int accessCount;
    private Integer maxAccessCount;
    private ExpirationType expirationType;
    private Boolean isUploadLink;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date expirationDate;

    private Boolean notifyOnClick;
    private Set<String> usersAccessed;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date createdAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date updatedAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date lastAccessedAt;
}
