
package com.digitalchain.link_management.service.links;
import com.digitalchain.common.dto.LocationDTO;
import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.link_management.dto.content.FileDownloadDTO;
import com.digitalchain.link_management.dto.content.FolderDownloadDTO;
import com.digitalchain.link_management.dto.sharelinks.LinkDetailsDTO;
import com.digitalchain.link_management.dto.sharelinks.LinksDTO;
import com.digitalchain.link_management.dto.sharelinks.ListLinksDTO;
import com.digitalchain.link_management.dto.sharelinks.UpdateLinkDTO;
import com.digitalchain.link_management.enums.AccessType;
import com.digitalchain.link_management.enums.ExpirationType;
import com.digitalchain.link_management.exception.links.CreateLinkException;
import com.digitalchain.link_management.exception.links.UpdateLinkException;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.link_management.exception.ResourceNotFoundException;
import com.digitalchain.link_management.exception.links.SharedLinkAccessException;
//import com.digitalchain.link_management.kafka.ShareLinkGeneration;
//import com.digitalchain.link_management.kafka.ShareLinkProducer;
import com.digitalchain.link_management.model.SharedLinks;
import com.digitalchain.link_management.repository.SharedLinksRepository;
import com.digitalchain.link_management.service.content.DocumentService;
import com.digitalchain.link_management.service.content.JwtTokenService;
import com.digitalchain.link_management.utils.LinkLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.CountOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.support.PageableExecutionUtils;

import static com.netflix.spectator.api.Statistic.count;

@Slf4j
@Service
public class SharedLinksService {
    @Autowired
    private SharedLinksRepository sharedLinksRepository;
    @Autowired
    private MongoTemplate mongoTemplate;
    // Use Camel's ProducerTemplate to send messages to Kafka
    @Autowired
    private ProducerTemplate producerTemplate;
    private static final String TOPIC = "shared-link-topic";
    @Autowired
    private DocumentService documentService;
    @Autowired
    private LinkLogger linkLogger;
    @Autowired
    private JwtTokenService jwtTokenService;


    @Value("${kafka.topic}")
    private String kafkaTopic;

    public Map<String, Long> getLinkExpirationCounts(String sharedBy) {
        Date now = new Date();

        // Define aggregation for expired links
        MatchOperation expiredMatch = Aggregation.match(
                Criteria.where("shared_by").is(sharedBy).andOperator(
                        new Criteria().orOperator(
                                Criteria.where("expirationType").is(ExpirationType.ON_DATE).and("expiration_date").lt(now),
                                Criteria.where("expirationType").is(ExpirationType.ON_NUMBER_OF_CLICKS).and("access_count").gte("max_access_count")
                        )
                )
        );
        CountOperation countExpired = Aggregation.count().as("expiredCount");
        Aggregation expiredAggregation = Aggregation.newAggregation(expiredMatch, countExpired);

        // Execute the aggregation for expired links
        AggregationResults<Map> expiredResults = mongoTemplate.aggregate(expiredAggregation, SharedLinks.class, Map.class);
        Long expiredCount = expiredResults.getUniqueMappedResult() != null
                ? ((Number) expiredResults.getUniqueMappedResult().get("expiredCount")).longValue()
                : 0L;

        // Define aggregation for active links
        MatchOperation activeMatch = Aggregation.match(
                Criteria.where("shared_by").is(sharedBy).andOperator(
                        new Criteria().orOperator(
                                Criteria.where("expirationType").is(ExpirationType.NONE),
                                Criteria.where("expirationType").is(ExpirationType.ON_DATE).and("expiration_date").gt(now),
                                Criteria.where("expirationType").is(ExpirationType.ON_NUMBER_OF_CLICKS).and("access_count").lt("max_access_count")
                        )
                )
        );
        CountOperation countActive = Aggregation.count().as("activeCount");
        Aggregation activeAggregation = Aggregation.newAggregation(activeMatch, countActive);

        // Execute the aggregation for active links
        AggregationResults<Map> activeResults = mongoTemplate.aggregate(activeAggregation, SharedLinks.class, Map.class);
        Long activeCount = activeResults.getUniqueMappedResult() != null
                ? ((Number) activeResults.getUniqueMappedResult().get("activeCount")).longValue()
                : 0L;

        // Return counts in a map
        Map<String, Long> counts = new HashMap<>();
        counts.put("expiredCount", expiredCount);
        counts.put("activeCount", activeCount);

        return counts;
    }

    public SharedLinks generateSharedLink(LinksDTO linksDTO) throws Exception {
        String jwtToken = jwtTokenService.generateJwtToken();
        // Fetch the JWT access token
        if (linksDTO.getTarget_id() == null) {
            throw CreateLinkException.targetIdRequired();  // Custom exception for null target_id
        }

        // Fetch the target details based on the target type
        FileDTO fileDTO = null;
        FolderDTO folderDTO = null;

        // Determine the target type and fetch the corresponding details
        if ("file".equalsIgnoreCase(linksDTO.getTarget_type())) {
            fileDTO = documentService.getFileById(linksDTO.getTarget_id(), jwtToken);
        } else if ("folder".equalsIgnoreCase(linksDTO.getTarget_type())) {
            folderDTO = documentService.getFolderById(linksDTO.getTarget_id(), jwtToken);
        } else {
            throw CreateLinkException.invalidTargetType();
        }

        // Set the target name based on the type
        String targetName = fileDTO != null ? fileDTO.getFileName() : folderDTO.getFolderName();

        // Handle the link creation
        String linkIdentifier = UUID.randomUUID().toString();

        // Include target name in link if requested
        String link;
        if (Boolean.TRUE.equals(linksDTO.getIncludeTargetNameInLink())) {
            link = targetName + "-" + Base64.getUrlEncoder().encodeToString(linkIdentifier.getBytes(StandardCharsets.UTF_8));
        } else {
            link = Base64.getUrlEncoder().encodeToString(linkIdentifier.getBytes(StandardCharsets.UTF_8));
        }

        // Handle password protection
        String hashedPassword = null;
        if (linksDTO.getAccessType() == AccessType.ANYONE_WITH_PASSWORD) {
            if (linksDTO.getPassword() != null && !linksDTO.getPassword().isEmpty()) {
                hashedPassword = BCrypt.hashpw(linksDTO.getPassword(), BCrypt.gensalt());
            } else {
                throw CreateLinkException.passwordRequired();
            }
        } else if (linksDTO.getAccessType() == AccessType.ANYONE) {
            // No password required
        } else if (linksDTO.getAccessType() == AccessType.ALL_USERS || linksDTO.getAccessType() == AccessType.SPECIFIC_USERS) {
            // For internal access types, password is not applicable
            if (linksDTO.getPassword() != null && !linksDTO.getPassword().isEmpty()) {
                throw CreateLinkException.passwordNotAllowedForAccessType();
            }
        } else {
            throw CreateLinkException.invalidAccessType();
        }

        // Handle expiration
        ExpirationType expirationType = linksDTO.getExpirationType();
        Date expirationDate = null;
        Integer maxAccessCount = null;

        if (expirationType == ExpirationType.ON_DATE) {
            if (linksDTO.getExpiration_date() != null && !linksDTO.getExpiration_date().isEmpty()) {
                expirationDate = Date.from(Instant.parse(linksDTO.getExpiration_date()));
            } else {
                throw CreateLinkException.expirationDateRequired();
            }
        } else if (expirationType == ExpirationType.ON_NUMBER_OF_CLICKS) {
            if (linksDTO.getMax_access_count() != null && linksDTO.getMax_access_count() > 0) {
                maxAccessCount = linksDTO.getMax_access_count();
            } else {

                throw CreateLinkException.maxAccessCountRequired();
            }
        } else if (expirationType == ExpirationType.NONE) {
            // No expiration, do nothing
        } else {
            throw CreateLinkException.invalidExpirationType();
        }

        // Validate specific users if accessType is SPECIFIC_USERS
        List<String> specificUsers = null;
        if (linksDTO.getAccessType() == AccessType.SPECIFIC_USERS) {
            if (linksDTO.getSpecificUsers() != null && !linksDTO.getSpecificUsers().isEmpty()) {
                specificUsers = linksDTO.getSpecificUsers();
            } else {
                throw CreateLinkException.specificUsersRequired();
            }
        }

        // Build the SharedLinks entity
        SharedLinks sharedLink = SharedLinks.builder()
                .link_id(UUID.randomUUID())
                .isUploadLink(false) // Mark as a shared link
                .target_id(linksDTO.getTarget_id())
                .target_type(linksDTO.getTarget_type())
                .target_name(targetName)
                .includeTargetNameInLink(linksDTO.getIncludeTargetNameInLink())
                .shared_by(linksDTO.getShared_by())
                // .message(linksDTO.getMessage())
                .accessType(linksDTO.getAccessType())
                .specificUsers(specificUsers)
                .link(link)
                .isDownloadAllowed(linksDTO.getIsDownloadAllowed())
                .password(hashedPassword)
                .expirationType(expirationType)
                .expiration_date(expirationDate)
                .max_access_count(maxAccessCount)
                .notifyOnClick(linksDTO.getNotifyOnClick())
                .access_count(0) // Initialize access count
                .created_at(new Date())
                .build();

        // Save the shared link to the database
        sharedLinksRepository.save(sharedLink);


        return sharedLink;
    }


// Serialize ShareLinkGeneration object to JSON
    //   ShareLinkGeneration message = new ShareLinkGeneration(
    //           linksDTO.getTarget_type(),
    //            targetName,
    //            linksDTO.getShared_by()
    //    );

    //  try {
    //       ObjectMapper objectMapper = new ObjectMapper();
    //      String messageJson = objectMapper.writeValueAsString(message); // Serialize to JSON
//
    // Send JSON message to Kafka
    //        producerTemplate.sendBody("kafka:" + kafkaTopic, messageJson);
    //         System.out.println("Publishing message to Kafka topic: " + kafkaTopic);
    //      } catch (Exception e) {
    //       throw new RuntimeException("Error serializing message to JSON", e);
    //   }

    public SharedLinks updateSharedLink(UUID linkId, UpdateLinkDTO updateLinkDTO) {
        SharedLinks sharedLink = sharedLinksRepository.findById(linkId)
                .orElseThrow(() -> SharedLinkAccessException.linkNotFound());

        // Update accessType if provided, or keep the existing one
        AccessType currentAccessType = sharedLink.getAccessType();
        if (updateLinkDTO.getAccessType() != null) {
            currentAccessType = updateLinkDTO.getAccessType();
            sharedLink.setAccessType(currentAccessType);

            // Adjust password requirements based on the new accessType
            if (currentAccessType == AccessType.ANYONE_WITH_PASSWORD) {
                if (updateLinkDTO.getNewPassword() != null && !updateLinkDTO.getNewPassword().isEmpty()) {
                    String hashedPassword = BCrypt.hashpw(updateLinkDTO.getNewPassword(), BCrypt.gensalt());
                    sharedLink.setPassword(hashedPassword);
                } else {
                    throw UpdateLinkException.passwordRequiredForAccessType();
                }
            } else {
                // For other access types, remove the password if it exists
                sharedLink.setPassword(null);
            }
        }

        // Handle specific users if current access type is SPECIFIC_USERS
        if (currentAccessType == AccessType.SPECIFIC_USERS) {
            if (updateLinkDTO.getSpecificUsers() != null && !updateLinkDTO.getSpecificUsers().isEmpty()) {
                sharedLink.setSpecificUsers(updateLinkDTO.getSpecificUsers());
            } else if (sharedLink.getSpecificUsers() == null || sharedLink.getSpecificUsers().isEmpty()) {
                throw UpdateLinkException.specificUsersRequired();
            }
        } else {
            // Clear specific users if accessType is not SPECIFIC_USERS
            sharedLink.setSpecificUsers(null);
        }

        // Update expirationType and related fields
        if (updateLinkDTO.getExpirationType() != null) {
            sharedLink.setExpirationType(updateLinkDTO.getExpirationType());

            if (updateLinkDTO.getExpirationType() == ExpirationType.ON_DATE) {
                if (updateLinkDTO.getExpiration_date() != null && !updateLinkDTO.getExpiration_date().isEmpty()) {
                    try {
                        sharedLink.setExpiration_date(Date.from(Instant.parse(updateLinkDTO.getExpiration_date())));
                        sharedLink.setMax_access_count(null); // Clear max access count
                    } catch (DateTimeParseException e) {
                        throw UpdateLinkException.invalidExpirationDateFormat();
                    }
                } else {
                    throw UpdateLinkException.expirationDateRequired();
                }
            } else if (updateLinkDTO.getExpirationType() == ExpirationType.ON_NUMBER_OF_CLICKS) {
                if (updateLinkDTO.getMax_access_count() != null && updateLinkDTO.getMax_access_count() > 0) {
                    sharedLink.setMax_access_count(updateLinkDTO.getMax_access_count());
                    sharedLink.setExpiration_date(null); // Clear expiration date
                } else {
                    throw UpdateLinkException.maxAccessCountRequired();
                }
            } else if (updateLinkDTO.getExpirationType() == ExpirationType.NONE) {
                sharedLink.setExpiration_date(null);
                sharedLink.setMax_access_count(null);
            } else {
                throw UpdateLinkException.invalidExpirationType();
            }
        }

        // Update isDownloadAllowed
        if (updateLinkDTO.getIsDownloadAllowed() != null) {
            sharedLink.setIsDownloadAllowed(updateLinkDTO.getIsDownloadAllowed());
        }
        if (updateLinkDTO.getNotifyOnClick() != null) {
            sharedLink.setNotifyOnClick(updateLinkDTO.getNotifyOnClick());
        }

        // Update message if provided
        //if (updateLinkDTO.getMessage() != null) {
        //     sharedLink.setMessage(updateLinkDTO.getMessage());
        //  }

        // Set updated_at field to the current date
        sharedLink.setUpdated_at(new Date());

        // Save the updated link
        return sharedLinksRepository.save(sharedLink);
    }

    public String deleteSharedLinkById(UUID linkId) {
        Optional<SharedLinks> sharedLinkOpt = sharedLinksRepository.findById(linkId);

        if (sharedLinkOpt.isEmpty()) {
            throw SharedLinkAccessException.linkNotFound();
        }

        // You can add any additional password validation logic here if needed.

        sharedLinksRepository.deleteById(linkId);  // Delete the link

        // Return the linkId as a string to confirm successful deletion
        return "Link with ID " + linkId.toString() + " deleted successfully";
    }

    // Method to filter and paginate shared links based on provided criteria
    public Page<ListLinksDTO> getFilteredLinks(AccessType accessType, String targetType, String targetName,
                                               Boolean isDownloadAllowed, Boolean isUploadLink, Boolean isExpired,
                                               String sharedBy, List<String> specificUsers, Date createdAfter, Date createdBefore,
                                               Date lastAccessedAfter, Date lastAccessedBefore, Pageable pageable) {

        Query query = new Query();

        // Apply filters if provided
        if (accessType != null) query.addCriteria(Criteria.where("accessType").is(accessType));
        if (targetType != null) query.addCriteria(Criteria.where("target_type").is(targetType));
        if (targetName != null) query.addCriteria(Criteria.where("target_name").regex(targetName, "i"));
        if (isDownloadAllowed != null) query.addCriteria(Criteria.where("isDownloadAllowed").is(isDownloadAllowed));
        if (isUploadLink != null) query.addCriteria(Criteria.where("isUploadLink").is(isUploadLink));
        if (sharedBy != null && !sharedBy.isEmpty()) query.addCriteria(Criteria.where("shared_by").is(sharedBy));
        if (specificUsers != null && !specificUsers.isEmpty())
            query.addCriteria(Criteria.where("specificUsers").in(specificUsers));
        if (createdAfter != null && createdBefore != null)
            query.addCriteria(Criteria.where("created_at").gte(createdAfter).lte(createdBefore));
        if (lastAccessedAfter != null && lastAccessedBefore != null)
            query.addCriteria(Criteria.where("lastAccessedAt").gte(lastAccessedAfter).lte(lastAccessedBefore));

        // Add expiration criteria based on `isExpired` flag
        Date now = new Date();
        if (isExpired != null) {
            if (isExpired) {
                // Expired links: either expired by date or by max access count
                query.addCriteria(new Criteria().orOperator(
                        Criteria.where("expirationType").is(ExpirationType.ON_DATE).and("expiration_date").lt(now),
                        Criteria.where("expirationType").is(ExpirationType.ON_NUMBER_OF_CLICKS).and("access_count").gte("max_access_count")
                ));
            } else {
                // Active (non-expired) links: not expired by date or by max access count
                query.addCriteria(new Criteria().orOperator(
                        Criteria.where("expirationType").is(ExpirationType.NONE),
                        Criteria.where("expirationType").is(ExpirationType.ON_DATE).and("expiration_date").gt(now),
                        Criteria.where("expirationType").is(ExpirationType.ON_NUMBER_OF_CLICKS).and("access_count").lt("max_access_count")
                ));
            }
        }

        // Pagination and sorting
        query.with(pageable);

        // Execute query and count
        List<SharedLinks> sharedLinksList = mongoTemplate.find(query, SharedLinks.class);
        long count = mongoTemplate.count(query.skip(-1).limit(-1), SharedLinks.class);

        // Convert results to DTOs
        List<ListLinksDTO> dtoList = sharedLinksList.stream().map(this::convertToDTO).collect(Collectors.toList());

        // Return paginated response
        return new PageImpl<>(dtoList, pageable, count);
    }



    private ListLinksDTO convertToDTO(SharedLinks sharedLink) {
        // Convert the entity to a DTO
        ListLinksDTO dto = new ListLinksDTO();
        dto.setLinkId(sharedLink.getLink_id());
        dto.setTargetId(sharedLink.getTarget_id());
        dto.setTargetType(sharedLink.getTarget_type());
        dto.setTargetName(sharedLink.getTarget_name());
        dto.setSharedBy(sharedLink.getShared_by());
        dto.setAccessType(sharedLink.getAccessType());
        dto.setSpecificUsers(sharedLink.getSpecificUsers());
        dto.setIsDownloadAllowed(sharedLink.getIsDownloadAllowed());
        dto.setIsUploadLink(sharedLink.getIsUploadLink());
        dto.setLink(sharedLink.getLink());
        dto.setSharedBy(sharedLink.getShared_by());
        dto.setSpecificUsers(sharedLink.getSpecificUsers());
        dto.setCreatedAt(sharedLink.getCreated_at());
        dto.setLastAccessedAt(sharedLink.getLast_accessed_at());
        dto.setAccessCount(sharedLink.getAccess_count());
        dto.setNumberOfUsersAccessed(sharedLink.getUsers_accessed() != null ? sharedLink.getUsers_accessed().size() : 0);
        return dto;
    }
    public LinkDetailsDTO getLinkById(UUID linkId) {
        // Find the link by ID from the repository
        SharedLinks sharedLink = sharedLinksRepository.findById(linkId)
                .orElseThrow(() -> SharedLinkAccessException.linkNotFound());

        // Map the SharedLinks entity to the LinkDetailsDTO
        LinkDetailsDTO dto = new LinkDetailsDTO();
        dto.setLinkId(sharedLink.getLink_id());
        dto.setTargetId(sharedLink.getTarget_id());
        dto.setTargetType(sharedLink.getTarget_type());
        dto.setIsUploadLink(sharedLink.getIsUploadLink());
        dto.setTargetName(sharedLink.getTarget_name());
        dto.setSharedBy(sharedLink.getShared_by());
        dto.setAccessType(sharedLink.getAccessType());
        dto.setSpecificUsers(sharedLink.getSpecificUsers());
        dto.setLink(sharedLink.getLink());
        dto.setIsDownloadAllowed(sharedLink.getIsDownloadAllowed());
        dto.setAccessCount(sharedLink.getAccess_count());
        dto.setMaxAccessCount(sharedLink.getMax_access_count());
        dto.setExpirationType(sharedLink.getExpirationType());
        dto.setExpirationDate(sharedLink.getExpiration_date());
        dto.setNotifyOnClick(sharedLink.getNotifyOnClick());
        dto.setUsersAccessed(sharedLink.getUsers_accessed());
        dto.setCreatedAt(sharedLink.getCreated_at());
        dto.setUpdatedAt(sharedLink.getUpdated_at());
        dto.setLastAccessedAt(sharedLink.getLast_accessed_at());
        return dto;
    }

  }