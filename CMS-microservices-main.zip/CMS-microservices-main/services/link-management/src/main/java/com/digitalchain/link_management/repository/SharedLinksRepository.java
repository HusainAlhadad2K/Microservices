package com.digitalchain.link_management.repository;

import com.digitalchain.link_management.model.SharedLinks;
import com.digitalchain.link_management.enums.AccessType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface SharedLinksRepository extends MongoRepository<SharedLinks, UUID> {

    Optional<SharedLinks> findByLink(String link);

}