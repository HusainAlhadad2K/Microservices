package com.digitalchain.link_management.config;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.springframework.stereotype.Component;

@Component
public class BaseRouteBuilder extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        // Global exception handling for any Throwable
        onException(Throwable.class)
                .log(LoggingLevel.ERROR, "Exception caught: ${exception.message}")
                .to("direct:error")
                .handled(true);

        // Intercept all REST API requests except the specific download endpoints
        interceptFrom("rest:*")
                .log("Intercepting request for JWT validation")
                .process(exchange -> {
                    // Get the request URI or path to check if it matches the excluded endpoints
                    String uri = exchange.getIn().getHeader(Exchange.HTTP_URI, String.class);
                    String path = exchange.getIn().getHeader(Exchange.HTTP_PATH, String.class);
                    String accessType = exchange.getProperty("accessType", String.class); // Check if accessType is passed
                    // Log URI and path for debugging
                    log.info("Intercepting URI: " + uri);
                    log.info("Intercepting Path: " + path);

                    // Check if the path matches the specific endpoints to exclude JWT validation
                    if ((path != null && (
                            path.equals("/sharing/downloadfile") ||
                                    path.equals("/sharing/downloadfolder") ||
                                    path.equals("/sharing/uploadfolder") ||    // Exclude upload folder creation
                                    path.equals("/sharing/uploadfile")  ||    // Exclude file upload
                                    path.equals("sharing/access/any")
                    )) ||
                            (uri != null && (
                                    uri.contains("/sharing/downloadfile") ||
                                            uri.contains("/sharing/downloadfolder") ||
                                            uri.contains("/sharing/uploadfolder") ||   // Exclude upload folder creation
                                            uri.contains("/sharing/uploadfile")  ||  // Exclude file upload
                                            uri.contains("sharing/access/any")
                            ))) {
                        log.info("Skipping JWT validation for excluded endpoint: " + path);
                        return; // Skip JWT validation for the specific endpoints
                    }

                    // Perform JWT validation for all other endpoints
                    try {
                        exchange.getContext().createProducerTemplate().send("direct:validateJwt", exchange);
                    } catch (Exception e) {
                        // Handle validation failure; log or process as necessary
                        throw new Exception("JWT validation failed during intercept: " + e.getMessage(), e);
                    }
                });
    }
}
