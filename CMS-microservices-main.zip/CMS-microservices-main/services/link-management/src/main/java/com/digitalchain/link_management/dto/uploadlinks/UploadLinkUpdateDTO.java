package com.digitalchain.link_management.dto.uploadlinks;

import com.digitalchain.link_management.enums.ExpirationType;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UploadLinkUpdateDTO {
    private String expiration_date;   // Optional, new expiration date in ISO 8601 format
    private ExpirationType expirationType; // 'ON_DATE', 'NONE'
    private Boolean notifyOnUpload;   // If true, notify the creator when someone uploads
}
