package com.digitalchain.link_management.dto.content;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.ByteArrayOutputStream;


@Data // Generates getters, setters, toString, equals, and hashCode methods
@NoArgsConstructor // Generates a no-argument constructor
@AllArgsConstructor // Generates a constructor with all fields as arguments
public class FolderDownloadDTO {
    private ByteArrayOutputStream byteArrayOutputStream;
    private String folderName;
    private String folderType;

}
