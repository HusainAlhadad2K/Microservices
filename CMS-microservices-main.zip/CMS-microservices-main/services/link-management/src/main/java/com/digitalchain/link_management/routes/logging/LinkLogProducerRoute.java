package com.digitalchain.link_management.routes.logging;

import com.digitalchain.link_management.config.BaseRouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class LinkLogProducerRoute extends BaseRouteBuilder {
    @Override
    public void configure() throws Exception {
        super.configure();
        // Kafka Producer route for sending log messages to Kafka topic
        from("direct:sendLinkLog")
                .routeId("sendLinkLogRoute")
                .marshal().json()  // Convert the object to JSON
                .to("kafka:{{link.activity.logging.topic}}?brokers={{camel.component.kafka.brokers}}")
                .log("Sent message to Kafka: ${body}");
    }
}
