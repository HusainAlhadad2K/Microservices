package com.digitalchain.link_management.dto.uploadlinks;

import lombok.*;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UploadLinkDTO {

    private UUID folder_id; // ID of the folder for which the upload link is generated

    private String expiration_date; // Expiration date for the upload link, if any

    private Boolean createSeparateFolder; // Option to create a separate folder for each uploader

    private Boolean notifyOnUpload; // Option to notify the user when someone uploads

    private Boolean linkExpires; // Determines if the link should expire

    private String shared_by;

}
