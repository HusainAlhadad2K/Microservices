package com.digitalchain.link_management.service.links;

import com.digitalchain.common.dto.LocationDTO;
import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.link_management.dto.content.FileDownloadDTO;
import com.digitalchain.link_management.dto.content.FolderDownloadDTO;
import com.digitalchain.link_management.enums.AccessType;
import com.digitalchain.link_management.enums.ExpirationType;
import com.digitalchain.link_management.exception.ResourceNotFoundException;
import com.digitalchain.link_management.exception.links.SharedLinkAccessException;
import com.digitalchain.link_management.model.SharedLinks;
import com.digitalchain.link_management.repository.SharedLinksRepository;
import com.digitalchain.link_management.service.content.DocumentService;
import com.digitalchain.link_management.service.content.JwtTokenService;
import com.digitalchain.link_management.utils.LinkLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Service
public class AccessLinksService {
    @Autowired
    private SharedLinksRepository sharedLinksRepository;
    @Autowired
    private DocumentService documentService;
    @Autowired
    private LinkLogger linkLogger;
    @Autowired
    private JwtTokenService jwtTokenService;
    @Autowired
    private ProducerTemplate producerTemplate;
    public Object accessResourceByAnyone(String link, String password, UUID parentFolderId, UserDTO user) {
        SharedLinks sharedLink = sharedLinksRepository.findByLink(link)
                .orElseThrow(() -> SharedLinkAccessException.linkNotFound());

        // Default parentFolderId to target_id if not provided (null or invalid)
        if (parentFolderId == null) {
            parentFolderId = sharedLink.getTarget_id();
            log.debug("this is the parentFolderid");
        }

        // Access Type Handling for ANYONE and ANYONE_WITH_PASSWORD
        AccessType accessType = sharedLink.getAccessType();
        switch (accessType) {
            case ANYONE:
                // No restrictions, skip JWT validation
                break;
            case ANYONE_WITH_PASSWORD:
                // Validate password if required
                if (sharedLink.getPassword() != null && !sharedLink.getPassword().isEmpty()) {
                    if (password == null || password.isEmpty()) {
                        throw SharedLinkAccessException.passwordRequired();
                    }
                    if (!BCrypt.checkpw(password, sharedLink.getPassword())) {
                        throw SharedLinkAccessException.invalidPassword();
                    }
                }
                break;
            default:
                throw new RuntimeException("Invalid access type for this method.");
        }
        // Call the Camel route to get the location
        Exchange result = producerTemplate.request("direct:getLocation", exchange -> {
            exchange.getIn().setHeader("ipAddress", user.getIpAddress());  // Set the IP address
        });

        // Map the Camel route result to LocationDTO
        LocationDTO location = new LocationDTO();
        location.setCity(result.getIn().getHeader("city", String.class));
        location.setCountry(result.getIn().getHeader("country", String.class));

        // Log the access event with the location details
        linkLogger.log(sharedLink, user, location);
        // Call the combined access handling logic
        return accessResourceByLink(sharedLink, parentFolderId);
    }
    public Object accessResourceByUsers(String link, UserDTO user, UUID parentFolderId) {

        String currentUserId = user != null ? user.getUser_id() : null;

        SharedLinks sharedLink = sharedLinksRepository.findByLink(link)
                .orElseThrow(() -> SharedLinkAccessException.linkNotFound());

        // Default parentFolderId to target_id if not provided
        if (parentFolderId == null) {
            parentFolderId = sharedLink.getTarget_id();
        }

        // Access Type Handling for ALL_USERS and SPECIFIC_USERS
        AccessType accessType = sharedLink.getAccessType();
        switch (accessType) {
            case ALL_USERS:
                // Validate JWT token (currentUserId must not be null)
                if (currentUserId == null || currentUserId.isEmpty()) {
                    throw SharedLinkAccessException.authenticationRequired();
                }
                break;
            case SPECIFIC_USERS:
                // Validate JWT token and ensure user is either the sharedBy user or in the specificUsers list
                if (currentUserId == null || currentUserId.isEmpty()) {
                    throw SharedLinkAccessException.authenticationRequired();
                }

                // Check if the user is the one who shared the link
                boolean isSharedByUser = sharedLink.getShared_by().equals(currentUserId);

                // Check if the user is in the specificUsers list
                boolean isSpecificUser = sharedLink.getSpecificUsers() != null && sharedLink.getSpecificUsers().contains(currentUserId);

                // If the user is neither the sharedBy user nor a specific user, deny access
                if (!isSharedByUser && !isSpecificUser) {
                    throw SharedLinkAccessException.accessDenied();
                }
                break;
            default:
                throw new RuntimeException("Invalid access type for this method.");
        }
        // Call the Camel route to get the location
        Exchange result = producerTemplate.request("direct:getLocation", exchange -> {
            exchange.getIn().setHeader("ipAddress", user.getIpAddress());  // Set the IP address
        });

        // Map the Camel route result to LocationDTO
        LocationDTO location = new LocationDTO();
        location.setCity(result.getIn().getHeader("city", String.class));
        location.setCountry(result.getIn().getHeader("country", String.class));

        // Log the access event with the location details
        linkLogger.log(sharedLink, user, location);

        // Call the combined access handling logic
        return accessResourceByLink(sharedLink, parentFolderId);
    }
    private Object accessResourceByLink(SharedLinks sharedLink, UUID parentFolderId) {
        // Handle expiration logic
        ExpirationType expirationType = sharedLink.getExpirationType();
        if (expirationType == ExpirationType.ON_DATE) {
            if (sharedLink.getExpiration_date() != null && sharedLink.getExpiration_date().before(new Date())) {
                throw SharedLinkAccessException.linkExpired();
            }
        } else if (expirationType == ExpirationType.ON_NUMBER_OF_CLICKS) {
            if (sharedLink.getMax_access_count() != null && sharedLink.getAccess_count() >= sharedLink.getMax_access_count()) {
                throw SharedLinkAccessException.maxAccessExceeded();
            }
        }

        // Get the target folder ID from the shared link
        UUID targetFolderId = sharedLink.getTarget_id();

        // Handle file access
        if ("file".equalsIgnoreCase(sharedLink.getTarget_type())) {
            // Increment access count immediately when accessing the file
            sharedLink.setAccess_count(sharedLink.getAccess_count() + 1);

            // Update last accessed date
            sharedLink.setLast_accessed_at(new Date());

            // Save the shared link to update the access count
            sharedLinksRepository.save(sharedLink);

            // Return file details
            String jwtToken = jwtTokenService.generateJwtToken(); // Generate JWT for internal API calls
            return documentService.getFileById(sharedLink.getTarget_id(), jwtToken);
        }
        // Handle folder access
        else if ("folder".equalsIgnoreCase(sharedLink.getTarget_type())) {
            // Only increment access count when accessing the root folder (target folder) or when no parent folder is provided
            if (parentFolderId == null || parentFolderId.equals(targetFolderId)) {
                sharedLink.setAccess_count(sharedLink.getAccess_count() + 1);
            }

            // Update last accessed date
            sharedLink.setLast_accessed_at(new Date());

            // Save the shared link to update the access count
            sharedLinksRepository.save(sharedLink);

            // Generate JWT for internal API calls
            String jwtToken = jwtTokenService.generateJwtToken();

            // Fetch the target folder's details
            FolderDTO targetFolder = documentService.getFolderById(targetFolderId, jwtToken); // Get target folder details
            String targetFolderPath = targetFolder.getFolderPath();

            // If parentFolderId is not provided, default it to the targetFolderId (root folder)
            if (parentFolderId == null) {
                parentFolderId = targetFolderId;
            }

            // Fetch the parent folder's details
            FolderDTO parentFolder = documentService.getFolderById(parentFolderId, jwtToken);
            String parentFolderPath = parentFolder.getFolderPath();

            // **Validation Step**: Check if parent folder's path starts with target folder's path
            if (!parentFolderPath.startsWith(targetFolderPath)) {
                throw new RuntimeException("Unauthorized access: The parent folder is outside the scope of the shared folder.");
            }

            // Retrieve folder contents (subfolders and files)
            Map<String, Object> folderContents = documentService.getFolderContents(parentFolderId, jwtToken);

            // Combine parent folder details with the folder contents (subfolders and files)
            Map<String, Object> result = new HashMap<>();
            result.put("parentFolder", parentFolder);  // Add parent folder details to result
            result.put("subfolders", folderContents.get("subfolders"));  // Add subfolders to result
            result.put("files", folderContents.get("files"));  // Add files to result

            return result;  // Return the combined result
        } else {
            throw new RuntimeException("Invalid target type.");
        }
    }
    public Exchange validateAndDownloadFile(String link, UUID fileId, boolean forceDownload) {
        String jwtToken = jwtTokenService.generateJwtToken();

        // Retrieve the shared link
        SharedLinks sharedLink = sharedLinksRepository.findByLink(link)
                .orElseThrow(() -> SharedLinkAccessException.linkNotFound());

        // Check if download is allowed
        if (!sharedLink.getIsDownloadAllowed() & forceDownload) {
            throw SharedLinkAccessException.downloadNotAllowed();
        }

        // Get the target ID (could be file or folder) from the shared link
        UUID targetId = sharedLink.getTarget_id();

        // Handle cases based on target type
        if (sharedLink.getTarget_type().equalsIgnoreCase("file")) {
            // If target_type is 'file', use target_id directly as fileId
            fileId = targetId;
        } else if (sharedLink.getTarget_type().equalsIgnoreCase("folder")) {
            // Ensure a fileId is provided when target_type is 'folder'
            if (fileId == null) {
                throw new IllegalArgumentException("File ID is required to download from a folder.");
            }

            // Retrieve the target folder details for scope validation
            FolderDTO targetFolder = documentService.getFolderById(targetId, jwtToken);
            if (targetFolder == null) {
                throw new ResourceNotFoundException("Target folder not found or access denied.");
            }

            // Retrieve details for the specified file to verify its location
            FileDTO requestedFile = documentService.getFileById(fileId, jwtToken);
            if (requestedFile == null || !requestedFile.getFilePath().startsWith(targetFolder.getFolderPath())) {
                throw new RuntimeException("Unauthorized access: The requested file is outside the shared folder scope.");
            }
        } else {
            throw new IllegalArgumentException("Invalid target type specified.");
        }

        // If validation is successful, proceed to download the file via Document Service
        return documentService.downloadFile(fileId, forceDownload, jwtToken);
    }


    public FolderDownloadDTO downloadFolderAsZip(String link, UUID folderId) {
        String jwtToken = jwtTokenService.generateJwtToken();

        // Retrieve the shared link from the repository
        SharedLinks sharedLink = sharedLinksRepository.findByLink(link)
                .orElseThrow(() -> SharedLinkAccessException.linkNotFound());

        // Check if download is allowed
        if (!sharedLink.getIsDownloadAllowed()) {
            throw SharedLinkAccessException.downloadNotAllowed();
        }

        // Get the target folder ID from the shared link
        UUID targetFolderId = sharedLink.getTarget_id();

        // Determine which folder to download
        UUID downloadFolderId = (folderId != null) ? folderId : targetFolderId;

        // Retrieve details for the target folder to establish the scope
        FolderDTO targetFolder = documentService.getFolderById(targetFolderId, jwtToken);
        if (targetFolder == null) {
            throw new ResourceNotFoundException("Target folder not found or access denied.");
        }

        // If a different folder is specified, ensure it is within the scope of the target folder
        if (!downloadFolderId.equals(targetFolderId)) {
            FolderDTO requestedFolder = documentService.getFolderById(downloadFolderId, jwtToken);
            if (requestedFolder == null || !requestedFolder.getFolderPath().startsWith(targetFolder.getFolderPath())) {
                throw new RuntimeException("Unauthorized access: The requested folder is outside the shared folder scope.");
            }
        }

        // Perform the actual folder download as a zip
        ByteArrayOutputStream folderBytes = documentService.downloadFolderAsZip(downloadFolderId, jwtToken);
        if (folderBytes == null) {
            throw new ResourceNotFoundException("Folder not found or access denied.");
        }

        // Use the downloaded folder's name in the zip file name
        String folderName = documentService.getFolderById(downloadFolderId, jwtToken).getFolderName();

        // Construct and return the FolderDownloadDTO
        return new FolderDownloadDTO(folderBytes, folderName, "application/zip");
    }

}
