package com.digitalchain.link_management.exception.links;

import com.digitalchain.link_management.enums.AccessType;

public class UpdateLinkException extends RuntimeException {

    private final String errorCode;

    public UpdateLinkException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }


    public String getErrorCode() {
        return errorCode;
    }

    public static UpdateLinkException passwordRequiredForAccessType() {
        return new UpdateLinkException("PASSWORD_REQUIRED_FOR_ACCESS_TYPE", "Password is required for 'ANYONE_WITH_PASSWORD' access type.");
    }

    public static UpdateLinkException passwordNotAllowedForAccessType(AccessType accessType) {
        return new UpdateLinkException("PASSWORD_NOT_ALLOWED_FOR_ACCESS_TYPE", "Password is not allowed for access type: " + accessType);
    }

    public static UpdateLinkException expirationDateRequired() {
        return new UpdateLinkException("EXPIRATION_DATE_REQUIRED", "Expiration date is required when 'expirationType' is 'ON_DATE'.");
    }

    public static UpdateLinkException maxAccessCountRequired() {
        return new UpdateLinkException("MAX_ACCESS_COUNT_REQUIRED", "Max access count is required when 'expirationType' is 'ON_NUMBER_OF_CLICKS'.");
    }

    public static UpdateLinkException invalidExpirationType() {
        return new UpdateLinkException("INVALID_EXPIRATION_TYPE", "Invalid expiration type specified.");
    }

    public static UpdateLinkException invalidExpirationDateFormat() {
        return new UpdateLinkException("INVALID_EXPIRATION_DATE_FORMAT", "Invalid expiration date format.");
    }
    public static UpdateLinkException specificUsersRequired() {
        return new UpdateLinkException("SPECIFIC_USER_REQUIRED", "Field specific users is missing.");
    }
    }


