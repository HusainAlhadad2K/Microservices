package com.digitalchain.link_management.routes.logging;

import com.digitalchain.link_management.config.BaseRouteBuilder;
import org.apache.camel.Exchange;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class GeoLocationRoute extends BaseRouteBuilder {

    @Override
    public void configure() throws Exception {
        super.configure();  // Inherit base configuration (if needed)

        // Define the route for geolocation lookup
        from("direct:getLocation")
                .routeId("geoLocationRoute")
                .process(this::lookupLocation);  // Delegate the processing to a method
    }

    // Method to handle the geolocation lookup logic
    private void lookupLocation(Exchange exchange) throws Exception {
        String ipAddress = exchange.getIn().getHeader("ipAddress", String.class);  // Get IP address from header

        if (ipAddress == null || ipAddress.isEmpty()) {
            throw new IllegalArgumentException("IP address is required");
        }

        // Make a call to IP-API to get location data
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://ip-api.com/json/" + ipAddress;

        // Make HTTP request to IP-API
        ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

        // Handle the response and set location headers
        if (response.getStatusCode().is2xxSuccessful()) {
            Map<String, Object> result = response.getBody();
            String city = (String) result.get("city");
            String country = (String) result.get("country");

            // Set the city and country in the headers of the exchange
            exchange.getIn().setHeader("city", city != null ? city : "Unknown City");
            exchange.getIn().setHeader("country", country != null ? country : "Unknown Country");
        } else {
            exchange.getIn().setHeader("city", "Unknown City");
            exchange.getIn().setHeader("country", "Unknown Country");
        }
    }
}
