package com.digitalchain.link_management.service.links;

import com.digitalchain.common.dto.LocationDTO;
import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.digitalchain.link_management.dto.uploadlinks.UploadLinkDTO;
import com.digitalchain.link_management.dto.uploadlinks.UploadLinkUpdateDTO;
import com.digitalchain.link_management.enums.AccessType;
import com.digitalchain.link_management.enums.ExpirationType;
import com.digitalchain.link_management.exception.ResourceNotFoundException;
import com.digitalchain.link_management.exception.links.CreateLinkException;
import com.digitalchain.link_management.model.SharedLinks;
import com.digitalchain.link_management.repository.SharedLinksRepository;
import com.digitalchain.link_management.service.content.DocumentService;
import com.digitalchain.link_management.service.content.JwtTokenService;
import com.digitalchain.link_management.utils.LinkLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.*;

@Slf4j
@Service
public class UploadLinksService {

    @Autowired
    private SharedLinksRepository sharedLinksRepository;

    @Autowired
    private DocumentService documentService;
    @Autowired
    private JwtTokenService jwtTokenService;
    @Autowired
    private ProducerTemplate producerTemplate;
    @Autowired
    private LinkLogger linkLogger;

    public SharedLinks generateUploadLink(UploadLinkDTO uploadLinkDTO) throws Exception {
        if (uploadLinkDTO.getFolder_id() == null) {
            throw CreateLinkException.targetIdRequired();  // Custom exception for null target_id
        }
        String jwtToken = jwtTokenService.generateJwtToken();
        // Validate the folder existence
        FolderDTO folderDetails = documentService.getFolderById(uploadLinkDTO.getFolder_id(), jwtToken);
        if (folderDetails == null) {
            throw new ResourceNotFoundException("Folder not found");
        }

        // Generate a unique link identifier
        String linkIdentifier = UUID.randomUUID().toString();
        String encodedLink = Base64.getUrlEncoder().encodeToString(linkIdentifier.getBytes(StandardCharsets.UTF_8));

        // Parse the expiration date
        Date expirationDate = null;
        if (uploadLinkDTO.getExpiration_date() != null && !uploadLinkDTO.getExpiration_date().isEmpty()) {
            try {
                expirationDate = Date.from(Instant.parse(uploadLinkDTO.getExpiration_date()));
            } catch (DateTimeParseException e) {
                throw new RuntimeException("Invalid expiration date format", e);
            }
        }

        // Build the SharedLinks entity for the upload link
        SharedLinks uploadLink = SharedLinks.builder()
                .link_id(UUID.randomUUID())
                .target_id(uploadLinkDTO.getFolder_id())
                .target_type("folder") // Always a folder for upload links
                .includeTargetNameInLink(false) // Do not include target name
                .target_name(folderDetails.getFolderName()) // Set folder name, but not included in the link
                .shared_by(uploadLinkDTO.getShared_by())
                .access_count(0)
                .accessType(AccessType.ANYONE) // Anyone can access the link
                .isDownloadAllowed(false) // Upload links don't allow downloads
                .isUploadLink(true) // Mark as an upload link
                .expirationType(uploadLinkDTO.getLinkExpires() ? ExpirationType.ON_DATE : ExpirationType.NONE) // Set expiration type
                .expiration_date(expirationDate) // Set expiration date if applicable
                .createSeparateFolder(uploadLinkDTO.getCreateSeparateFolder()) // Option to create separate folders for each uploader
                .notifyOnClick(uploadLinkDTO.getNotifyOnUpload()) // Notify when someone uploads
                .link(encodedLink) // Generated link
                .created_at(new Date()) // Current time as created date
                .build();

        // Save the upload link to the database
        sharedLinksRepository.save(uploadLink);

        return uploadLink;
    }

    public SharedLinks updateUploadLink(UUID linkId, UploadLinkUpdateDTO updateDTO) throws Exception {
        // Fetch the existing upload link
        SharedLinks existingLink = sharedLinksRepository.findById(linkId)
                .orElseThrow(() -> new ResourceNotFoundException("Link not found"));

        // Only update the fields that are provided in the request

        // Update expiration type and handle expiration date accordingly if provided
        if (updateDTO.getExpirationType() != null) {
            existingLink.setExpirationType(updateDTO.getExpirationType());

            if (updateDTO.getExpirationType() == ExpirationType.NONE) {
                // If the expiration type is NONE, clear the expiration date
                existingLink.setExpiration_date(null);
            } else if (updateDTO.getExpirationType() == ExpirationType.ON_DATE) {
                // If ON_DATE, ensure an expiration date is provided and valid
                if (updateDTO.getExpiration_date() != null && !updateDTO.getExpiration_date().isEmpty()) {
                    Date expirationDate;
                    try {
                        expirationDate = Date.from(Instant.parse(updateDTO.getExpiration_date()));
                        existingLink.setExpiration_date(expirationDate);
                    } catch (DateTimeParseException e) {
                        throw new RuntimeException("Invalid expiration date format", e);
                    }
                } else {
                    throw new RuntimeException("Expiration date is required for ExpirationType.ON_DATE.");
                }
            }
        }

        // Update the notifyOnUpload flag (if provided)
        if (updateDTO.getNotifyOnUpload() != null) {
            existingLink.setNotifyOnClick(updateDTO.getNotifyOnUpload());
        }

        // Set the updated_at field to the current date and time
        existingLink.setUpdated_at(new Date());

        // Save the updated link
        return sharedLinksRepository.save(existingLink);
    }

    public void uploadFileUsingLink(String link, InputStream fileInputStream, String contentType, String fileName, UserDTO user) throws Exception {
        // Fetch the upload link by the provided link
        SharedLinks uploadLink = sharedLinksRepository.findByLink(link)
                .orElseThrow(() -> new ResourceNotFoundException("Upload link not found"));

        UUID folderId;
        String jwtToken = jwtTokenService.generateJwtToken();

        // Check if createSeparateFolder is enabled
        if (uploadLink.getCreateSeparateFolder()) {
            List<FolderDTO> folderDTOList = documentService.getFolderInfo(uploadLink.getTarget_id(), user.getSub(), jwtToken);

            if (folderDTOList != null && !folderDTOList.isEmpty()) {
                FolderDTO folderDTO = folderDTOList.get(0);
                folderId = folderDTO.getFolderId();
            } else {
                folderId = documentService.createFolder(user.getSub(), uploadLink.getTarget_id(), jwtToken);
            }
        } else {
            folderId = uploadLink.getTarget_id();
        }

        // Proceed with the upload using the folderId
        documentService.uploadFile(fileInputStream, folderId.toString(), fileName, contentType, jwtToken);
        log.debug("File uploaded successfully to folder ID: {}", folderId);
// Increment access count after a successful upload
        uploadLink.setAccess_count(uploadLink.getAccess_count() + 1);
        sharedLinksRepository.save(uploadLink); // Save the updated access count
        // Call the Camel route to get the location
        Exchange result = producerTemplate.request("direct:getLocation", exchange -> {
            exchange.getIn().setHeader("ipAddress", user.getIpAddress());  // Set the IP address
        });

        // Map the Camel route result to LocationDTO
        LocationDTO location = new LocationDTO();
        location.setCity(result.getIn().getHeader("city", String.class));
        location.setCountry(result.getIn().getHeader("country", String.class));

        linkLogger.log(uploadLink, user, location);
    }
}