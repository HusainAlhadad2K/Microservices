package com.digitalchain.link_management.dto.sharelinks;

import com.digitalchain.link_management.enums.AccessType;
import com.digitalchain.link_management.enums.ExpirationType;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
public class LinksDTO {
    private UUID target_id; // The ID of the target file or folder
    private String target_type; // "file" or "folder"
    private String shared_by; // The user ID of the person sharing the link
    private String password; // Password for 'ANYONE_WITH_PASSWORD' access type
   // private String Message;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private AccessType accessType; // "ANYONE", "ANYONE_WITH_PASSWORD", "ALL_USERS", "SPECIFIC_USERS"

    private List<String> specificUsers; // List of user IDs if accessType is "SPECIFIC_USERS"

    private Boolean includeTargetNameInLink; // Include folder/file name in the link
    private Boolean isDownloadAllowed; // Is download allowed

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private ExpirationType expirationType; // "NONE", "ON_DATE", "ON_NUMBER_OF_CLICKS"

    private String expiration_date; // ISO 8601 format, required if expirationType is 'ON_DATE'
    private Integer max_access_count; // Required if expirationType is 'ON_NUMBER_OF_CLICKS'

    private Boolean notifyOnClick; // Indicates whether to notify when the link is clicked
}
