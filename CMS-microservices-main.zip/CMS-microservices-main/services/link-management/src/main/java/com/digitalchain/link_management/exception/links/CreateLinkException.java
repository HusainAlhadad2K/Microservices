package com.digitalchain.link_management.exception.links;

import lombok.Getter;

@Getter
public class CreateLinkException extends RuntimeException {

    private final String errorCode;

    public CreateLinkException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public static CreateLinkException invalidTargetType() {
        return new CreateLinkException("INVALID_TARGET_TYPE", "Invalid target type specified.");
    }
    public static CreateLinkException targetIdRequired() {
        return new CreateLinkException("TARGET_ID_REQUIRED", "Missing target id.");
    }
    public static CreateLinkException invalidLinkType() {
        return new CreateLinkException("INVALID_LINK_TYPE", "Invalid link type specified. Must be 'internal' or 'external'.");
    }

    public static CreateLinkException invalidAccessTypeForExternalLink() {
        return new CreateLinkException("INVALID_ACCESS_TYPE_FOR_EXTERNAL_LINK", "External links can only have accessType 'ANYONE' or 'ANYONE_WITH_PASSWORD'.");
    }

    public static CreateLinkException invalidAccessTypeForInternalLink() {
        return new CreateLinkException("INVALID_ACCESS_TYPE_FOR_INTERNAL_LINK", "Internal links can only have accessType 'ALL_USERS' or 'SPECIFIC_USERS'.");
    }

    public static CreateLinkException passwordRequired() {
        return new CreateLinkException("PASSWORD_REQUIRED", "Password is required for 'ANYONE_WITH_PASSWORD' access type.");
    }

    public static CreateLinkException expirationDateRequired() {
        return new CreateLinkException("EXPIRATION_DATE_REQUIRED", "Expiration date is required when 'doesExpire' is true.");
    }

    public static CreateLinkException specificUsersRequired() {
        return new CreateLinkException("SPECIFIC_USERS_REQUIRED", "specificUsers list cannot be null or empty when accessType is 'SPECIFIC_USERS'.");
    }

    public static CreateLinkException userPermissionsRequired() {
        return new CreateLinkException("USER_PERMISSIONS_REQUIRED", "userPermissions cannot be null or empty when sharing with specific users.");
    }

    public static CreateLinkException missingPermissionsForUser(String userId) {
        return new CreateLinkException("MISSING_PERMISSIONS_FOR_USER", "Permissions are missing for user ID: " + userId);
    }

    public static Exception maxAccessCountRequired() {
        return new CreateLinkException("MAX_ACCESS_COUNT_REQUIRED", "Maximum number of clicks required" );
    }

    public static Exception invalidExpirationType() {
        return new CreateLinkException("INVALID_EXPIRATION_TYPE", "Invalid expiration type" );
    }

    public static Exception invalidAccessType() {
        return new CreateLinkException("INVALID_ACCESS_TYPE", "Invalid access type" );
    }

    public static Exception passwordNotAllowedForAccessType() {
        return new CreateLinkException("PASSWORD_NOT_ALLOWED", "Password not allowed for access type" );
    }
}
