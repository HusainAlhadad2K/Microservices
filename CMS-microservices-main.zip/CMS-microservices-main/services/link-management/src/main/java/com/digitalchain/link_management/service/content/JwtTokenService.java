package com.digitalchain.link_management.service.content;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Service // Add this annotation to register JwtTokenService as a Spring Bean
public class JwtTokenService {

    @Value("${oracle.oauth2-token-url}")
    private String oauth2TokenUrl;

    @Value("${oracle.jwk-url}")
    private String jwkUrl;

    @Value("${oracle.username}")
    private String ociUsername;

    @Value("${oracle.password}")
    private String ociPassword;

    public String generateJwtToken() {
        try {
            // Prepare credentials and encode them for Basic Authentication
            String credentials = Base64.getEncoder().encodeToString((ociUsername + ":" + ociPassword).getBytes(StandardCharsets.UTF_8));

            // Construct the request body including the scope parameter
            String requestBody = "grant_type=client_credentials&scope=AdminUsersAdminUsersRead";

            // Build the HTTP request with headers and body
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(oauth2TokenUrl))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .header("Authorization", "Basic " + credentials)
                    .header("Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            // Send the request and capture the response
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Log the request and response details
            System.out.println("Request URL: " + oauth2TokenUrl);
            System.out.println("Request Headers: " + request.headers());
            System.out.println("Request Body: " + requestBody);
            System.out.println("Response Status Code: " + response.statusCode());
            System.out.println("Response Body: " + response.body());

            // Check if the request was successful
            if (response.statusCode() != 200) {
                String errorDetails = "Failed to obtain JWT token. Status Code: " + response.statusCode() + ", Response: " + response.body();
                System.err.println(errorDetails);
                throw new RuntimeException(errorDetails);
            }

            // Parse the JSON response to extract the JWT token
            String responseBody = response.body();
            JsonNode jsonNode = new ObjectMapper().readTree(responseBody);

            // Ensure the access token is present in the response
            if (!jsonNode.has("access_token")) {
                throw new RuntimeException("JWT token not found in the response: " + responseBody);
            }

            // Return the access token
            return jsonNode.get("access_token").asText();

        } catch (IOException e) {
            System.err.println("Network or I/O error during JWT token generation: " + e.getMessage());
            throw new RuntimeException("Network or I/O error during JWT token generation", e);

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Request interrupted during JWT token generation: " + e.getMessage());
            throw new RuntimeException("Request interrupted during JWT token generation", e);

        } catch (Exception e) {
            System.err.println("Unexpected error during JWT token generation: " + e.getMessage());
            throw new RuntimeException("Unexpected error during JWT token generation", e);
        }
    }
}
