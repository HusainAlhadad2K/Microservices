package com.digitalchain.link_management.utils;

import com.digitalchain.common.dto.AccessMethod;
import com.digitalchain.common.dto.LocationDTO;
import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.common.dto.files.FileLogAction;
import com.digitalchain.common.dto.files.FileLogDTO;
import com.digitalchain.common.dto.folders.FolderDTO;

import com.digitalchain.common.dto.links.LinkLogDTO;
import com.digitalchain.link_management.dto.sharelinks.LinkDetailsDTO;
import com.digitalchain.link_management.model.SharedLinks;
import com.digitalchain.link_management.service.logging.LinkLogProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
public class LinkLogger {
    @Autowired
    LinkLogProducerService linkLogProducerService;
    public void log(SharedLinks link, UserDTO user, LocationDTO location){
        LinkLogDTO log = LinkLogDTO.builder()
                .link_id(link.getLink_id())
                .target_id(link.getTarget_id())
                .target_type(link.getTarget_type())
                .target_name(link.getTarget_name())
                .userId(user.getUser_id())
                .accessMethod(AccessMethod.WEB)
                .userName(user.getSub())
                .ipAddress(user.getIpAddress())
                .city(location.getCity())
                .country(location.getCountry())
                .actionTime(new Date())
                .build();

        linkLogProducerService.sendLinkLog(log);
    }
}
