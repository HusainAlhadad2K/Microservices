package com.digitalchain.link_management.model;

import com.digitalchain.link_management.enums.AccessType;
import com.digitalchain.link_management.enums.ExpirationType;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@Document(collection = "shared_links")
public class SharedLinks {

    @Id
    private UUID link_id;

    private UUID target_id;

    private String target_type;  // "file" or "folder"

    private Boolean includeTargetNameInLink;

    private String target_name;

    private String shared_by;

    private AccessType accessType; // "ANYONE", "ANYONE_WITH_PASSWORD", "ALL_USERS", "SPECIFIC_USERS"

    private List<String> specificUsers; // List of user IDs if accessType is 'SPECIFIC_USERS'

    private String link;

    private Boolean isDownloadAllowed;

    private int access_count = 0;

    private Integer max_access_count; // For 'ON_NUMBER_OF_CLICKS' expiration

    @JsonIgnore
    private String password;

    private ExpirationType expirationType; // 'ON_DATE', 'ON_NUMBER_OF_CLICKS', 'NONE'

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date expiration_date; // For 'ON_DATE' expiration

    private Boolean notifyOnClick;

    private Set<String> users_accessed; // New field to track unique users accessing the link
    private Boolean isUploadLink; // true for upload link, false for share link
    private Boolean createSeparateFolder; // Create separate folder for each uploader
    //private String message;
    @CreatedDate
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date created_at;

    @LastModifiedDate
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date updated_at;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date last_accessed_at; // New field to store when the link was last accessed
}
