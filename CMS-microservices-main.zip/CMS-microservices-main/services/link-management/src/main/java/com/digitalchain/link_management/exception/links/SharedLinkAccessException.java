package com.digitalchain.link_management.exception.links;

public class SharedLinkAccessException extends RuntimeException {

    private final String errorCode;

    public SharedLinkAccessException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }


    public String getErrorCode() {
        return errorCode;
    }

    public static SharedLinkAccessException invalidPassword() {
        return new SharedLinkAccessException("INVALID_PASSWORD", "Invalid password");
    }

    public static SharedLinkAccessException maxAccessExceeded() {
        return new SharedLinkAccessException("MAX_ACCESS_EXCEEDED", "Max access count exceeded");
    }

    public static SharedLinkAccessException linkExpired() {
        return new SharedLinkAccessException("LINK_EXPIRED", "Link expired");
    }

    public static SharedLinkAccessException passwordRequired() {
        return new SharedLinkAccessException("PASSWORD_REQUIRED", "Password is required");
    }

    public static SharedLinkAccessException linkNotFound() {
        return new SharedLinkAccessException("LINK_NOT_FOUND", "Link not found");
    }

    public static SharedLinkAccessException invalidTargetType() {
        return new SharedLinkAccessException("INVALID_TARGET_TYPE", "Invalid target type");
    }

    public static SharedLinkAccessException invalidToken() {
        return new SharedLinkAccessException("INVALID_TOKEN", "Invalid or missing access token");
    }

    public static SharedLinkAccessException invalidPermission() {
        return new SharedLinkAccessException("INVALID_PERMISSION", "Invalid permission");
    }
    public static SharedLinkAccessException downloadNotAllowed(){
        return new SharedLinkAccessException("DOWNOAD_NOT_ALLOWED", "download permissions not allowed");
    }
    public static SharedLinkAccessException authenticationRequired(){
        return new SharedLinkAccessException("AUTH_REQUIRED", "Authentication is required");
    }
    public static SharedLinkAccessException accessDenied(){
        return new SharedLinkAccessException("ACCESS_DENIED", "Access is denied");
    }
}
