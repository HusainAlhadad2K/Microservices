package com.digitalchain.link_management.kafka;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShareLinkGeneration {
    private String targetType;
    private String targetName;
    private String sharedWith;
    private String sharedBy;
}
