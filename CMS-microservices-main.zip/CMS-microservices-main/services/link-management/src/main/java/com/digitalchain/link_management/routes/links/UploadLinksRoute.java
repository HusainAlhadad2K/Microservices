package com.digitalchain.link_management.routes.links;


import com.digitalchain.link_management.config.BaseRouteBuilder;
import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.link_management.dto.uploadlinks.UploadLinkDTO;
import com.digitalchain.link_management.dto.uploadlinks.UploadLinkUpdateDTO;
import com.digitalchain.link_management.model.SharedLinks;
import com.digitalchain.link_management.service.links.UploadLinksService;
import jakarta.activation.DataHandler;
import org.apache.camel.Exchange;
import org.apache.camel.attachment.AttachmentMessage;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import java.io.InputStream;
import java.util.Map;
import java.util.UUID;

@Component
public class UploadLinksRoute extends BaseRouteBuilder {

    @Autowired
    private UploadLinksService uploadLinksService;

    @Override
    public void configure() throws Exception {
        super.configure();

        rest("/sharing")
                // Define Generate endpoint for generating an upload link
                .post("/upload")
                .type(UploadLinkDTO.class)
                .description("Generate a new upload link")
                .responseMessage().code(200).message("Upload link generated successfully").responseModel(SharedLinks.class).endResponseMessage()
                .to("direct:generateUploadLink")

                // Define PATCH endpoint for updating an upload link
                .patch("/upload/{linkId}")
                .type(UploadLinkUpdateDTO.class)
                .description("Update an existing upload link")
                .responseMessage().code(200).message("Upload link updated successfully").responseModel(UploadLinkUpdateDTO.class).endResponseMessage()
                .to("direct:updateUploadLink")

                .post("/uploadfile/{link}")
                .description("Upload file to the link")
                .bindingMode(RestBindingMode.off)  // Ensure binding mode is off for multipart form data
                .consumes("multipart/form-data")
                .produces(MediaType.APPLICATION_JSON_VALUE)
                .param().name("link").type(RestParamType.path).description("The link to upload to").dataType("string").endParam()
                .param().name("email").type(RestParamType.body).description("The email of the uploader").dataType("string").endParam()  // email in the body
                .param().name("file").type(RestParamType.body).description("The file to upload").dataType("file").endParam()
                .responseMessage().code(200).message("File uploaded successfully").endResponseMessage()
                .to("direct:uploadFileToLink");


        from("direct:generateUploadLink")
                .routeId("generateUploadLink")
                .process(this::handleGenerateUploadLink);  // Call the separate method to handle the process

        // Route to process the upload link update
        from("direct:updateUploadLink")
                .routeId("updateUploadLink")
                .process(this::handleUpdateUploadLink);  // Call the separate method to handle the process

        from("direct:uploadFileToLink")
                .routeId("uploadFileToLink")
                .setHeader("RestBindingMode", constant("off"))
                .unmarshal().mimeMultipart()  // Unmarshal the multipart form data
                .process(this::handleUploadFileToLink)  // Call the separate method to handle the process
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                .process(exchange -> {
                    exchange.getIn().setBody("File uploaded successfully");
                });
    }

    private void handleGenerateUploadLink(Exchange exchange) throws Exception {
            UploadLinkDTO uploadLinkDTO = exchange.getIn().getBody(UploadLinkDTO.class);

            // Retrieve the UserDTO from the exchange properties
            UserDTO user = exchange.getProperty("user", UserDTO.class);
            uploadLinkDTO.setShared_by(user.getUser_id());

            // Call the UploadLinksService to generate the upload link
            SharedLinks uploadLink = uploadLinksService.generateUploadLink(uploadLinkDTO);

            // Set the upload link as the response body
            exchange.getIn().setBody(uploadLink);

    }

    private void handleUpdateUploadLink(Exchange exchange) {
        try {
            // Retrieve the linkId from the headers
            UUID linkId = UUID.fromString(exchange.getIn().getHeader("linkId", String.class));

            // Retrieve the UploadLinkUpdateDTO from the message body
            UploadLinkUpdateDTO updateDTO = exchange.getIn().getBody(UploadLinkUpdateDTO.class);

            // Call the UploadLinksService to update the upload link
            SharedLinks updatedLink = uploadLinksService.updateUploadLink(linkId, updateDTO);

            // Set the updated link as the response body
            exchange.getIn().setBody(updatedLink);

        } catch (Exception e) {
            // Handle the exception locally, perhaps log it and send a proper error response
            log.error("Error updating upload link: {}", e.getMessage());
            exchange.getIn().setBody("Error updating upload link");
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 500);
        }
    }

    private void handleUploadFileToLink(Exchange exchange) throws Exception {
        // Extract the linkId from the path parameter
        String link = exchange.getIn().getHeader("link", String.class);
        if (link == null || link.isEmpty()) {
            throw new RuntimeException("link is missing in the path");
        }

        // Extract the AttachmentMessage (multipart data)
        AttachmentMessage attachmentMessage = exchange.getIn(AttachmentMessage.class);

        // Extract the email from form-data (body)
        String email = attachmentMessage.getBody(String.class);  // Assuming the user passes email in the form-data
        if (email == null || email.isEmpty()) {
            throw new RuntimeException("Uploader's email is missing in the form data");
        }

        // Extract the file attachment
        Map<String, DataHandler> attachments = attachmentMessage.getAttachments();
        if (attachments == null || attachments.isEmpty()) {
            throw new RuntimeException("No file found in the request");
        }

        // Get the first file attachment
        Map.Entry<String, DataHandler> fileEntry = attachments.entrySet().iterator().next();
        String fileName = fileEntry.getKey();  // This is the file name
        DataHandler fileHandler = fileEntry.getValue();

        // Get InputStream and ContentType from the file
        InputStream fileInputStream = fileHandler.getInputStream();
        String contentType = fileHandler.getContentType();

        log.info("Attachment File Name: {}", fileName);

        // Create and populate UserDTO with email as username
        UserDTO user = new UserDTO();
        user.setSub(email);  // Set the email as the username
        user.setIpAddress(exchange.getIn().getHeader("X-Forwarded-For", String.class));

        // Call the UploadLinksService to handle the file upload, now passing UserDTO as well
        uploadLinksService.uploadFileUsingLink(link, fileInputStream, contentType, fileName, user);

    }
}