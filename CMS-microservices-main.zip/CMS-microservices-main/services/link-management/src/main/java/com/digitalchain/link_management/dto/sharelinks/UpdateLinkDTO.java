package com.digitalchain.link_management.dto.sharelinks;

import com.digitalchain.link_management.enums.AccessType;
import com.digitalchain.link_management.enums.ExpirationType;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.List;

@Data
public class UpdateLinkDTO {
    private String newPassword; // New password if updating or adding

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private ExpirationType expirationType; // "NONE", "ON_DATE", "ON_NUMBER_OF_CLICKS"
    private String expiration_date; // ISO 8601 format, required if expirationType is 'ON_DATE'
    private Integer max_access_count; // Required if expirationType is 'ON_NUMBER_OF_CLICKS'
   // private String message;
    private Boolean isDownloadAllowed; // Is download allowed
    private Boolean notifyOnClick; // Indicates whether to notify when the link is clicked
    private AccessType accessType;
    private List<String> specificUsers; // List of specific users for "SPECIFIC_USERS" access type
}
