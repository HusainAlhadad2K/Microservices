package com.digitalchain.link_management.dto.content;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.core.io.InputStreamResource;

import java.io.InputStream;
@Data
@AllArgsConstructor
public class FileDownloadDTO {
    private InputStreamResource inputStreamResource;
    private String fileName;
    private String fileType;
}
