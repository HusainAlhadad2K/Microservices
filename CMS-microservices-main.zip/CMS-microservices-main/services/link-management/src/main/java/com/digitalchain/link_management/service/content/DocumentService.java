package com.digitalchain.link_management.service.content;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.common.dto.folders.FolderDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.http.HttpMethods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
public class DocumentService {

    @Autowired
    private ProducerTemplate producerTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    public FileDTO getFileById(UUID fileId, String jwtToken) {
        Map<String, Object> headers = new HashMap<>();
        headers.put("targetId", fileId);
        if (jwtToken != null && !jwtToken.isEmpty()) {
            headers.put("jwtToken", jwtToken);
        }
        
        // Expect a List<FileDTO> and pick the first item
        List<Map<String,Object>> fileDTOList = producerTemplate.requestBodyAndHeaders("direct:getFileDetails", null, headers, List.class);

        if (fileDTOList != null && !fileDTOList.isEmpty()) {
            Map<String, Object> firstItem = fileDTOList.get(0);
            return objectMapper.convertValue(firstItem, FileDTO.class); // Return the first FileDTO from the list
        } else {
            throw new RuntimeException("No document details found for fileId: " + fileId);
        }
    }

    public FolderDTO getFolderById(UUID folderId, String jwtToken) {
        Map<String, Object> headers = new HashMap<>();
        headers.put("targetId", folderId);
        if (jwtToken != null && !jwtToken.isEmpty()) {
            headers.put("jwtToken", jwtToken);
        }

        List<Map<String, Object>> detailsList = producerTemplate.requestBodyAndHeaders("direct:getFolderDetails", null, headers, List.class);
        if (detailsList != null && !detailsList.isEmpty()) {
            Map<String, Object> firstItem = detailsList.get(0);
            return objectMapper.convertValue(firstItem, FolderDTO.class);
        } else {
            throw new RuntimeException("No folder details found for folderId: " + folderId);
        }
    }
    public Map<String, Object> getFolderContents(UUID folderId, String jwtToken) {
        Map<String, Object> headersForSubfolders = new HashMap<>();
        Map<String, Object> headersForFiles = new HashMap<>();

        headersForSubfolders.put("parentFolderId", folderId);  // Correct for subfolder fetching in folder service
        headersForFiles.put("folderId", folderId);  // Correct for file fetching in document service

        if (jwtToken != null && !jwtToken.isEmpty()) {
            headersForSubfolders.put("jwtToken", jwtToken);
            headersForFiles.put("jwtToken", jwtToken);
        }

        // Fetch subfolders as a list of FolderDTO
        List<FolderDTO> subfolders = producerTemplate.requestBodyAndHeaders("direct:getSubfolders", null, headersForSubfolders, List.class);

        // Fetch files in the folder as a list of FileDTO
        List<FileDTO> files = producerTemplate.requestBodyAndHeaders("direct:getFiles", null, headersForFiles, List.class);  // Correct for file fetching in document service

        // Combine the results into a map to return
        Map<String, Object> result = new HashMap<>();
        result.put("subfolders", subfolders);
        result.put("files", files);

        return result;
    }

    public Exchange downloadFile(UUID fileId, boolean forceDownload, String jwtToken) {
        return producerTemplate.send("direct:downloadFileURL", exchange -> {
            exchange.getIn().setHeader("fileId", fileId.toString());
            exchange.getIn().setHeader("forceDownload", forceDownload);
            exchange.getIn().setHeader("jwtToken", jwtToken);
        });
    }

    public ByteArrayOutputStream downloadFolderAsZip(UUID folderId, String jwtToken) {
        Map<String, Object> headers = new HashMap<>();
        headers.put(Exchange.HTTP_METHOD, HttpMethods.GET);
        headers.put("folderId", folderId);

        if (jwtToken != null && !jwtToken.isEmpty()) {
            headers.put("jwtToken", jwtToken); // Use the Authorization header logic in the route
        }

        InputStream folderInputStream = producerTemplate.requestBodyAndHeaders("direct:downloadFolderURL", null, headers, InputStream.class);

        if (folderInputStream == null) {
            throw new RuntimeException("Failed to retrieve folder as InputStream.");
        }

        ByteArrayOutputStream folderBytes = new ByteArrayOutputStream();
        try {
            folderInputStream.transferTo(folderBytes);
        } catch (Exception e) {
            throw new RuntimeException("Failed to download folder as zip", e);
        }
        return folderBytes;
    }

    public UUID createFolder(String folderName, UUID parentFolderId, String jwtToken) {
        // Process to create a folder and return the new folder ID
        Map<String, Object> headers = new HashMap<>();

        // Set JWT token if available
        if (jwtToken != null && !jwtToken.isEmpty()) {
            headers.put("jwtToken", jwtToken);
        }

        // Prepare request body with folder details
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("folderName", folderName);
        requestBody.put("parentFolderId", parentFolderId);

        // Call the route and return the new folder ID
        UUID newFolderId = producerTemplate.requestBodyAndHeaders("direct:createFolder", requestBody, headers, UUID.class);
        return newFolderId;
    }

    public void uploadFile(InputStream fileInputStream, String folderId, String fileName, String contentType, String jwtToken) {
        Map<String, Object> headers = new HashMap<>();
        headers.put("folderId", folderId);
        headers.put("fileName", fileName);
        headers.put("Content-Type", contentType);

        if (jwtToken != null && !jwtToken.isEmpty()) {
            headers.put("jwtToken", jwtToken);
        }

        // Prepare the file data
        Map<String, Object> formData = new HashMap<>();
        formData.put("file", fileInputStream);

        // Send to the route for uploading
        producerTemplate.sendBodyAndHeaders("direct:uploadFile", formData, headers);
    }

    public List<FolderDTO> getFolderInfo(UUID parentFolderId, String folderName, String jwtToken) {
        // Start with a fresh Map for headers
        Map<String, Object> headers = new HashMap<>();

        // Set required headers for the route
        headers.put("parentFolderId", parentFolderId);
        headers.put("folderName", folderName);

        if (jwtToken != null && !jwtToken.isEmpty()) {
            headers.put("jwtToken", jwtToken);  // Pass JWT token as a header
        }

        try {
            // Call the route and fetch the folder details
            List<Map<String, Object>> detailsList = producerTemplate.requestBodyAndHeaders("direct:getFolderInfo", null, headers, List.class);

            if (detailsList != null && !detailsList.isEmpty()) {
                // Map the results to FolderDTO objects and return them
                return detailsList.stream()
                        .map(item -> objectMapper.convertValue(item, FolderDTO.class))
                        .collect(Collectors.toList());
            } else {
                // No folder found, return null instead of throwing an exception
                log.debug("No folder details found for parentFolderId: {} and folderName: {}", parentFolderId, folderName);
                return null;
            }
        } catch (Exception e) {
            // Log the exception with stack trace and rethrow it
            log.error("Error occurred while fetching folder details for parentFolderId: {} and folderName: {}", parentFolderId, folderName, e);
            throw new RuntimeException("Error occurred while fetching folder details: " + e.getMessage(), e);
        }
    }
}