package com.digitalchain.link_management.enums;


public enum AccessType {
    ANYONE,
    ANYONE_WITH_PASSWORD,
    ALL_USERS,
    SPECIFIC_USERS
}
