package com.digitalchain.link_management.routes.links;

import com.digitalchain.common.dto.UserDTO;
import com.digitalchain.common.dto.files.FileDTO;
import com.digitalchain.link_management.config.BaseRouteBuilder;
import com.digitalchain.link_management.dto.content.FileDownloadDTO;
import com.digitalchain.link_management.dto.content.FolderDownloadDTO;
import com.digitalchain.link_management.service.links.AccessLinksService;
import org.apache.camel.Exchange;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.Map;
import java.util.UUID;

@Component
public class AccessLinksRoute extends BaseRouteBuilder {
    @Autowired
    private AccessLinksService accessLinksService;
    @Override
    public void configure() throws Exception {
        super.configure();

        rest("/sharing")
                .get("/access/{link}")
                .description("Access a file or folder by link")
                .param().name("parentFolderId").type(RestParamType.query).description("Optional parent folder ID to access subfolders").dataType("string").required(false).endParam()
                .description("Access a file or folder by link")
                .responseMessage().code(200).message("Resource accessed successfully").responseModel(FileDTO.class).endResponseMessage() // Assuming DocumentDetails or FolderDetails are the response types
                .responseMessage().code(404).message("Link or Resource not found").endResponseMessage()
                .responseMessage().code(403).message("Link expired or Max access count exceeded").endResponseMessage().to("direct:accessResourceByUsers")

                .get("/access/any/{link}")
                .param().name("password").type(RestParamType.query).description("Password for the link, if required").dataType("string").required(false).endParam()
                .param().name("parentFolderId").type(RestParamType.query).description("Optional parent folder ID to access subfolders").dataType("string").required(false).endParam()
                .description("Access a file or folder by link")
                .description("Access a file or folder by link (anyone or anyone with password)")
                .responseMessage().code(200).message("Resource accessed successfully").responseModel(FileDTO.class).endResponseMessage()
                .responseMessage().code(400).message("Invalid password or Password required").endResponseMessage()
                .responseMessage().code(404).message("Link or Resource not found").endResponseMessage()
                .responseMessage().code(403).message("Link expired or Max access count exceeded").endResponseMessage()
                .to("direct:accessResourceByAnyone")

                .get("/downloadfile")
                .param().name("link").type(RestParamType.query).description("The shared link").dataType("string").endParam()
                .param().name("fileId").type(RestParamType.query).description("ID of the file to be downloaded inside the shared folder").dataType("string").required(false).endParam()
                .param().name("forceDownload").type(RestParamType.query).description("Whether to force download").dataType("boolean").endParam()
                .description("Download a file using the shared link")
                .responseMessage().code(200).message("File downloaded successfully").responseModel(InputStreamResource.class).endResponseMessage()
                .responseMessage().code(400).message("Invalid link").endResponseMessage()
                .responseMessage().code(403).message("Permission denied or access count exceeded").endResponseMessage()
                .to("direct:downloadFile")

                // Define the download folder endpoint
                .get("/downloadfolder")
                .param().name("link").type(RestParamType.query).description("The shared link").dataType("string").endParam()
                .param().name("folderId").type(RestParamType.query).description("ID of the folder to be downloaded").dataType("string").required(false).endParam()
                .description("Download a folder or subfolder using the shared link")
                .responseMessage().code(200).message("Folder downloaded successfully").responseModel(ByteArrayOutputStream.class).endResponseMessage()
                .responseMessage().code(400).message("Invalid link or subfolder ID").endResponseMessage()
                .responseMessage().code(403).message("Permission denied or access count exceeded").endResponseMessage()
                .to("direct:downloadFolder");
        // Route to process access by link
        from("direct:accessResourceByAnyone")
                .routeId("accessResourceByAnyone")
                .process(this::accessResourceByAnyone)
                .log("Returning response: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:accessResourceByUsers")
                .routeId("accessResourceByUsers")
                .process(this::accessResourceByUsers)  // Calls the method to handle anyone/anyone with password access
                .log("Returning response: ${body}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));
        from("direct:downloadFile")
                .routeId("downloadFile")
                .process(this::processDownloadFile);
        from("direct:downloadFolder")
                .routeId("downloadFolder")
                .process(this::processDownloadFolder)
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(200))
                .setHeader(Exchange.CONTENT_TYPE, constant("application/octet-stream"));
    }
    private void accessResourceByAnyone(Exchange exchange) {
        // Extract parameters from the request
        String link = exchange.getIn().getHeader("link", String.class);
        String password = exchange.getIn().getHeader("password", String.class);
        String parentFolderIdParam = exchange.getIn().getHeader("parentFolderId", String.class);

        // Treat empty or invalid parentFolderId as null
        UUID parentFolderId = (parentFolderIdParam != null && !parentFolderIdParam.isEmpty())
                ? UUID.fromString(parentFolderIdParam) : null;
        UserDTO user = new UserDTO();
        user.setIpAddress(exchange.getIn().getHeader("X-Forwarded-For", String.class));
        // Access the resource using the shared link
        Object resource = accessLinksService.accessResourceByAnyone(link, password, parentFolderId,user);

        // Set the response body
        exchange.getIn().setBody(resource);

        // Set response headers
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
        exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
    }
    private void accessResourceByUsers(Exchange exchange) {
        // Extract parameters from the request
        String link = exchange.getIn().getHeader("link", String.class);
        UserDTO user = exchange.getProperty("user", UserDTO.class);  // Use UserDTO directly
        String parentFolderIdParam = exchange.getIn().getHeader("parentFolderId", String.class);

        // Treat empty or invalid parentFolderId as null
        UUID parentFolderId = (parentFolderIdParam != null && !parentFolderIdParam.isEmpty())
                ? UUID.fromString(parentFolderIdParam) : null;

        // Access the resource using the shared link, now passing UserDTO
        Object resource = accessLinksService.accessResourceByUsers(link, user, parentFolderId);

        // Set the response body
        exchange.getIn().setBody(resource);

        // Set response headers
        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
        exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
    }
    private void processDownloadFile(Exchange exchange) {
        String link = exchange.getIn().getHeader("link", String.class);
        String fileIdParam = exchange.getIn().getHeader("fileId", String.class);
        boolean forceDownload = Boolean.TRUE.equals(exchange.getIn().getHeader("forceDownload", Boolean.class));

        UUID fileId = (fileIdParam != null && !fileIdParam.isEmpty()) ? UUID.fromString(fileIdParam) : null;

        // Validate download permissions and get the file download response from AccessLinksService
        Exchange documentExchange = accessLinksService.validateAndDownloadFile(link, fileId, forceDownload);

        // Copy all headers and body from the documentExchange to the current exchange
        exchange.getIn().setHeaders(documentExchange.getIn().getHeaders());
        exchange.getIn().setBody(documentExchange.getIn().getBody());
    }



    private void processDownloadFolder(Exchange exchange) {
        String link = exchange.getIn().getHeader("link", String.class);
        String folderIdParam = exchange.getIn().getHeader("folderId", String.class);

        // Convert folderId parameter to UUID, or set to null if not provided
        UUID folderId = (folderIdParam != null && !folderIdParam.isEmpty())
                ? UUID.fromString(folderIdParam)
                : null;

        // Retrieve the folder as a FolderDownloadDTO using the shared link service, with optional folder ID
        FolderDownloadDTO folderDownloadDTO = accessLinksService.downloadFolderAsZip(link, folderId);

        // Set headers for downloading the zip file with the correct folder name
        exchange.getIn().setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + folderDownloadDTO.getFolderName() + ".zip\"");
        exchange.getIn().setHeader(HttpHeaders.CONTENT_TYPE, folderDownloadDTO.getFolderType());

        // Set the ByteArrayOutputStream as the body of the response
        exchange.getIn().setBody(folderDownloadDTO.getByteArrayOutputStream().toByteArray());
    }

}
