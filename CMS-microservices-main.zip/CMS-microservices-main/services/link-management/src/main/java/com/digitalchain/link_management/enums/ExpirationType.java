package com.digitalchain.link_management.enums;

public enum ExpirationType {
    NONE,
    ON_DATE,
    ON_NUMBER_OF_CLICKS
}
